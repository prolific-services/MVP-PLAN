/* @ds-bundle: {"format":3,"namespace":"MaidsCcDesignSystem_019dc3","components":[],"sourceHashes":{"ui_kits/dashboard/components.jsx":"c31688e66635","ui_kits/dashboard/tweaks-panel.jsx":"0aa200157ad1","ui_kits/marketing/components.jsx":"e7ec85f7f449","ui_kits/marketing/pages.jsx":"bb5c6a4ae80b","ui_kits/marketing/service-data.jsx":"b0f4fe88c599","ui_kits/marketing/service-detail.jsx":"9536d9d4ceeb","ui_kits/social/components.jsx":"d3ffce26c9c6","ui_kits/social/tweaks-panel.jsx":"22c052960f83"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MaidsCcDesignSystem_019dc3 = window.MaidsCcDesignSystem_019dc3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/dashboard/components.jsx
try { (() => {
/* global React */
/* Internal Ops Dashboard — components match dashboard.css */

/* Official WhatsApp glyph — the brand's primary B2C channel. Used wherever
   the UI represents WhatsApp (inbox, customer messages). Inherits color via
   currentColor. */
function WaIcon({
  size
}) {
  const s = size || '1.05em';
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 32 32",
    width: s,
    height: s,
    fill: "currentColor",
    "aria-hidden": "true",
    focusable: "false",
    style: {
      display: 'inline-block',
      verticalAlign: '-0.16em',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M16.004 0h-.008C7.174 0 0 7.176 0 16c0 3.5 1.128 6.744 3.046 9.378L1.05 31.31l6.137-1.961C9.717 31.018 12.74 32 16.004 32 24.826 32 32 24.822 32 16S24.826 0 16.004 0zm9.31 22.594c-.386 1.09-1.918 1.994-3.14 2.258-.836.178-1.928.32-5.604-1.204-4.7-1.948-7.726-6.724-7.962-7.034-.226-.31-1.9-2.53-1.9-4.826 0-2.296 1.166-3.424 1.636-3.904.386-.394.844-.574 1.298-.574.146 0 .278.008.398.014.47.02.706.048 1.016.79.386.93 1.326 3.226 1.438 3.462.114.236.228.554.07.864-.148.32-.278.46-.514.736-.236.276-.46.488-.696.784-.216.258-.46.534-.188.998.272.454 1.21 1.994 2.6 3.23 1.794 1.594 3.274 2.088 3.786 2.302.382.158.836.12 1.116-.186.354-.394.79-1.046 1.234-1.688.314-.46.71-.518 1.126-.362.424.148 2.71 1.276 3.18 1.51.47.236.78.35.894.546.112.196.112 1.13-.274 2.22z"
  }));
}
function Sidebar() {
  return /*#__PURE__*/React.createElement("aside", {
    className: "sidebar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/maids-logo-white.png",
    alt: "Maids.cc",
    className: "wm"
  }), /*#__PURE__*/React.createElement("span", {
    className: "pip"
  }, "OPS")), /*#__PURE__*/React.createElement("a", {
    className: "item active",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "layout-dashboard"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Today")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "inbox"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Inbox"), /*#__PURE__*/React.createElement("span", {
    className: "count urgent"
  }, "12")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "users"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Roster")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "repeat"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Replacements"), /*#__PURE__*/React.createElement("span", {
    className: "count"
  }, "4")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "badge-check"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Visa pipeline")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "calendar"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Schedule")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "credit-card"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Billing")), /*#__PURE__*/React.createElement("div", {
    className: "section-label"
  }, "Insights"), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "trending-up"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "SLA dashboard")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bar-chart-3"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Reports")), /*#__PURE__*/React.createElement("a", {
    className: "item",
    href: "#"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "settings"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Admin")), /*#__PURE__*/React.createElement("div", {
    className: "sidebar-footer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "av"
  }, "RB"), /*#__PURE__*/React.createElement("div", {
    className: "who"
  }, /*#__PURE__*/React.createElement("div", {
    className: "name"
  }, "Reem B."), /*#__PURE__*/React.createElement("div", {
    className: "role"
  }, "DUTY MGR \xB7 ABU DHABI"))));
}
function Topbar() {
  return /*#__PURE__*/React.createElement("header", {
    className: "topbar"
  }, /*#__PURE__*/React.createElement("h1", null, "Today"), /*#__PURE__*/React.createElement("div", {
    className: "crumb"
  }, "\xB7 ", /*#__PURE__*/React.createElement("b", null, "Abu Dhabi"), " region"), /*#__PURE__*/React.createElement("div", {
    className: "role-tabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: "active"
  }, "All teams"), /*#__PURE__*/React.createElement("button", null, "Coordinators"), /*#__PURE__*/React.createElement("button", null, "Drivers"), /*#__PURE__*/React.createElement("button", null, "PRO")), /*#__PURE__*/React.createElement("div", {
    className: "topbar-spacer"
  }), /*#__PURE__*/React.createElement("div", {
    className: "search"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "search"
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search maid, household, visa ID\u2026"
  }), /*#__PURE__*/React.createElement("kbd", null, "\u2318K")), /*#__PURE__*/React.createElement("div", {
    className: "right"
  }, /*#__PURE__*/React.createElement("span", {
    className: "shift-pill"
  }, /*#__PURE__*/React.createElement("span", {
    className: "live-dot"
  }), "Live \xB7 06:42"), /*#__PURE__*/React.createElement("button", {
    className: "icon-btn"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bell"
  }), /*#__PURE__*/React.createElement("span", {
    className: "pip"
  })), /*#__PURE__*/React.createElement("button", {
    className: "icon-btn"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "help-circle"
  }))));
}
function PageHeader() {
  return /*#__PURE__*/React.createElement("div", {
    className: "page-h"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", null, "Operations \xB7 Mon 4 May"), /*#__PURE__*/React.createElement("div", {
    className: "sub"
  }, /*#__PURE__*/React.createElement("b", null, "137 households"), " serviced today \xB7 ", /*#__PURE__*/React.createElement("b", null, "4"), " replacement requests open \xB7 ", /*#__PURE__*/React.createElement("b", null, "9"), " visas waiting on action")), /*#__PURE__*/React.createElement("div", {
    className: "actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost btn-sm"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "filter"
  }), "Filters"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost btn-sm"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "download"
  }), "Export"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary btn-sm"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "plus"
  }), "New ticket")));
}
function KPIs() {
  const items = [{
    lbl: 'Active maids',
    val: '1,284',
    unit: '',
    delta: '+12 today',
    cls: 'up',
    live: true
  }, {
    lbl: 'Households today',
    val: '137',
    unit: '',
    delta: '94% on-time',
    cls: 'up'
  }, {
    lbl: 'Open inbox',
    val: '12',
    unit: '',
    delta: '3 SLA-warn',
    cls: 'down',
    attn: true
  }, {
    lbl: 'Replacements 7d',
    val: '4',
    unit: '',
    delta: 'flat vs prior',
    cls: 'flat'
  }, {
    lbl: 'Visas in pipeline',
    val: '38',
    unit: '',
    delta: '9 action-needed',
    cls: 'down'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "kpis"
  }, items.map((k, i) => /*#__PURE__*/React.createElement("div", {
    className: 'kpi' + (k.attn ? ' attn' : ''),
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "lbl"
  }, k.live && /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), k.lbl), /*#__PURE__*/React.createElement("div", {
    className: "val"
  }, k.val, k.unit && /*#__PURE__*/React.createElement("span", {
    className: "unit"
  }, k.unit)), /*#__PURE__*/React.createElement("div", {
    className: 'delta ' + k.cls
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": k.cls === 'up' ? 'arrow-up' : k.cls === 'down' ? 'arrow-down' : 'minus'
  }), k.delta), /*#__PURE__*/React.createElement("svg", {
    className: "spark",
    viewBox: "0 0 60 24",
    preserveAspectRatio: "none"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "0,18 8,16 16,17 24,12 32,14 40,8 48,10 56,4 60,6",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    style: {
      color: k.attn ? 'var(--maids-orange)' : 'var(--maids-blue)'
    }
  })))));
}
function Inbox() {
  const rows = [{
    unread: true,
    av: 'AK',
    avC: '',
    name: 'Aisha K. · Al Reem',
    time: '06:41',
    preview: 'Maria not here yet — usually arrives by 6:30. Can you check?',
    tag: 'replace',
    sla: {
      v: '14m',
      cls: 'warn'
    }
  }, {
    unread: true,
    av: 'JM',
    avC: 'b',
    name: 'Jay M. · Saadiyat',
    time: '06:36',
    preview: 'Visa medical re-test booked Tue 9:30 — confirmed?',
    tag: 'visa',
    sla: {
      v: '19m',
      cls: 'warn'
    }
  }, {
    unread: true,
    av: '+9',
    avC: 'o',
    name: '+971 50 ··· 4421',
    time: '06:28',
    preview: 'Live-in package quote · 1 child + dog · start 15 May',
    tag: 'lead',
    sla: {
      v: 'New',
      cls: ''
    }
  }, {
    unread: false,
    av: 'PK',
    avC: '',
    name: 'Priya K. · Yas',
    time: '05:54',
    preview: 'Replacement update — Maid Linet arrives 09:30 with PRO Sami',
    tag: 'replace',
    sla: {
      v: '–',
      cls: ''
    }
  }, {
    unread: false,
    av: 'OM',
    avC: 'b',
    name: 'Omar M. · Khalifa City',
    time: '05:31',
    preview: 'Renewal documents uploaded · Emirates ID, passport copy',
    tag: 'visa',
    sla: {
      v: '–',
      cls: ''
    }
  }, {
    unread: false,
    av: 'TS',
    avC: '',
    name: 'Tom S. · Reem Hills',
    time: 'Yest',
    preview: 'Resolved · refund of AED 3,950 processed',
    tag: 'success',
    sla: {
      v: '–',
      cls: ''
    }
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-h"
  }, /*#__PURE__*/React.createElement("h3", null, /*#__PURE__*/React.createElement("span", {
    className: "pip"
  }), /*#__PURE__*/React.createElement(WaIcon, {
    size: "1.05em"
  }), "Live inbox \xB7 WhatsApp"), /*#__PURE__*/React.createElement("div", {
    className: "tabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: "active"
  }, "All \xB7 12"), /*#__PURE__*/React.createElement("button", null, "Replace \xB7 4"), /*#__PURE__*/React.createElement("button", null, "Visa \xB7 5"), /*#__PURE__*/React.createElement("button", null, "Leads \xB7 3")), /*#__PURE__*/React.createElement("span", {
    className: "more"
  }, "Open inbox", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: 'inbox-row' + (r.unread ? ' unread' : ''),
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: 'av' + (r.avC ? ' ' + r.avC : '')
  }, r.av), /*#__PURE__*/React.createElement("div", {
    className: "body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "name"
  }, r.name), /*#__PURE__*/React.createElement("span", {
    className: "time"
  }, r.time)), /*#__PURE__*/React.createElement("div", {
    className: "preview"
  }, r.preview)), /*#__PURE__*/React.createElement("div", {
    className: "meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'tag ' + r.tag
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), r.tag), r.sla.v && /*#__PURE__*/React.createElement("span", {
    className: 'sla' + (r.sla.cls ? ' ' + r.sla.cls : '')
  }, r.sla.v))))));
}
function VisaKanban() {
  const cols = [{
    name: 'Intake',
    count: 6,
    cards: [{
      id: 'V-2841',
      name: 'Linet O.',
      day: '+0d',
      agent: 'SK'
    }, {
      id: 'V-2842',
      name: 'Faith W.',
      day: '+0d',
      agent: 'SK'
    }]
  }, {
    name: 'Medical',
    count: 9,
    urg: true,
    cards: [{
      id: 'V-2810',
      name: 'Maria S.',
      day: '+2d',
      agent: 'AB',
      urg: true
    }, {
      id: 'V-2812',
      name: 'Bethel A.',
      day: '+1d',
      agent: 'AB'
    }]
  }, {
    name: 'Emirates ID',
    count: 8,
    cards: [{
      id: 'V-2790',
      name: 'Joyce N.',
      day: '+3d',
      agent: 'RB'
    }]
  }, {
    name: 'PRO / typing',
    count: 7,
    urg: true,
    cards: [{
      id: 'V-2755',
      name: 'Adanech T.',
      day: '+5d',
      agent: 'PR',
      urg: true
    }, {
      id: 'V-2761',
      name: 'Hanna G.',
      day: '+4d',
      agent: 'PR'
    }]
  }, {
    name: 'Issued',
    count: 8,
    cards: [{
      id: 'V-2701',
      name: 'Marie F.',
      day: '7d total',
      agent: 'RB'
    }]
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-h"
  }, /*#__PURE__*/React.createElement("h3", null, "Visa pipeline \xB7 38 active"), /*#__PURE__*/React.createElement("span", {
    className: "meta"
  }, "7-DAY TARGET \xB7 6.4D AVG"), /*#__PURE__*/React.createElement("span", {
    className: "more"
  }, "Open kanban", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "kanban"
  }, cols.map((c, i) => /*#__PURE__*/React.createElement("div", {
    className: "col",
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "col-h"
  }, /*#__PURE__*/React.createElement("span", {
    className: "name"
  }, c.name), /*#__PURE__*/React.createElement("span", {
    className: 'count' + (c.urg ? ' urg' : '')
  }, c.count)), c.cards.map((k, j) => /*#__PURE__*/React.createElement("div", {
    className: 'kcard' + (k.urg ? ' urg' : ''),
    key: j
  }, /*#__PURE__*/React.createElement("div", {
    className: "id"
  }, k.id), /*#__PURE__*/React.createElement("div", {
    className: "name"
  }, k.name), /*#__PURE__*/React.createElement("div", {
    className: "meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'day' + (k.urg ? ' urg' : '')
  }, k.day), /*#__PURE__*/React.createElement("span", {
    className: "agent"
  }, k.agent))))))));
}
function TodayBoard() {
  const rows = [{
    time: '06:30',
    ampm: 'AM',
    who: 'Maria S. → Aisha K.',
    sub: 'Live-in · Al Reem · regular shift',
    status: 'on',
    label: 'On site'
  }, {
    time: '07:00',
    ampm: 'AM',
    who: 'Linet O. → Priya K.',
    sub: 'Replacement deploy · Yas Acres',
    status: 'on',
    label: 'En route',
    now: true
  }, {
    time: '08:00',
    ampm: 'AM',
    who: 'Faith W.',
    sub: 'Hourly · Saadiyat (3 hrs)',
    status: 'on',
    label: 'On site'
  }, {
    time: '09:30',
    ampm: 'AM',
    who: 'Maria S.',
    sub: 'Visa medical · Mafraq Centre',
    status: 'medical',
    label: 'Medical'
  }, {
    time: '11:00',
    ampm: 'AM',
    who: 'Bethel A.',
    sub: 'Hourly · Khalifa City (4 hrs)',
    status: 'on',
    label: 'On site'
  }, {
    time: '14:00',
    ampm: 'PM',
    who: 'Hanna G.',
    sub: 'Day off · agreed',
    status: 'leave',
    label: 'Off'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-h"
  }, /*#__PURE__*/React.createElement("h3", null, /*#__PURE__*/React.createElement("span", {
    className: "pip"
  }), "Today's schedule"), /*#__PURE__*/React.createElement("span", {
    className: "meta"
  }, "137 ASSIGNMENTS \xB7 06:42 NOW"), /*#__PURE__*/React.createElement("span", {
    className: "more"
  }, "Open schedule", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "today"
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: 'today-row' + (r.now ? ' now' : ''),
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "time"
  }, r.time, /*#__PURE__*/React.createElement("span", {
    className: "ampm"
  }, r.ampm)), /*#__PURE__*/React.createElement("div", {
    className: "who"
  }, r.who, /*#__PURE__*/React.createElement("div", {
    className: "sub"
  }, r.sub)), /*#__PURE__*/React.createElement("span", {
    className: 'status ' + r.status
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), r.label), /*#__PURE__*/React.createElement("span", {
    className: "tag support"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), r.now ? 'now' : 'today')))));
}
function ReplacementsRail() {
  const rows = [{
    id: 'R-0042',
    reason: 'Family unhappy with cooking — wants more variety',
    who: 'Aisha K. · 7d into contract',
    urgent: true
  }, {
    id: 'R-0041',
    reason: 'Maid requested transfer — schedule conflict',
    who: 'Priya K. · 21d',
    urgent: false
  }, {
    id: 'R-0039',
    reason: 'Failed medical — needs re-test before deploy',
    who: 'Bethel A. · intake',
    urgent: true
  }, {
    id: 'R-0037',
    reason: 'Cultural fit — prefers Filipina vs Ethiopian',
    who: 'Tom S. · 3d',
    urgent: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-h"
  }, /*#__PURE__*/React.createElement("h3", null, "Replacements \xB7 4 open"), /*#__PURE__*/React.createElement("span", {
    className: "more"
  }, "Open queue", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "replace-list"
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "replace-row",
    key: i
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "id"
  }, r.id), /*#__PURE__*/React.createElement("div", {
    className: "reason"
  }, r.reason), /*#__PURE__*/React.createElement("div", {
    className: "who"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "user",
    style: {
      width: 11,
      height: 11
    }
  }), /*#__PURE__*/React.createElement("b", null, r.who))), /*#__PURE__*/React.createElement("div", {
    className: "actions"
  }, r.urgent && /*#__PURE__*/React.createElement("span", {
    className: "tag hot"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "urgent"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost btn-sm"
  }, "Assign")))))));
}
function SlaStrip() {
  const cells = [{
    lbl: 'First response · WA',
    v: '2.4',
    unit: 'min',
    target: 'target ≤ 5min',
    pct: 88
  }, {
    lbl: 'Replacement deploy',
    v: '3.1',
    unit: 'hrs',
    target: 'target ≤ 6h',
    pct: 72,
    warn: false
  }, {
    lbl: 'Visa cycle',
    v: '6.4',
    unit: 'days',
    target: 'target ≤ 7d',
    pct: 91
  }, {
    lbl: 'CSAT · this week',
    v: '4.78',
    unit: '/5',
    target: '15.2K reviews',
    pct: 95
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "sla-strip"
  }, cells.map((c, i) => /*#__PURE__*/React.createElement("div", {
    className: "sla-cell",
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "lbl"
  }, c.lbl), /*#__PURE__*/React.createElement("div", {
    className: "row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, c.v), /*#__PURE__*/React.createElement("span", {
    className: "target"
  }, c.unit, " \xB7 ", c.target)), /*#__PURE__*/React.createElement("div", {
    className: "gauge"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'fill' + (c.warn ? ' warn' : ''),
    style: {
      width: c.pct + '%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "mark",
    style: {
      left: '85%'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "foot"
  }, /*#__PURE__*/React.createElement("span", null, "0"), /*#__PURE__*/React.createElement("span", null, "target"), /*#__PURE__*/React.createElement("span", null, "100")))));
}
function ActivityTail() {
  const rows = [{
    ic: 'success',
    icon: 'check-circle-2',
    label: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      className: "who"
    }, "Reem B."), " resolved replacement R-0036 \xB7 Tom S."),
    time: '06:38'
  }, {
    ic: 'info',
    icon: 'whatsapp',
    label: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      className: "who"
    }, "Sami P."), " messaged Aisha K. \u2014 ETA on Linet (07:00)"),
    time: '06:34'
  }, {
    ic: 'warning',
    icon: 'alert-triangle',
    label: /*#__PURE__*/React.createElement(React.Fragment, null, "SLA-warn \xB7 ticket #1841 unanswered for 14m"),
    time: '06:30'
  }, {
    ic: 'success',
    icon: 'badge-check',
    label: /*#__PURE__*/React.createElement(React.Fragment, null, "Visa V-2701 issued \xB7 ", /*#__PURE__*/React.createElement("span", {
      className: "who"
    }, "Marie F."), " \xB7 7d cycle"),
    time: '05:58'
  }, {
    ic: 'info',
    icon: 'user-plus',
    label: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      className: "who"
    }, "Anna B."), " added 3 maids to active roster"),
    time: '05:42'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-h"
  }, /*#__PURE__*/React.createElement("h3", null, "Activity \xB7 last 30 min"), /*#__PURE__*/React.createElement("span", {
    className: "meta"
  }, "AUTO \xB7 LIVE"), /*#__PURE__*/React.createElement("span", {
    className: "more"
  }, "Full log", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "activity"
  }, rows.map((a, i) => /*#__PURE__*/React.createElement("div", {
    className: "act",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: 'ic ' + a.ic
  }, a.icon === 'whatsapp' ? /*#__PURE__*/React.createElement(WaIcon, {
    size: "0.95em"
  }) : /*#__PURE__*/React.createElement("i", {
    "data-lucide": a.icon
  })), /*#__PURE__*/React.createElement("div", {
    className: "label"
  }, a.label), /*#__PURE__*/React.createElement("span", {
    className: "time"
  }, a.time)))));
}
Object.assign(window, {
  Sidebar,
  Topbar,
  PageHeader,
  KPIs,
  Inbox,
  VisaKanban,
  TodayBoard,
  ReplacementsRail,
  SlaStrip,
  ActivityTail
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/tweaks-panel.jsx
try { (() => {
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;width:100%;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-noncommentable": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;

  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}
function TweakColor({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
    type: "color",
    className: "twk-swatch",
    value: value,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/components.jsx
try { (() => {
/* global React */

/* ========================================================================
   MAIDS.CC MARKETING KIT — redesigned against the live site (May 2026).
   Single hero: "Get a full-time maid in your home today."
   Primary CTA: Sign & pay online in 5 minutes. WhatsApp is secondary.
   Core mechanic: browse maid video profiles, hire, we Uber her to you.
   Trust signals: 30K+ employees · 4.8 / 15K Google reviews · Tadbeer
                  Ministry award · 2nd-largest UAE employer · Khaleej Times.
   ======================================================================== */

const WA_NUMBER = '971800624377';
const wa = msg => `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`;
/* Live Google Business reviews — clicking any rating opens the real, current
   listing on Google Maps (the source of truth for up-to-date numbers). */
const GOOGLE_REVIEWS_URL = 'https://maps.app.goo.gl/TW51GJNnWCEgeQwz5';

/* Official WhatsApp glyph — used on every CTA that opens WhatsApp.
   Inherits button text colour via currentColor. */
function WaIcon({
  size
}) {
  const s = size || '1.1em';
  return /*#__PURE__*/React.createElement("svg", {
    className: "wa-icon",
    viewBox: "0 0 32 32",
    width: s,
    height: s,
    fill: "currentColor",
    "aria-hidden": "true",
    focusable: "false",
    style: {
      display: 'inline-block',
      verticalAlign: '-0.16em',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M16.004 0h-.008C7.174 0 0 7.176 0 16c0 3.5 1.128 6.744 3.046 9.378L1.05 31.31l6.137-1.961C9.717 31.018 12.74 32 16.004 32 24.826 32 32 24.822 32 16S24.826 0 16.004 0zm9.31 22.594c-.386 1.09-1.918 1.994-3.14 2.258-.836.178-1.928.32-5.604-1.204-4.7-1.948-7.726-6.724-7.962-7.034-.226-.31-1.9-2.53-1.9-4.826 0-2.296 1.166-3.424 1.636-3.904.386-.394.844-.574 1.298-.574.146 0 .278.008.398.014.47.02.706.048 1.016.79.386.93 1.326 3.226 1.438 3.462.114.236.228.554.07.864-.148.32-.278.46-.514.736-.236.276-.46.488-.696.784-.216.258-.46.534-.188.998.272.454 1.21 1.994 2.6 3.23 1.794 1.594 3.274 2.088 3.786 2.302.382.158.836.12 1.116-.186.354-.394.79-1.046 1.234-1.688.314-.46.71-.518 1.126-.362.424.148 2.71 1.276 3.18 1.51.47.236.78.35.894.546.112.196.112 1.13-.274 2.22z"
  }));
}

/* Official UAE Dirham symbol — path data from assets/dirham.svg.
   Inherits color via currentColor; scale via the `size` prop. */
const DH_PATH = "m88.3 1c0.4 0.6 2.6 3.3 4.7 5.9 15.3 18.2 26.8 47.8 33 85.1 4.1 24.5 4.3 32.2 4.3 125.6v87h-41.8c-38.2 0-42.6-0.2-50.1-1.7-11.8-2.5-24-9.2-32.2-17.8-6.5-6.9-6.3-7.3-5.9 13.6 0.5 17.3 0.7 19.2 3.2 28.6 4 14.9 9.5 26 17.8 35.9 11.3 13.6 22.8 21.2 39.2 26.3 3.5 1 10.9 1.4 37.1 1.6l32.7 0.5v43.3 43.4l-46.1-0.3-46.3-0.3-8-3.2c-9.5-3.8-13.8-6.6-23.1-14.9l-6.8-6.1 0.4 19.1c0.5 17.7 0.6 19.7 3.1 28.7 8.7 31.8 29.7 54.5 57.4 61.9 6.9 1.9 9.6 2 38.5 2.4l30.9 0.4v89.6c0 54.1-0.3 94-0.8 100.8-0.5 6.2-2.1 17.8-3.5 25.9-6.5 37.3-18.2 65.4-35 83.6l-3.4 3.7h169.1c101.1 0 176.7-0.4 187.8-0.9 19.5-1 63-5.3 72.8-7.4 3.1-0.6 8.9-1.5 12.7-2.1 8.1-1.2 21.5-4 40.8-8.9 27.2-6.8 52-15.3 76.3-26.1 7.6-3.4 29.4-14.5 35.2-18 3.1-1.8 6.8-4 8.2-4.7 3.9-2.1 10.4-6.3 19.9-13.1 4.7-3.4 9.4-6.7 10.4-7.4 4.2-2.8 18.7-14.9 25.3-21 25.1-23.1 46.1-48.8 62.4-76.3 2.3-4 5.3-9 6.6-11.1 3.3-5.6 16.9-33.6 18.2-37.8 0.6-1.9 1.4-3.9 1.8-4.3 2.6-3.4 17.6-50.6 19.4-60.9 0.6-3.3 0.9-3.8 3.4-4.3 1.6-0.3 24.9-0.3 51.8-0.1 53.8 0.4 53.8 0.4 65.7 5.9 6.7 3.1 8.7 4.5 16.1 11.2 9.7 8.7 8.8 10.1 8.2-11.7-0.4-12.8-0.9-20.7-1.8-23.9-3.4-12.3-4.2-14.9-7.2-21.1-9.8-21.4-26.2-36.7-47.2-44l-8.2-3-33.4-0.4-33.3-0.5 0.4-11.7c0.4-15.4 0.4-45.9-0.1-61.6l-0.4-12.6 44.6-0.2c38.2-0.2 45.3 0 49.5 1.1 12.6 3.5 21.1 8.3 31.5 17.8l5.8 5.4v-14.8c0-17.6-0.9-25.4-4.5-37-7.1-23.5-21.1-41-41.1-51.8-13-7-13.8-7.2-58.5-7.5-26.2-0.2-39.9-0.6-40.6-1.2-0.6-0.6-1.1-1.6-1.1-2.4 0-0.8-1.5-7.1-3.5-13.9-23.4-82.7-67.1-148.4-131-197.1-8.7-6.7-30-20.8-38.6-25.6-3.3-1.9-6.9-3.9-7.8-4.5-4.2-2.3-28.3-14.1-34.3-16.6-3.6-1.6-8.3-3.6-10.4-4.4-35.3-15.3-94.5-29.8-139.7-34.3-7.4-0.7-17.2-1.8-21.7-2.2-20.4-2.3-48.7-2.6-209.4-2.6-135.8 0-169.9 0.3-169.4 1zm330.7 43.3c33.8 2 54.6 4.6 78.9 10.5 74.2 17.6 126.4 54.8 164.3 117 3.5 5.8 18.3 36 20.5 42.1 10.5 28.3 15.6 45.1 20.1 67.3 1.1 5.4 2.6 12.6 3.3 16 0.7 3.3 1 6.4 0.7 6.7-0.5 0.4-100.9 0.6-223.3 0.5l-222.5-0.2-0.3-128.5c-0.1-70.6 0-129.3 0.3-130.4l0.4-1.9h71.1c39 0 78 0.4 86.5 0.9zm297.5 350.3c0.7 4.3 0.7 77.3 0 80.9l-0.6 2.7-227.5-0.2-227.4-0.3-0.2-42.4c-0.2-23.3 0-42.7 0.2-43.1 0.3-0.5 97.2-0.8 227.7-0.8h227.2zm-10.2 171.7c0.5 1.5-1.9 13.8-6.8 33.8-5.6 22.5-13.2 45.2-20.9 62-3.8 8.6-13.3 27.2-15.6 30.7-1.1 1.6-4.3 6.7-7.1 11.2-18 28.2-43.7 53.9-73 72.9-10.7 6.8-32.7 18.4-38.6 20.2-1.2 0.3-2.5 0.9-3 1.3-0.7 0.6-9.8 4-20.4 7.8-19.5 6.9-56.6 14.4-86.4 17.5-19.3 1.9-22.4 2-96.7 2h-76.9v-129.7-129.8l220.9-0.4c121.5-0.2 221.6-0.5 222.4-0.7 0.9-0.1 1.8 0.5 2.1 1.2z";
function Dh({
  size
}) {
  const fs = size || '0.9em';
  return /*#__PURE__*/React.createElement("svg", {
    className: "dh",
    viewBox: "0 0 1000 870",
    "aria-label": "AED",
    role: "img",
    style: {
      width: `calc(${fs} * 1.149)`,
      height: fs,
      display: 'inline-block',
      verticalAlign: '-0.08em',
      marginRight: '0.14em'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: DH_PATH,
    fill: "currentColor"
  }));
}

/* ========================================================================
   PICTURE PLACEHOLDER — the kit's photo primitive.
   Photos fill the entire frame; this draws a striped tinted placeholder
   with a passive-zone overlay where text will sit, plus a mono label.
   ======================================================================== */
function Picture({
  label = 'photo',
  tone = 'blue',
  src,
  // real photo URL — when set, fills the frame and hides the label
  pos = 'center',
  // object-position for the photo (e.g. 'center', 'top', '70% 40%')
  eager,
  // true for above-the-fold images — skips lazy-loading
  passive = 'none',
  // 'top' | 'bottom' | 'left' | 'right' | 'center' | 'none'
  ratio,
  // e.g. '4/5', '16/9', '1/1' — sets aspect-ratio
  rounded = 'md',
  // 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'full'
  className,
  style
}) {
  const radius = {
    none: 0,
    sm: 8,
    md: 16,
    lg: 23,
    xl: 32,
    full: 999
  }[rounded] ?? 16;
  const bg = {
    blue: '#25499B',
    orange: '#EE6124',
    light: '#F2F5FB'
  }[tone] || '#25499B';
  const labelColor = tone === 'light' ? 'rgba(37,73,155,0.25)' : 'rgba(255,255,255,0.25)';
  /* Passive-zone scrims — solid semi-transparent bands, NO gradients.
     The band sits over the side where text will overlay the photo. */
  const passiveBand = passive === 'none' || !passive ? null : {
    position: 'absolute',
    background: 'rgba(22,48,104,0.45)',
    pointerEvents: 'none',
    ...(passive === 'top' && {
      top: 0,
      left: 0,
      right: 0,
      height: '45%'
    }),
    ...(passive === 'bottom' && {
      bottom: 0,
      left: 0,
      right: 0,
      height: '45%'
    }),
    ...(passive === 'left' && {
      top: 0,
      left: 0,
      bottom: 0,
      width: '45%'
    }),
    ...(passive === 'right' && {
      top: 0,
      right: 0,
      bottom: 0,
      width: '45%'
    }),
    ...(passive === 'center' && {
      inset: 0
    })
  };
  return /*#__PURE__*/React.createElement("div", {
    className: 'picture ' + (className || ''),
    style: {
      position: 'relative',
      background: bg,
      borderRadius: radius,
      overflow: 'hidden',
      aspectRatio: ratio,
      width: ratio ? undefined : '100%',
      height: ratio ? undefined : '100%',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: src ? 'none' : 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: labelColor,
      fontFamily: 'var(--font-mono, ui-monospace)',
      fontSize: 11,
      letterSpacing: '0.04em',
      textTransform: 'none',
      fontWeight: 700,
      textAlign: 'center',
      padding: 12
    }
  }, label), src && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: label,
    loading: eager ? 'eager' : 'lazy',
    decoding: "async",
    fetchpriority: eager ? 'high' : undefined,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: pos,
      display: 'block'
    }
  }), passiveBand && /*#__PURE__*/React.createElement("div", {
    style: passiveBand
  }));
}

/* ========================================================================
   PRODUCT MODEL
   Three products, but full-time maid is the primary. Copy lifted from the
   real site: "Sign & pay online in 5 minutes", "We'll Uber her to you",
   "Cancel anytime", "Avoid visits to medical centers & typists".
   ======================================================================== */
const SERVICES = {
  maids: {
    key: 'maids',
    label: 'Full-time maid',
    anchor: 'maids',
    icon: 'sparkles',
    headline: {
      pre: 'Get a full-time maid',
      accent: 'in your home today.',
      post: ''
    },
    lede: () => /*#__PURE__*/React.createElement(React.Fragment, null, "Sign and pay ", /*#__PURE__*/React.createElement("b", null, "online in 5 minutes"), ". We'll ", /*#__PURE__*/React.createElement("b", null, "Uber her to you"), " \u2014 same day in most cases. Cancel anytime. No visits to medical centers or typists."),
    waMsg: 'Hi maids.cc — I want to hire a full-time maid. Please send me profiles.',
    priceLine: {
      from: '2,980',
      unit: '/month',
      or: '',
      orUnit: ''
    },
    bullets: ['Watch maid video profiles · pick your favourite', 'Live-in or live-out · Ethiopian, African, or Filipina', 'All-in monthly: salary + visa + medicals + Ubers + gov costs', '7-day money-back · unlimited free replacements', 'Cancel anytime — no long-term lock-in', 'Free add-ons: ironing, fridge clean, balcony, windows'],
    chips: ['Same-day hire', 'Live-in', 'Live-out', 'Cancel anytime'],
    proofStat: {
      v: '200+',
      l: 'maid profiles ready to start'
    },
    cardFoot: '7-day money-back · unlimited free replacements',
    primaryCtaLabel: 'Sign & pay — 5 min',
    secondaryCtaLabel: 'Chat on WhatsApp'
  },
  nannies: {
    key: 'nannies',
    label: 'Nanny',
    anchor: 'nannies',
    icon: 'baby',
    headline: {
      pre: 'A nanny who actually',
      accent: 'loves your kids.',
      post: ''
    },
    lede: () => /*#__PURE__*/React.createElement(React.Fragment, null, "Hourly or full-time. ", /*#__PURE__*/React.createElement("b", null, "CPR-certified"), ", English-speaking, kid-trained. Same nanny every visit. All-in from ", /*#__PURE__*/React.createElement("b", null, /*#__PURE__*/React.createElement(Dh, null), "2,980/month"), "."),
    waMsg: 'Hi maids.cc — I want to hire a nanny. Please send me profiles.',
    priceLine: {
      from: '2,980',
      unit: '/month',
      or: '35',
      orUnit: '/hour'
    },
    bullets: ['After-school, weekends, ad-hoc — or full-time, live-in/live-out', 'CPR + first-aid certified · background-checked · references', 'Same-nanny guarantee · 7-day money-back · unlimited replacements', 'Upgrades for newborn, special-needs, overnight, multilingual', 'All-in monthly price — salary, visa, medicals, the lot'],
    chips: ['After-school', 'Live-in nanny', 'Newborn-trained', 'CPR-certified'],
    proofStat: {
      v: '4.8★',
      l: '15K Google reviews'
    },
    cardFoot: 'Free replacements until she fits',
    primaryCtaLabel: 'Sign & pay — 5 min',
    secondaryCtaLabel: 'Chat on WhatsApp'
  },
  visa: {
    key: 'visa',
    label: '2-year maid visa',
    anchor: 'visa',
    icon: 'badge-check',
    headline: {
      pre: 'Maid visa,',
      accent: 'issued in 7 days.',
      post: ''
    },
    lede: () => /*#__PURE__*/React.createElement(React.Fragment, null, "Upload your maid's ", /*#__PURE__*/React.createElement("b", null, "passport copy and photo"), ". We handle the rest \u2014 Emirates ID, medical, WPS payroll, embassy paperwork, and PRO services for the awkward bits."),
    waMsg: 'Hi maids.cc — I want a 2-year maid visa. Please send me the details.',
    priceLine: {
      from: '8,500',
      unit: ' + 160/mo',
      or: '10,960',
      orUnit: ' + 0/mo'
    },
    bullets: ['Two-year visa, issued in 7 days end-to-end', 'Emirates ID + medical handled by us', 'WPS payroll set up and run for you', 'PRO services: failed medicals, ban / runaway lifting, DMW, GCC', 'Embassy paperwork — Philippines, Ethiopia, Kenya, Sri Lanka, Uganda', '24/7 customer care · one accountable name for the pipeline'],
    chips: ['New visa', 'Renewal', 'Sponsorship transfer', 'PRO services'],
    proofStat: {
      v: '7 days',
      l: 'visa issued end-to-end'
    },
    cardFoot: 'Tadbeer-licensed · 24/7 PRO support',
    primaryCtaLabel: 'Get my visa — 5 min',
    secondaryCtaLabel: 'Chat on WhatsApp'
  }
};
const SERVICE_KEYS = ['maids', 'nannies', 'visa'];

/* ========================================================================
   MAID GALLERY DATA — placeholder profiles for the hero + dedicated section.
   ======================================================================== */
const MAIDS_GALLERY = [{
  id: 1,
  name: 'Marisol',
  nat: 'Filipina',
  exp: '4 yrs UAE',
  tag: 'Same day',
  photo: 'assets/maid-1.jpg',
  pos: 'center 22%',
  expertise: 'Cooks Filipino & Western dishes · gentle with toddlers'
}, {
  id: 2,
  name: 'Niluka',
  nat: 'Sri Lankan',
  exp: '6 yrs UAE',
  tag: 'Available',
  photo: 'assets/maid-2.jpg',
  pos: 'center 18%',
  expertise: 'Deep-cleaning expert · patient elderly care'
}, {
  id: 3,
  name: 'Esther',
  nat: 'Kenyan',
  exp: '3 yrs UAE',
  tag: 'Newborn',
  photo: 'assets/maid-3.jpg',
  pos: 'center 20%',
  expertise: 'Newborn & infant care · CPR-certified'
}, {
  id: 4,
  name: 'Aster',
  nat: 'Ethiopian',
  exp: '2 yrs UAE',
  tag: 'Live-in',
  photo: 'assets/maid-4.jpg',
  pos: 'center 22%',
  expertise: 'Tidy live-in housekeeping · daily meal prep'
}, {
  id: 5,
  name: 'Joy',
  nat: 'Filipina',
  exp: '5 yrs UAE',
  tag: 'Cooking',
  photo: 'assets/maid-5.jpg',
  pos: 'center 22%',
  expertise: 'Cooks Levantine & Asian food · home baking'
}, {
  id: 6,
  name: 'Priya',
  nat: 'Indian',
  exp: '1 yr UAE',
  tag: 'New arrival',
  photo: 'assets/maid-6.jpg',
  pos: 'center 18%',
  expertise: 'Cooks Indian & Levantine food · comfortable with pets'
}];

/* ========================================================================
   NAV — landing-page minimal: brand left, WhatsApp pill right
   ======================================================================== */
function Nav({
  overlay
}) {
  return /*#__PURE__*/React.createElement("nav", {
    className: 'nav lp nav-min' + (overlay ? ' nav-overlay' : '')
  }, /*#__PURE__*/React.createElement("a", {
    className: "brand",
    href: "index.html"
  }, /*#__PURE__*/React.createElement("img", {
    className: "brand-blue",
    src: "../../assets/logos/maids-logo-blue.png",
    alt: "Maids.cc"
  }), /*#__PURE__*/React.createElement("img", {
    className: "brand-white",
    src: "../../assets/logos/maids-logo-white.png",
    alt: "Maids.cc"
  })), /*#__PURE__*/React.createElement("div", {
    className: "right"
  }, /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc — I want to chat.'),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-wa nav-wa-pill",
    "aria-label": "Chat on WhatsApp"
  }, /*#__PURE__*/React.createElement(WaIcon, null), /*#__PURE__*/React.createElement("span", {
    className: "nav-wa-text"
  }, "WhatsApp")), /*#__PURE__*/React.createElement("a", {
    href: "hire.html",
    className: "btn btn-accent nav-hire",
    "aria-label": "Get started"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "credit-card"
  }), /*#__PURE__*/React.createElement("span", {
    className: "nav-hire-text"
  }, "Get started"))));
}

/* ========================================================================
   HERO — full-bleed photo, single-line headline + brand quadrangle stamp.
   My take: tighter, more confident than the live site's 3-line stack.
   ======================================================================== */
function Hero() {
  // Hero entrance reveal. The hidden start-state lives behind the `.intro`
  // class (added here, before paint, so there's no visible→hidden flash) and is
  // released by `.intro-in`. Crucially, a timer then REMOVES both classes so
  // the resting DOM carries no hidden rule at all — guaranteeing that any
  // export/PDF/screenshot capture, or a backgrounded tab whose compositor
  // froze the transition mid-flight, settles to fully-visible content rather
  // than an invisible block. setTimeout fires even in background tabs (unlike
  // rAF), so the settle is reliable. useLayoutEffect runs pre-paint.
  React.useLayoutEffect(() => {
    const hero = document.querySelector('.hero.hero-bleed');
    if (!hero) return;
    hero.classList.add('intro');
    let raf1 = 0,
      raf2 = 0;
    raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => hero.classList.add('intro-in'));
    });
    const trigger = setTimeout(() => hero.classList.add('intro-in'), 180);
    // Past the full stagger (≈540ms delay + 720ms duration), drop the animation
    // classes so the resting state is the plain visible base style.
    const settle = setTimeout(() => hero.classList.remove('intro', 'intro-in'), 1500);
    return () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
      clearTimeout(trigger);
      clearTimeout(settle);
    };
  }, []);

  // Autoplay nudge — some browsers won't start muted video until JS calls
  // play(). Try on mount; if blocked, retry once on first user interaction.
  React.useEffect(() => {
    const vids = Array.from(document.querySelectorAll('.hero-video'));
    const tryPlay = () => vids.forEach(v => {
      if (typeof v.play !== 'function') return;
      const p = v.play();
      if (p && p.catch) p.catch(() => {});
    });
    tryPlay();
    const onFirst = () => {
      tryPlay();
      window.removeEventListener('pointerdown', onFirst);
      window.removeEventListener('scroll', onFirst);
    };
    window.addEventListener('pointerdown', onFirst, {
      once: true
    });
    window.addEventListener('scroll', onFirst, {
      once: true,
      passive: true
    });
    return () => {
      window.removeEventListener('pointerdown', onFirst);
      window.removeEventListener('scroll', onFirst);
    };
  }, []);
  return /*#__PURE__*/React.createElement("section", {
    className: "hero hero-bleed",
    id: "top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-video-wrap",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("video", {
    className: "hero-video hero-video-h",
    src: "assets/hero-horizontal.mp4",
    poster: "assets/hero-bubbles.jpg",
    autoPlay: true,
    muted: true,
    loop: true,
    playsInline: true,
    preload: "auto"
  }), /*#__PURE__*/React.createElement("video", {
    className: "hero-video hero-video-v",
    src: "assets/hero-vertical.mp4",
    poster: "assets/hero-bubbles.jpg",
    autoPlay: true,
    muted: true,
    loop: true,
    playsInline: true,
    preload: "auto"
  })), /*#__PURE__*/React.createElement("div", {
    className: "hero-bleed-overlay"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-bleed-inner"
  }, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement("span", null, "Hire a maid"), /*#__PURE__*/React.createElement("span", {
    className: "or"
  }, "OR"), /*#__PURE__*/React.createElement("span", null, "Get a maid visa")), /*#__PURE__*/React.createElement("p", {
    className: "hero-bleed-sub"
  }, "Done on ", /*#__PURE__*/React.createElement("b", null, "WhatsApp ", /*#__PURE__*/React.createElement("span", {
    className: "u"
  }, "in 5 minutes"))), /*#__PURE__*/React.createElement("div", {
    className: "hero-bleed-ctas"
  }, /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc — I want to hire a full-time maid.'),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-primary btn-lg wa"
  }, /*#__PURE__*/React.createElement(WaIcon, null), "Hire a maid"), /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc — I want a 2-year maid visa.'),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-accent btn-lg wa"
  }, /*#__PURE__*/React.createElement(WaIcon, null), "Get a maid visa")), /*#__PURE__*/React.createElement("a", {
    className: "hero-google",
    href: GOOGLE_REVIEWS_URL,
    target: "_blank",
    rel: "noopener",
    title: "See live reviews on Google"
  }, /*#__PURE__*/React.createElement("svg", {
    className: "hg-g",
    viewBox: "0 0 48 48",
    "aria-hidden": "true",
    focusable: "false"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "#EA4335",
    d: "M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#4285F4",
    d: "M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#FBBC05",
    d: "M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#34A853",
    d: "M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
  })), /*#__PURE__*/React.createElement("span", {
    className: "hg-body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hg-top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hg-rating"
  }, "4.8"), /*#__PURE__*/React.createElement("span", {
    className: "hg-stars",
    role: "img",
    "aria-label": "Rated 4.8 out of 5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hg-stars-on",
    style: {
      width: '96%'
    }
  }, "\u2605\u2605\u2605\u2605\u2605"), /*#__PURE__*/React.createElement("span", {
    className: "hg-stars-off"
  }, "\u2605\u2605\u2605\u2605\u2605"))), /*#__PURE__*/React.createElement("span", {
    className: "hg-count"
  }, "15,000+ Google reviews")))));
}

/* ========================================================================
   PRODUCT PICKER — three side-by-side cards. My take vs the live site's
   three full-page colored bands: faster scan, forces a choice, more honest.
   ======================================================================== */
function ProductPicker() {
  return /*#__PURE__*/React.createElement(ServiceSections, null);
}

/* ========================================================================
   SERVICE SECTIONS — alternating full-width sections (image + content).
   Replaces the cramped 4-card picker grid. Each service gets its own
   editorial section with room for a real picture/video placeholder.
   ======================================================================== */
function ServiceSections() {
  const products = [{
    key: 'fulltime',
    tone: 'blue',
    tag: 'Most popular',
    tagColor: 'blue',
    title: 'Full-time maid',
    sub: 'Live-in or live-out. Filipinas, Africans, Ethiopians, or Indians.',
    bullets: ['300+ available maids, ready today', '7-day money-back guarantee', 'Unlimited free replacements'],
    priceFrom: '2,980',
    priceUnit: '/month',
    ctaLabel: 'Hire a maid',
    waMsg: 'Hi maids.cc — I want to hire a full-time maid.',
    mediaLabel: 'Photo or video · maid arriving at a UAE home',
    mediaSrc: 'assets/fulltime-card.png',
    mediaPos: 'center'
  }, {
    key: 'parttime',
    tone: 'green',
    tag: 'Hourly',
    tagColor: 'green',
    title: 'Part-time maid or nanny',
    sub: 'Same maid guaranteed. Childcare, elderly, pet care, cooking.',
    bullets: ['Up to 15% off on multi-visit packages', '100% satisfaction or money back', 'Add-ons at no extra charge'],
    priceFrom: '35',
    priceUnit: '/hour',
    ctaLabel: 'Book part-time',
    waMsg: 'Hi maids.cc — I want to book a part-time maid.',
    mediaLabel: 'Photo or video · part-time maid at work',
    mediaSrc: 'assets/parttime-card.png',
    mediaPos: 'center'
  }, {
    key: 'visa',
    tone: 'orange',
    tag: 'For your maid',
    tagColor: 'orange',
    title: '2-year maid visa',
    sub: 'Done on WhatsApp in 5 minutes. Ready in 7 days.',
    bullets: ['No deposit, no cancellation fee', 'Emirates ID, medical, WPS payroll', '2-year medical insurance included'],
    priceFrom: '8,500',
    priceUnit: '+ 160/mo',
    ctaLabel: 'Get a maid visa',
    waMsg: 'Hi maids.cc — I want a 2-year maid visa.',
    mediaLabel: 'Photo or video · maid holding her Emirates ID',
    mediaSrc: 'assets/visa-hero.png',
    mediaPos: '50% 22%'
  }, {
    key: 'overseas',
    tone: 'orange',
    tag: 'From abroad',
    tagColor: 'orange',
    title: 'Bring a maid from abroad',
    sub: 'Anywhere in the world to the UAE — visas, flights, taxis, paperwork.',
    bullets: ['100% arrival guarantee or money back', 'Arrival in 10–50 days, by nationality', 'Fully online · no office visits'],
    quoteOnly: true,
    priceUnit: 'depends on country',
    ctaLabel: 'Get instant quote',
    waMsg: "Hi maids.cc — I want to bring a maid from overseas. What's the price?",
    mediaLabel: 'Photo or video · maid arriving at DXB',
    mediaSrc: 'assets/overseas-hero.png',
    mediaPos: '50% 30%'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "services",
    id: "products"
  }, /*#__PURE__*/React.createElement("div", {
    className: "services-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "What do you need?"), /*#__PURE__*/React.createElement("h2", null, "Pick one. We\u2019ll take it from there."), /*#__PURE__*/React.createElement("p", null, "Every option includes Tadbeer licensing, 24/7 support, and the same all-in pricing promise \u2014 no hidden fees.")), /*#__PURE__*/React.createElement("div", {
    className: "service-grid"
  }, products.map((p, i) => /*#__PURE__*/React.createElement("article", {
    key: p.key,
    id: p.key,
    className: 'service-block tone-' + p.tone
  }, /*#__PURE__*/React.createElement("div", {
    className: "service-block-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "service-block-media"
  }, p.mediaSrc ? /*#__PURE__*/React.createElement("img", {
    className: "media-photo",
    src: p.mediaSrc,
    alt: p.mediaLabel,
    loading: "lazy",
    decoding: "async",
    style: {
      objectPosition: p.mediaPos || 'center'
    }
  }) : /*#__PURE__*/React.createElement("div", {
    className: 'media-frame media-frame-' + p.tone
  }, /*#__PURE__*/React.createElement("span", {
    className: "media-label"
  }, p.mediaLabel), /*#__PURE__*/React.createElement("span", {
    className: "media-badge"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "play"
  }), "Add picture or video"))), /*#__PURE__*/React.createElement("div", {
    className: "service-block-content"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'service-tag service-tag-' + p.tagColor
  }, p.tag), /*#__PURE__*/React.createElement("h3", null, p.title), /*#__PURE__*/React.createElement("p", {
    className: "service-sub"
  }, p.sub), /*#__PURE__*/React.createElement("ul", {
    className: "service-bullets"
  }, p.bullets.map((b, j) => /*#__PURE__*/React.createElement("li", {
    key: j
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check-circle"
  }), /*#__PURE__*/React.createElement("span", null, b)))), /*#__PURE__*/React.createElement("div", {
    className: "service-price"
  }, p.quoteOnly ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "sp-quote"
  }, "Quote in chat"), /*#__PURE__*/React.createElement("span", {
    className: "sp-unit"
  }, "\xB7 ", p.priceUnit)) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "sp-from"
  }, "From"), /*#__PURE__*/React.createElement("span", {
    className: "sp-amount"
  }, /*#__PURE__*/React.createElement(Dh, {
    size: "0.78em"
  }), p.priceFrom), /*#__PURE__*/React.createElement("span", {
    className: "sp-unit"
  }, p.priceUnit))), /*#__PURE__*/React.createElement("div", {
    className: "service-actions"
  }, /*#__PURE__*/React.createElement("a", {
    href: wa(p.waMsg),
    target: "_blank",
    rel: "noopener",
    className: 'btn btn-tone-' + p.tone + ' btn-lg wa'
  }, /*#__PURE__*/React.createElement(WaIcon, null), p.ctaLabel), /*#__PURE__*/React.createElement("a", {
    href: 'service-' + p.key + '.html',
    className: "service-learn"
  }, "Learn more", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  })))))))));
}

/* Legacy picker grid (kept as a no-op alias for any imports) */
function ProductPicker_Legacy() {
  const products = [{
    key: 'fulltime',
    tone: 'blue',
    tag: 'Most popular',
    tagColor: 'blue',
    title: 'Full-time maid',
    sub: 'Live-in or live-out. Filipinas, Africans, Ethiopians, or Indians.',
    bullets: ['300+ available maids, ready today', '7-day money-back guarantee', 'Unlimited free replacements'],
    priceFrom: '2,980',
    priceUnit: '/month',
    ctaLabel: 'Hire a maid',
    ctaTone: 'primary',
    waMsg: 'Hi maids.cc — I want to hire a full-time maid.',
    photoLabel: 'Photo · maid arriving home'
  }, {
    key: 'parttime',
    tone: 'green',
    tag: 'Hourly',
    tagColor: 'green',
    title: 'Part-time maid or nanny',
    sub: 'Same maid guaranteed. Childcare, elderly, pet care, cooking.',
    bullets: ['Up to 15% off on multi-visit packages', '100% satisfaction or money back', 'Add-ons at no extra charge'],
    priceFrom: '35',
    priceUnit: '/hour',
    ctaLabel: 'Book part-time',
    ctaTone: 'primary',
    waMsg: 'Hi maids.cc — I want to book a part-time maid.',
    photoLabel: 'Photo · maid waving'
  }, {
    key: 'visa',
    tone: 'orange',
    tag: 'For your maid',
    tagColor: 'orange',
    title: '2-year maid visa',
    sub: 'Done on WhatsApp in 5 minutes. Ready in 7 days.',
    bullets: ['No deposit, no cancellation fee', 'Emirates ID, medical, WPS payroll', '2-year medical insurance included'],
    priceFrom: '8,500',
    priceUnit: '+ 160/mo',
    ctaLabel: 'Get a maid visa',
    ctaTone: 'accent',
    waMsg: 'Hi maids.cc — I want a 2-year maid visa.',
    photoLabel: 'Photo · maid holding her EID',
    photoSrc: 'assets/visa-hero.png',
    photoPos: '50% 22%'
  }, {
    key: 'overseas',
    tone: 'orange',
    tag: 'From abroad',
    tagColor: 'orange',
    title: 'Bring a maid from abroad',
    sub: 'Anywhere in the world to the UAE — visas, flights, taxis, paperwork.',
    bullets: ['100% arrival guarantee or money back', 'Arrival in 10–50 days, by nationality', 'Fully online · no office visits'],
    quoteOnly: true,
    priceUnit: 'depends on country',
    ctaLabel: 'Get instant quote',
    ctaTone: 'accent',
    waMsg: "Hi maids.cc — I want to bring a maid from overseas. What's the price?",
    photoLabel: 'Photo · maid arriving at DXB'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "picker",
    id: "products"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "picker-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "What do you need?"), /*#__PURE__*/React.createElement("h2", null, "Pick one. We\u2019ll take it from there."), /*#__PURE__*/React.createElement("p", null, "Every option includes Tadbeer licensing, our 24/7 support team, and the same all-in pricing promise: no hidden fees, no surprise charges.")), /*#__PURE__*/React.createElement("div", {
    className: "picker-grid"
  }, products.map(p => /*#__PURE__*/React.createElement("article", {
    key: p.key,
    className: 'picker-card tone-' + p.tone,
    id: p.key
  }, /*#__PURE__*/React.createElement(Picture, {
    label: p.photoLabel,
    src: p.photoSrc,
    pos: p.photoPos,
    tone: p.tone === 'orange' ? 'orange' : 'blue',
    passive: "bottom",
    rounded: "none",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "picker-card-overlay"
  }), /*#__PURE__*/React.createElement("div", {
    className: "picker-card-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'picker-tag tag-' + p.tagColor
  }, p.tag), /*#__PURE__*/React.createElement("h3", null, p.title), /*#__PURE__*/React.createElement("p", {
    className: "pc-sub"
  }, p.sub), /*#__PURE__*/React.createElement("ul", null, p.bullets.map((b, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  }), /*#__PURE__*/React.createElement("span", null, b)))), /*#__PURE__*/React.createElement("div", {
    className: "picker-foot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "picker-price"
  }, p.quoteOnly ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "pp-from"
  }, "Price"), /*#__PURE__*/React.createElement("span", {
    className: "pp-amount pp-quote"
  }, "Quote in chat"), /*#__PURE__*/React.createElement("span", {
    className: "pp-unit"
  }, "\xB7 ", p.priceUnit)) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "pp-from"
  }, "From"), /*#__PURE__*/React.createElement("span", {
    className: "pp-amount"
  }, /*#__PURE__*/React.createElement(Dh, {
    size: "0.78em"
  }), p.priceFrom), /*#__PURE__*/React.createElement("span", {
    className: "pp-unit"
  }, p.priceUnit))), /*#__PURE__*/React.createElement("a", {
    href: wa(p.waMsg),
    target: "_blank",
    rel: "noopener",
    className: 'btn btn-tone-' + p.tone + ' wa'
  }, /*#__PURE__*/React.createElement(WaIcon, null), p.ctaLabel)), /*#__PURE__*/React.createElement("a", {
    href: 'service-' + p.key + '.html',
    className: "picker-learn"
  }, "Learn more", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  }))))))));
}

/* ========================================================================
   TEAM SLIDESHOW — crossfading photos of the real maids.cc team.
   Auto-advances, pauses on hover, dots to jump, respects reduced-motion.
   Sits in the About editorial frame (4/5, rounded-xl, shadow-md).
   ======================================================================== */
const TEAM_SLIDES = [{
  src: 'assets/team/team-1.jpg',
  pos: 'center 42%',
  caption: 'The whole team, under the Dubai stars'
}, {
  src: 'assets/team/team-6.jpg',
  pos: 'center 30%',
  caption: 'Heads-down on the floor'
}, {
  src: 'assets/team/team-4.jpg',
  pos: 'center 35%',
  caption: 'Training day'
}, {
  src: 'assets/team/team-2.jpg',
  pos: 'center 45%',
  caption: 'Friday five-a-side'
}, {
  src: 'assets/team/team-5.png',
  pos: 'center 22%',
  caption: 'Off the clock, on the slopes'
}, {
  src: 'assets/team/team-3.jpg',
  pos: 'center 40%',
  caption: 'Team dinner'
}, {
  src: 'assets/team/team-7.jpg',
  pos: 'center 45%',
  caption: 'Breaking bread together'
}];
function TeamSlideshow({
  slides = TEAM_SLIDES,
  interval = 4500,
  ratio = '4/5',
  rounded = 'xl'
}) {
  const [i, setI] = React.useState(0);
  const [paused, setPaused] = React.useState(false);
  const radius = {
    none: 0,
    sm: 8,
    md: 16,
    lg: 23,
    xl: 32,
    full: 999
  }[rounded] ?? 32;
  const reduced = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  React.useEffect(() => {
    if (paused || reduced || slides.length < 2) return;
    const t = setInterval(() => setI(p => (p + 1) % slides.length), interval);
    return () => clearInterval(t);
  }, [paused, reduced, slides.length, interval]);
  return /*#__PURE__*/React.createElement("div", {
    className: "team-slideshow",
    style: {
      position: 'relative',
      aspectRatio: ratio,
      width: '100%',
      borderRadius: radius,
      overflow: 'hidden',
      boxShadow: 'var(--shadow-md)',
      background: '#25499B'
    },
    onMouseEnter: () => setPaused(true),
    onMouseLeave: () => setPaused(false),
    role: "group",
    "aria-roledescription": "carousel",
    "aria-label": "maids.cc team photos"
  }, slides.map((s, idx) => /*#__PURE__*/React.createElement("img", {
    key: s.src,
    src: s.src,
    alt: s.caption,
    loading: idx === 0 ? 'eager' : 'lazy',
    decoding: "async",
    "aria-hidden": idx !== i,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: s.pos || 'center',
      display: 'block',
      opacity: idx === i ? 1 : 0,
      transition: reduced ? 'none' : 'opacity 900ms var(--ease-standard)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      height: '38%',
      background: 'linear-gradient(to top, rgba(15,30,68,0.72), rgba(15,30,68,0))',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "ts-caption",
    "aria-live": "polite",
    style: {
      position: 'absolute',
      left: 18,
      bottom: 16,
      right: 90,
      color: '#fff',
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 14,
      lineHeight: 1.25,
      textShadow: '0 1px 6px rgba(0,0,0,0.4)'
    }
  }, slides[i].caption), /*#__PURE__*/React.createElement("div", {
    className: "ts-dots",
    role: "tablist",
    style: {
      position: 'absolute',
      right: 16,
      bottom: 18,
      display: 'flex',
      gap: 7
    }
  }, slides.map((s, idx) => /*#__PURE__*/React.createElement("button", {
    key: s.src,
    type: "button",
    role: "tab",
    "aria-selected": idx === i,
    "aria-label": 'Show photo ' + (idx + 1) + ': ' + s.caption,
    onClick: () => setI(idx),
    style: {
      width: idx === i ? 22 : 8,
      height: 8,
      padding: 0,
      border: 'none',
      cursor: 'pointer',
      borderRadius: 999,
      background: idx === i ? '#fff' : 'rgba(255,255,255,0.5)',
      transition: 'width 300ms var(--ease-standard), background 300ms var(--ease-standard)'
    }
  }))));
}

/* ========================================================================
   ABOUT — my take: editorial split, not just one stat sentence.
   ======================================================================== */
function About() {
  return /*#__PURE__*/React.createElement("section", {
    className: "about about-split",
    id: "about"
  }, /*#__PURE__*/React.createElement("div", {
    className: "about-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "about-photo"
  }, /*#__PURE__*/React.createElement(TeamSlideshow, {
    ratio: "4/5",
    rounded: "xl"
  })), /*#__PURE__*/React.createElement("div", {
    className: "about-copy"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "About us"), /*#__PURE__*/React.createElement("h2", null, "We\u2019re the team behind ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, "30,000 maids and nannies.")), /*#__PURE__*/React.createElement("p", null, "We\u2019re Tadbeer-licensed under the UAE Ministry of Human Resources & Emiratization. We sponsor the visas, run the payroll, handle the medicals, and lift the bans. You pay one monthly number; we carry the rest."), /*#__PURE__*/React.createElement("div", {
    className: "about-stats"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-num"
  }, "30K", /*#__PURE__*/React.createElement("span", {
    className: "plus"
  }, "+")), /*#__PURE__*/React.createElement("div", {
    className: "as-label"
  }, "On our payroll \xB7 2nd-largest UAE employer")), /*#__PURE__*/React.createElement("div", {
    className: "as-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-num"
  }, "15K", /*#__PURE__*/React.createElement("span", {
    className: "plus"
  }, "+")), /*#__PURE__*/React.createElement("div", {
    className: "as-label"
  }, "Google reviews \xB7 4.8\u2605 public record")), /*#__PURE__*/React.createElement("div", {
    className: "as-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-num"
  }, "2009"), /*#__PURE__*/React.createElement("div", {
    className: "as-label"
  }, "Year founded \xB7 Tadbeer-licensed"))))));
}

/* ========================================================================
   PRICING TABLET — the AED 2,980 mega-number, broken down.
   Sells transparency: shows exactly what's bundled into the monthly price.
   ======================================================================== */
function Pricing() {
  const breakdown = [{
    item: 'Salary',
    color: 'blue'
  }, {
    item: '2-year UAE visa',
    color: 'blue'
  }, {
    item: 'Emirates ID + medical',
    color: 'blue'
  }, {
    item: 'Government fees',
    color: 'blue'
  }, {
    item: 'WPS payroll',
    color: 'blue'
  }, {
    item: 'Ubers to and from work',
    color: 'green'
  }, {
    item: 'Free ironing, fridge, windows',
    color: 'green'
  }, {
    item: 'Free replacements',
    color: 'green'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "pricing",
    id: "pricing"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pricing-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "One price. Everything in."), /*#__PURE__*/React.createElement("h2", null, "From ", /*#__PURE__*/React.createElement(Dh, {
    size: "0.78em"
  }), /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, "2,980"), "/month.", /*#__PURE__*/React.createElement("br", null), "Nothing else, ever."), /*#__PURE__*/React.createElement("p", null, "Most agencies hide the visa, the medical, the typist runs, the Ubers, and a dozen \u201Cgovernment fees\u201D that aren't government fees. We bundle it all into one monthly number and refund the difference if anything we miss isn't covered.")), /*#__PURE__*/React.createElement("div", {
    className: "pricing-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pc-headline"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pc-from"
  }, "From"), /*#__PURE__*/React.createElement("span", {
    className: "pc-amount"
  }, /*#__PURE__*/React.createElement(Dh, {
    size: "0.6em"
  }), "2,980"), /*#__PURE__*/React.createElement("span", {
    className: "pc-unit"
  }, "/ month")), /*#__PURE__*/React.createElement("div", {
    className: "pc-divider"
  }), /*#__PURE__*/React.createElement("div", {
    className: "pc-list"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pc-col"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pc-col-h"
  }, "Included \u2014 always"), breakdown.filter(b => b.color === 'blue').map(b => /*#__PURE__*/React.createElement("div", {
    className: "pc-row",
    key: b.item
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  }), /*#__PURE__*/React.createElement("span", null, b.item)))), /*#__PURE__*/React.createElement("div", {
    className: "pc-col"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pc-col-h"
  }, "Plus, free of charge"), breakdown.filter(b => b.color === 'green').map(b => /*#__PURE__*/React.createElement("div", {
    className: "pc-row plus",
    key: b.item
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "plus"
  }), /*#__PURE__*/React.createElement("span", null, b.item))))), /*#__PURE__*/React.createElement("div", {
    className: "pc-foot"
  }, /*#__PURE__*/React.createElement("a", {
    href: "hire.html",
    className: "btn btn-accent btn-lg"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "zap"
  }), "Sign & pay \u2014 5 min"), /*#__PURE__*/React.createElement("span", {
    className: "pc-foot-sub"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shield-check"
  }), "7-day money-back. If we miss something on this list, we eat the cost.")))));
}

/* ========================================================================
   COMPARISON — the wedge: us vs traditional agency vs hire-direct
   ======================================================================== */
function Comparison() {
  const rows = [{
    row: 'Sign &amp; pay online',
    a: 'In 5 minutes',
    b: 'After 2 office visits',
    c: 'You handle it'
  }, {
    row: 'Visa, EID, medical',
    a: 'All handled by us',
    b: 'You drive her around',
    c: 'You handle it'
  }, {
    row: 'Replace if she doesn’t fit',
    a: 'Unlimited · free',
    b: 'One-time · fee',
    c: 'Start over'
  }, {
    row: 'Cancel anytime',
    a: 'Yes · monthly',
    b: 'No · 2-yr contract',
    c: 'No'
  }, {
    row: 'Hidden fees',
    a: 'None',
    b: 'Multiple',
    c: '—'
  }, {
    row: 'After-hours support',
    a: '24/7 · real person',
    b: 'Office hours',
    c: '—'
  }];
  const cols = [{
    key: 'a',
    label: 'Maids.cc',
    tag: 'You',
    good: true
  }, {
    key: 'b',
    label: 'Traditional agency',
    tag: 'Them',
    good: false
  }, {
    key: 'c',
    label: 'Hire direct',
    tag: 'DIY',
    good: false
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "comparison",
    id: "compare"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-head left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Why families switch"), /*#__PURE__*/React.createElement("h2", null, "The transparency wedge."), /*#__PURE__*/React.createElement("p", null, "What you actually get with us, vs. what a traditional agency or hiring direct gives you. No marketing fluff \u2014 line items only.")), /*#__PURE__*/React.createElement("div", {
    className: "compare-table"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct-row-label"
  }, "\xA0"), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.key,
    className: 'ct-col-head' + (c.good ? ' good' : '')
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-col-tag"
  }, c.tag), /*#__PURE__*/React.createElement("span", {
    className: "ct-col-name"
  }, c.label)))), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "ct-row",
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct-row-label",
    dangerouslySetInnerHTML: {
      __html: r.row
    }
  }), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.key,
    className: 'ct-cell' + (c.good ? ' good' : '')
  }, c.good && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check-circle",
    className: "ct-icon-good"
  }), !c.good && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    className: "ct-icon-bad"
  }), /*#__PURE__*/React.createElement("span", {
    dangerouslySetInnerHTML: {
      __html: r[c.key]
    }
  }))))))));
}

/* ========================================================================
   MAID GALLERY — placeholder cards, the actual product mechanic.
   layout: 'stagger' (hero) | 'grid' (section) | 'strip' (inline)
   ======================================================================== */
function MaidGallery({
  layout = 'grid',
  count = 6,
  intro
}) {
  const items = MAIDS_GALLERY.slice(0, count);
  const [active, setActive] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", {
    className: 'maid-gallery layout-' + layout
  }, intro && /*#__PURE__*/React.createElement("div", {
    className: "maid-gallery-intro"
  }, /*#__PURE__*/React.createElement("h2", null, intro.title), /*#__PURE__*/React.createElement("p", null, intro.sub)), /*#__PURE__*/React.createElement("div", {
    className: "maid-gallery-grid"
  }, items.map(m => /*#__PURE__*/React.createElement(MaidCard, {
    key: m.id,
    maid: m,
    onSelect: setActive
  }))), /*#__PURE__*/React.createElement(MaidVideoModal, {
    maid: active,
    onClose: () => setActive(null)
  }));
}
function MaidCard({
  maid,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "maid-card",
    onClick: () => onSelect(maid),
    "aria-label": `Watch ${maid.name}'s video intro`
  }, /*#__PURE__*/React.createElement("div", {
    className: "maid-photo"
  }, /*#__PURE__*/React.createElement(Picture, {
    label: `Maid · ${maid.nat}`,
    src: maid.photo,
    pos: maid.pos || 'center',
    tone: "blue",
    passive: "none",
    rounded: "none",
    ratio: "3/4"
  }), /*#__PURE__*/React.createElement("div", {
    className: "maid-pill"
  }, maid.tag), /*#__PURE__*/React.createElement("div", {
    className: "maid-play"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "play"
  })), /*#__PURE__*/React.createElement("div", {
    className: "maid-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "maid-name"
  }, maid.name), /*#__PURE__*/React.createElement("div", {
    className: "maid-meta"
  }, maid.nat, " \xB7 ", maid.exp), maid.expertise && /*#__PURE__*/React.createElement("div", {
    className: "maid-expertise"
  }, maid.expertise))));
}

/* Video-intro lightbox — opens on card click, ends in a WhatsApp CTA to book
   this specific maid. Video is a poster placeholder until real intros land. */
function MaidVideoModal({
  maid,
  onClose
}) {
  React.useEffect(() => {
    if (!maid) return;
    lucide.createIcons();
    const onKey = e => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [maid]);
  if (!maid) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "maid-modal-backdrop",
    onClick: onClose,
    role: "dialog",
    "aria-modal": "true",
    "aria-label": `${maid.name} — video intro`
  }, /*#__PURE__*/React.createElement("div", {
    className: "maid-modal",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "maid-modal-close",
    onClick: onClose,
    "aria-label": "Close"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x"
  })), /*#__PURE__*/React.createElement("div", {
    className: "maid-modal-video"
  }, /*#__PURE__*/React.createElement(Picture, {
    label: `Video · ${maid.name}`,
    src: maid.photo,
    pos: maid.pos || 'center',
    tone: "blue",
    passive: "none",
    rounded: "none",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "mm-videotag"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "video"
  }), "Video intro"), /*#__PURE__*/React.createElement("div", {
    className: "mm-play"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "play"
  })), /*#__PURE__*/React.createElement("div", {
    className: "mm-pill"
  }, maid.tag)), /*#__PURE__*/React.createElement("div", {
    className: "maid-modal-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mm-name"
  }, maid.name), /*#__PURE__*/React.createElement("div", {
    className: "mm-meta"
  }, maid.nat, " \xB7 ", maid.exp), maid.expertise && /*#__PURE__*/React.createElement("div", {
    className: "mm-expertise"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check-circle"
  }), /*#__PURE__*/React.createElement("span", null, maid.expertise)), /*#__PURE__*/React.createElement("a", {
    href: wa(`Hi maids.cc — I'd like to hire ${maid.name} (${maid.nat}). Is she available?`),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-wa btn-lg mm-cta"
  }, /*#__PURE__*/React.createElement(WaIcon, null), "Hire ", maid.name, " on WhatsApp"), /*#__PURE__*/React.createElement("div", {
    className: "mm-reassure"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shield-check"
  }), /*#__PURE__*/React.createElement("span", null, "7-day money-back \xB7 unlimited free replacements")))));
}

/* ========================================================================
   PRESS STRIP — "As featured in"
   ======================================================================== */
function PressStrip() {
  const press = [{
    name: 'Khaleej Times',
    url: 'https://www.khaleejtimes.com',
    quote: 'Agencies like maids.cc save time, prevent hidden costs, and eliminate legal risks — offering better value and full compliance.',
    cite: 'Khaleej Times · Legal Affairs'
  }, {
    name: 'Gulf News',
    url: 'https://gulfnews.com',
    quote: 'Among the largest private-sector employers in the country, with tens of thousands of domestic workers on fully sponsored, compliant contracts.',
    cite: 'Gulf News · Business Desk'
  }, {
    name: 'The National',
    url: 'https://www.thenationalnews.com',
    quote: 'A technology-led model that handles visas, payroll and replacements end to end — turning a famously painful process into a few taps.',
    cite: 'The National · Future of Work'
  }, {
    name: 'Tadbeer · UAE Ministry',
    url: 'https://www.mohre.gov.ae',
    quote: 'Licensed under the Tadbeer framework of the Ministry of Human Resources & Emiratisation, operating within full regulatory compliance.',
    cite: 'Tadbeer · UAE MOHRE'
  }, {
    name: 'maids.news',
    url: 'https://maids.news',
    quote: 'Same-day hiring, unlimited free replacements and a 4.8★ public record across 15,000+ reviews — a new benchmark for the category.',
    cite: 'maids.news · Editorial'
  }];
  const [active, setActive] = React.useState(0);
  const cur = press[active];
  React.useEffect(() => {
    if (window.lucide) lucide.createIcons();
  }, [active]);
  return /*#__PURE__*/React.createElement("section", {
    className: "press"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "press-label"
  }, "As featured in"), /*#__PURE__*/React.createElement("div", {
    className: "press-logos",
    role: "tablist",
    "aria-label": "Press coverage"
  }, press.map((p, i) => /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'press-logo' + (i === active ? ' active' : ''),
    key: p.name,
    onClick: () => setActive(i),
    "aria-pressed": i === active
  }, p.name))), /*#__PURE__*/React.createElement("blockquote", {
    className: "press-quote",
    key: active
  }, /*#__PURE__*/React.createElement("span", {
    className: "pq-mark"
  }, "\u201C"), cur.quote, /*#__PURE__*/React.createElement("a", {
    className: "pq-cite",
    href: cur.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, "\u2014 ", cur.cite, " ", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-up-right"
  })))));
}

/* ========================================================================
   TRUST STRIP — real numbers from the live site
   ======================================================================== */
function TrustStrip() {
  return /*#__PURE__*/React.createElement("section", {
    className: "trust"
  }, /*#__PURE__*/React.createElement("div", {
    className: "trust-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "trust-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "num"
  }, "30K", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--maids-orange)'
    }
  }, "+")), /*#__PURE__*/React.createElement("div", {
    className: "lbl"
  }, "On payroll \xB7 2nd-largest in UAE")), /*#__PURE__*/React.createElement("div", {
    className: "trust-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "num"
  }, "4.8", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--maids-orange)'
    }
  }, "\u2605")), /*#__PURE__*/React.createElement("div", {
    className: "lbl"
  }, "15K reviews on Google")), /*#__PURE__*/React.createElement("div", {
    className: "trust-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "num"
  }, "5", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--maids-orange)'
    }
  }, "min")), /*#__PURE__*/React.createElement("div", {
    className: "lbl"
  }, "Sign & pay online \u2014 that's it")), /*#__PURE__*/React.createElement("div", {
    className: "trust-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "num"
  }, "7d"), /*#__PURE__*/React.createElement("div", {
    className: "lbl"
  }, "Visa, end-to-end"))));
}

/* ========================================================================
   SERVICE SECTION — kept structure; each gets a passive-zone hero picture.
   ======================================================================== */
function ServiceSection({
  service,
  index,
  alt
}) {
  const s = service;
  const Lede = s.lede;
  return /*#__PURE__*/React.createElement("section", {
    className: 'service-section' + (alt ? ' alt' : ''),
    id: s.anchor
  }, /*#__PURE__*/React.createElement("div", {
    className: "service-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "service-copy"
  }, /*#__PURE__*/React.createElement("div", {
    className: "service-tag"
  }, /*#__PURE__*/React.createElement("span", {
    className: "service-num"
  }, "0", index), /*#__PURE__*/React.createElement("span", {
    className: "service-icon"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": s.icon
  })), /*#__PURE__*/React.createElement("span", {
    className: "service-eyebrow"
  }, s.label)), /*#__PURE__*/React.createElement("h2", null, s.headline.pre, " ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, s.headline.accent), " ", s.headline.post), /*#__PURE__*/React.createElement("p", {
    className: "lede"
  }, /*#__PURE__*/React.createElement(Lede, null)), /*#__PURE__*/React.createElement("div", {
    className: "chips"
  }, s.chips.map(c => /*#__PURE__*/React.createElement("span", {
    className: "chip",
    key: c
  }, c))), /*#__PURE__*/React.createElement("ul", {
    className: "bullets"
  }, s.bullets.map((b, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  }), /*#__PURE__*/React.createElement("span", null, b)))), /*#__PURE__*/React.createElement("div", {
    className: "service-cta"
  }, /*#__PURE__*/React.createElement("a", {
    href: "hire.html",
    className: "btn btn-accent btn-lg"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "zap"
  }), s.primaryCtaLabel), /*#__PURE__*/React.createElement("a", {
    href: wa(s.waMsg),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-ghost btn-lg"
  }, /*#__PURE__*/React.createElement(WaIcon, null), s.secondaryCtaLabel)), /*#__PURE__*/React.createElement("span", {
    className: "service-cta-sub"
  }, "No medical centers \xB7 no typists \xB7 cancel anytime.")), /*#__PURE__*/React.createElement("div", {
    className: "service-visual"
  }, /*#__PURE__*/React.createElement(Picture, {
    label: s.key === 'visa' ? 'Photo · maid receiving documents' : s.key === 'nannies' ? 'Photo · nanny with kids at home' : 'Photo · maid working in a UAE home',
    tone: "blue",
    passive: "bottom",
    rounded: "xl",
    ratio: "4/5"
  }), /*#__PURE__*/React.createElement("div", {
    className: "service-card-overlay"
  }, /*#__PURE__*/React.createElement("div", {
    className: "service-card-tag"
  }, "From"), /*#__PURE__*/React.createElement("div", {
    className: "service-card-price"
  }, /*#__PURE__*/React.createElement(Dh, {
    size: "0.78em"
  }), s.priceLine.from, /*#__PURE__*/React.createElement("span", {
    className: "service-card-unit"
  }, s.priceLine.unit)), s.priceLine.or && /*#__PURE__*/React.createElement("div", {
    className: "service-card-or"
  }, "or ", /*#__PURE__*/React.createElement(Dh, {
    size: "0.72em"
  }), s.priceLine.or, /*#__PURE__*/React.createElement("span", {
    className: "service-card-unit"
  }, s.priceLine.orUnit)), /*#__PURE__*/React.createElement("div", {
    className: "service-card-divider"
  }), /*#__PURE__*/React.createElement("div", {
    className: "service-card-stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "service-card-stat-v"
  }, s.proofStat.v), /*#__PURE__*/React.createElement("div", {
    className: "service-card-stat-l"
  }, s.proofStat.l)), /*#__PURE__*/React.createElement("div", {
    className: "service-card-foot"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shield-check"
  }), /*#__PURE__*/React.createElement("span", null, s.cardFoot))))));
}

/* ========================================================================
   HOW IT WORKS — rewritten to match the live product flow
   ======================================================================== */
function HowItWorks() {
  const steps = [{
    n: '01',
    ic: 'play-circle',
    t: 'Browse maid videos',
    d: "Watch profiles, see exactly who you're hiring. 200+ live maids on the site right now."
  }, {
    n: '02',
    ic: 'file-signature',
    t: 'Sign & pay in 5 min',
    d: 'Everything online — contract, ID, payment. No visits to medical centers or typists.'
  }, {
    n: '03',
    ic: 'car-front',
    t: 'We Uber her to you',
    d: "Same day in most cases. She arrives with her documents — you don't lift a finger."
  }, {
    n: '04',
    ic: 'smartphone',
    t: 'Manage in the app',
    d: 'Schedule, payments, replacements, complaints — all in one place. Replace anytime, free.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "section how",
    id: "how"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "How it works"), /*#__PURE__*/React.createElement("h2", null, "Four steps. ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, "No paperwork.")), /*#__PURE__*/React.createElement("p", null, "The whole pipeline is software-driven \u2014 that's how we deliver same-day. No portal to log into, no app required (one is provided if you want it).")), /*#__PURE__*/React.createElement("ol", {
    className: "timeline"
  }, steps.map(st => /*#__PURE__*/React.createElement("li", {
    className: "tl-step",
    key: st.n
  }, /*#__PURE__*/React.createElement("div", {
    className: "tl-rail"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tl-icon"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": st.ic
  }))), /*#__PURE__*/React.createElement("div", {
    className: "tl-body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tl-num"
  }, "Step ", st.n), /*#__PURE__*/React.createElement("h3", null, st.t), /*#__PURE__*/React.createElement("p", null, st.d)))))));
}

/* ========================================================================
   REVIEWS — real reviews from the live site (paraphrased), 4.8 / 14K hook
   ======================================================================== */
function Reviews() {
  const reviews = [{
    stars: 5,
    txt: "Adam was absolutely fantastic. He stepped in and resolved an ongoing issue with our previous maid quickly and professionally.",
    who: 'N · Dubai'
  }, {
    stars: 5,
    txt: "Outstanding experience. Incredibly supportive, understanding, and professional. From the very start, they listened to exactly what we needed.",
    who: 'N · Dubai'
  }, {
    stars: 5,
    txt: "Highly recommend for families looking for nannies. Very impressed with their responsiveness and genuine care for the children.",
    who: 'Y · Dubai'
  }, {
    stars: 5,
    txt: "Same-day delivery was real — we signed in the morning and she arrived that afternoon with all her documents in order.",
    who: 'R · Abu Dhabi'
  }, {
    stars: 5,
    txt: "When the first maid wasn't the right fit, the free replacement was painless. A new candidate was arranged within days, no fees.",
    who: 'S · Sharjah'
  }, {
    stars: 5,
    txt: "Support actually replies. I messaged on a Sunday evening and got a real person within minutes — not a bot loop.",
    who: 'L · Dubai'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "reviews",
    id: "reviews"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "reviews-head"
  }, /*#__PURE__*/React.createElement("a", {
    className: "reviews-rating",
    href: GOOGLE_REVIEWS_URL,
    target: "_blank",
    rel: "noopener",
    title: "See live reviews on Google"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rr-brand"
  }, /*#__PURE__*/React.createElement("svg", {
    className: "rr-glogo",
    viewBox: "0 0 272 92",
    role: "img",
    "aria-label": "Google",
    focusable: "false"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "#EA4335",
    d: "M115.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18C71.25 34.32 81.24 25 93.5 25s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44S80.99 39.2 80.99 47.18c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#FBBC05",
    d: "M163.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18c0-12.85 9.99-22.18 22.25-22.18s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44s-12.51 5.46-12.51 13.44c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#4285F4",
    d: "M209.75 26.34v39.82c0 16.38-9.66 23.07-21.08 23.07-10.75 0-17.22-7.19-19.66-13.07l8.48-3.53c1.51 3.61 5.21 7.87 11.17 7.87 7.31 0 11.84-4.51 11.84-13v-3.19h-.34c-2.18 2.69-6.38 5.04-11.68 5.04-11.09 0-21.25-9.66-21.25-22.09 0-12.52 10.16-22.26 21.25-22.26 5.29 0 9.49 2.35 11.68 4.96h.34v-3.61h9.25zm-8.56 20.92c0-7.81-5.21-13.52-11.84-13.52-6.72 0-12.35 5.71-12.35 13.52 0 7.73 5.63 13.36 12.35 13.36 6.63 0 11.84-5.63 11.84-13.36z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#34A853",
    d: "M225 3v65h-9.5V3h9.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#EA4335",
    d: "M262.02 54.48l7.56 5.04c-2.44 3.61-8.32 9.83-18.48 9.83-12.6 0-22.01-9.74-22.01-22.18 0-13.19 9.49-22.18 20.92-22.18 11.51 0 17.14 9.16 18.98 14.11l1.01 2.52-29.65 12.28c2.27 4.45 5.8 6.72 10.75 6.72 4.96 0 8.4-2.44 10.92-6.04zm-23.27-7.98l19.82-8.23c-1.09-2.77-4.37-4.7-8.23-4.7-4.95 0-11.84 4.37-11.59 12.93z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#4285F4",
    d: "M35.29 41.41V32H67c.31 1.64.47 3.58.47 5.68 0 7.06-1.93 15.79-8.15 22.01-6.05 6.3-13.78 9.66-24.02 9.66C16.32 69.35.36 53.89.36 34.91.36 15.93 16.32.47 35.3.47c10.5 0 17.98 4.12 23.6 9.49l-6.64 6.64c-4.03-3.78-9.49-6.72-16.97-6.72-13.86 0-24.7 11.17-24.7 25.03 0 13.86 10.84 25.03 24.7 25.03 8.99 0 14.11-3.61 17.39-6.89 2.66-2.66 4.41-6.46 5.1-11.65l-22.49.01z"
  })), /*#__PURE__*/React.createElement("span", {
    className: "rr-brand-label"
  }, "Reviews")), /*#__PURE__*/React.createElement("div", {
    className: "rr-rate"
  }, /*#__PURE__*/React.createElement("span", {
    className: "rr-score"
  }, "4.8"), /*#__PURE__*/React.createElement("span", {
    className: "rr-stars",
    style: {
      '--pct': '96%'
    },
    "aria-label": "4.8 out of 5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "rr-stars-track"
  }, "\u2605\u2605\u2605\u2605\u2605"), /*#__PURE__*/React.createElement("span", {
    className: "rr-stars-fill"
  }, "\u2605\u2605\u2605\u2605\u2605"))), /*#__PURE__*/React.createElement("div", {
    className: "rr-count"
  }, "Based on ", /*#__PURE__*/React.createElement("b", null, "15,000+"), " reviews"), /*#__PURE__*/React.createElement("div", {
    className: "rr-sub"
  }, "Read them on Google ", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-up-right"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "reviews-quote"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "15 thousand families. Counting."), /*#__PURE__*/React.createElement("h2", null, "Real reviews. Public record."), /*#__PURE__*/React.createElement("p", null, "We can't curate Google. These are the actual reviews \u2014 the good, the bad, the long ones \u2014 at maids.cc on Google Maps."))), /*#__PURE__*/React.createElement(ReviewCarousel, {
    reviews: reviews
  })));
}

/* Auto-rotating, swipeable review carousel. Advances on a timer, pauses on
   hover/focus/touch so people can actually read, and supports drag + dots.
   Respects prefers-reduced-motion (no auto-advance). */
function ReviewCarousel({
  reviews
}) {
  const n = reviews.length;
  const [index, setIndex] = React.useState(0);
  const [visible, setVisible] = React.useState(1);
  // Refs so the single auto-advance interval (set up once) always reads the
  // latest pause state and bounds — no teardown/rebuild on every render, which
  // is what was stalling the rotation.
  const pausedRef = React.useRef(false);
  const maxIndexRef = React.useRef(0);
  const drag = React.useRef({
    x: 0,
    active: false
  });
  const pause = () => {
    pausedRef.current = true;
  };
  const resume = () => {
    pausedRef.current = false;
  };
  React.useEffect(() => {
    const mq = window.matchMedia('(min-width: 880px)');
    const update = () => setVisible(mq.matches ? 3 : 1);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);
  const maxIndex = Math.max(0, n - visible);
  maxIndexRef.current = maxIndex;
  React.useEffect(() => {
    setIndex(i => Math.min(i, maxIndex));
  }, [maxIndex]);
  React.useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return;
    const id = setInterval(() => {
      if (pausedRef.current) return;
      setIndex(i => i >= maxIndexRef.current ? 0 : i + 1);
    }, 3800);
    return () => clearInterval(id);
  }, []);
  const go = dir => setIndex(i => {
    const m = maxIndexRef.current;
    const next = i + dir;
    if (next < 0) return m;
    if (next > m) return 0;
    return next;
  });
  const onDown = x => {
    drag.current = {
      x,
      active: true
    };
  };
  const onUp = x => {
    if (!drag.current.active) return;
    drag.current.active = false;
    const dx = x - drag.current.x;
    if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
  };
  const slidePct = 100 / visible;
  return /*#__PURE__*/React.createElement("div", {
    className: "review-carousel",
    onMouseEnter: pause,
    onMouseLeave: resume,
    onFocusCapture: pause,
    onBlurCapture: resume
  }, /*#__PURE__*/React.createElement("div", {
    className: "rcar-viewport",
    onTouchStart: e => {
      pause();
      onDown(e.touches[0].clientX);
    },
    onTouchEnd: e => {
      onUp(e.changedTouches[0].clientX);
      resume();
    },
    onMouseDown: e => onDown(e.clientX),
    onMouseUp: e => onUp(e.clientX)
  }, /*#__PURE__*/React.createElement("div", {
    className: "rcar-track",
    style: {
      transform: `translateX(-${index * slidePct}%)`
    }
  }, reviews.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "rcar-slide",
    style: {
      flexBasis: slidePct + '%',
      maxWidth: slidePct + '%'
    },
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "review-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rc-stars"
  }, '★'.repeat(r.stars)), /*#__PURE__*/React.createElement("blockquote", null, r.txt), /*#__PURE__*/React.createElement("div", {
    className: "rc-who"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "circle-user-round"
  }), r.who, " \xB7 Google review")))))), /*#__PURE__*/React.createElement("div", {
    className: "rcar-controls"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "rcar-arrow",
    onClick: () => go(-1),
    "aria-label": "Previous reviews"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-left"
  })), /*#__PURE__*/React.createElement("div", {
    className: "rcar-dots"
  }, Array.from({
    length: maxIndex + 1
  }).map((_, i) => /*#__PURE__*/React.createElement("button", {
    type: "button",
    key: i,
    className: 'rcar-dot' + (i === index ? ' active' : ''),
    onClick: () => setIndex(i),
    "aria-label": `Go to review group ${i + 1}`
  }))), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "rcar-arrow",
    onClick: () => go(1),
    "aria-label": "Next reviews"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-right"
  }))));
}

/* ========================================================================
   REASSURE — kept; refined copy
   ======================================================================== */
function Reassure() {
  const items = [{
    ic: 'shield-check',
    t: 'Cancel anytime',
    d: 'Monthly contracts, no long lock-ins. Full-time turns into hourly if needs change.'
  }, {
    ic: 'repeat',
    t: 'Unlimited free replacements',
    d: "If she doesn't fit, we send another. No fee, no questions, no awkward calls."
  }, {
    ic: 'whatsapp',
    t: '24/7 real-person support',
    d: 'Four languages, real humans, replies in minutes — evenings, weekends, holidays.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "reassure-band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "reassure-grid"
  }, items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    className: "reassure-card",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "reassure-icon"
  }, it.ic === 'whatsapp' ? /*#__PURE__*/React.createElement(WaIcon, {
    size: "1.4em"
  }) : /*#__PURE__*/React.createElement("i", {
    "data-lucide": it.ic
  })), /*#__PURE__*/React.createElement("h3", null, it.t), /*#__PURE__*/React.createElement("p", null, it.d))))));
}

/* ========================================================================
   FAQ — dark blue band with slate-blue cards, mirrors live site
   ======================================================================== */
function Faq() {
  const items = [{
    q: 'Are you licensed by the Ministry of Human Resources and Emiratization?',
    a: 'Yes — Tadbeer-licensed. We are an approved domestic worker service center under the Ministry of Human Resources & Emiratization (MOHRE), authorized to recruit, sponsor and place full-time maids and nannies anywhere in the UAE.'
  }, {
    q: 'Why should I use a licensed agency?',
    a: 'Hiring direct exposes you to the costs of a failed medical, a runaway, a banned passport, or a worker without the right paperwork. A licensed agency carries those risks for you — we replace at our cost, lift bans, run the payroll, and stand between you and the government processes.'
  }, {
    q: 'How much do your services cost?',
    a: 'Full-time maid: from AED 2,980/month all-in (salary + visa + medicals + Ubers + government fees). 2-year maid visa: AED 8,500 upfront + 160/month, or AED 10,960 + 0/month. Hourly help: from AED 35/hour. No hidden fees — the price you see is the price you pay.'
  }, {
    q: 'What documents do I need to use maids.cc services?',
    a: 'Just your Emirates ID and a tenancy contract for your home (or owner\'s deed). Everything else — visa, medical, payroll — we handle.'
  }, {
    q: "What if the maid does not match my family's preferences?",
    a: "Tell us on WhatsApp. We send a replacement — free, every time, unlimited. The 7-day money-back covers the rare case where none of the replacements work for you."
  }, {
    q: 'What if I want to cancel later on?',
    a: "Cancel anytime, no penalty. Monthly contracts — we don't lock you in. If you cancel within the first 7 days, you get a full refund."
  }, {
    q: 'Can you bring my maid from outside the UAE?',
    a: 'Yes. We handle the entire pipeline — embassy paperwork (Philippines, Ethiopia, Kenya, Sri Lanka, Uganda), DMW / GCC approvals, ticket, visa, medical, EID, and arrival.'
  }, {
    q: 'Are there any legal liabilities?',
    a: "No. Because we sponsor the visa, we carry the legal employer obligations — WPS payroll, end-of-service, medical insurance, repatriation. You are simply paying a monthly service fee."
  }, {
    q: 'What are the nationalities of your professionals?',
    a: 'Filipina, Ethiopian, Kenyan, Ugandan, Sri Lankan, and Indian maids and nannies. Tell us your preference on WhatsApp; we send matching profiles within minutes.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "faq faq-dark",
    id: "faq"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "faq-title"
  }, "Frequently Asked Questions"), /*#__PURE__*/React.createElement("div", {
    className: "faq-list"
  }, items.map((it, i) => /*#__PURE__*/React.createElement("details", {
    className: "faq-item",
    key: i
  }, /*#__PURE__*/React.createElement("summary", null, /*#__PURE__*/React.createElement("span", null, it.q), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-down",
    className: "faq-chev"
  })), /*#__PURE__*/React.createElement("p", null, it.a))))));
}

/* ========================================================================
   FINAL CTA BAND — converts on "Sign & pay in 5 min"
   ======================================================================== */
function CtaBand() {
  return /*#__PURE__*/React.createElement("section", {
    className: "cta-band",
    id: "hire"
  }, /*#__PURE__*/React.createElement(Picture, {
    label: "maids.cc maid arriving at your door",
    src: "assets/cta-arriving.jpg",
    pos: "center 28%",
    tone: "blue",
    passive: "center",
    rounded: "none",
    ratio: undefined,
    style: {
      position: 'absolute',
      inset: 0,
      height: '100%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "cta-band-inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Ready when you are."), /*#__PURE__*/React.createElement("h2", null, "Get her in your home ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, "today.")), /*#__PURE__*/React.createElement("p", null, "Sign & pay online in 5 minutes. We'll Uber her to you \u2014 same day in most cases."), /*#__PURE__*/React.createElement("div", {
    className: "cta-band-ctas"
  }, /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc — I want to hire a full-time maid.'),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-accent btn-lg cta-band-btn"
  }, /*#__PURE__*/React.createElement(WaIcon, null), "Chat on WhatsApp \u2014 book in 5 min")), /*#__PURE__*/React.createElement("div", {
    className: "cta-band-sub"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shield-check"
  }), "7-day money-back \xB7 cancel anytime \xB7 4.8 / 15K reviews")));
}
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    className: "footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "footer-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/maids-logo-white.png",
    alt: "Maids.cc",
    style: {
      height: 32
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "lede"
  }, "UAE's largest provider of full-time maids, nannies, and 2-year maid visas. Tadbeer-licensed since 2009. 30,000+ employees."), /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc'),
    target: "_blank",
    rel: "noopener",
    className: "footer-wa"
  }, /*#__PURE__*/React.createElement(WaIcon, null), "+971 800 624 377")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, "Services"), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "service-fulltime.html"
  }, "Full-time maid")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "service-parttime.html"
  }, "Part-time maid & nanny")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "service-visa.html"
  }, "2-year maid visa")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "service-overseas.html"
  }, "Bring a maid from abroad")))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, "Company"), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "about.html"
  }, "About")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "about.html#tech"
  }, "AI & Tech Division")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "about.html#press"
  }, "Press")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "about.html#careers"
  }, "Careers")))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, "Help"), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc — I have a question.'),
    target: "_blank",
    rel: "noopener"
  }, "Chat 24/7")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "faq.html"
  }, "FAQ")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "faq.html#replacement"
  }, "Replacement policy")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "faq.html#terms"
  }, "Terms"))))), /*#__PURE__*/React.createElement("div", {
    className: "legal"
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Maids.cc \xB7 All rights reserved"), /*#__PURE__*/React.createElement("span", null, "Tadbeer-licensed \xB7 UAE")));
}
function WhatsappFab() {
  return /*#__PURE__*/React.createElement("a", {
    className: "fab",
    href: wa('Hi maids.cc — I want to chat.'),
    target: "_blank",
    rel: "noopener"
  }, /*#__PURE__*/React.createElement(WaIcon, null), /*#__PURE__*/React.createElement("span", null, "Chat on WhatsApp"));
}

/* ========================================================================
   STICKY MOBILE CTA BAR — the conversion lever. Always visible on small
   screens; hidden on desktop where the hero CTAs are already on-screen.
   Two thumb-friendly buttons side by side: Hire Maid / Get Visa.
   ======================================================================== */
/* ========================================================================
   STICKY MOBILE NAV — bottom tab bar with Home + 4 services.
   Mobile-only (hidden via CSS on desktop). Active tab highlighted.
   Pass `current` prop to indicate which page is active.
   ======================================================================== */
function StickyMobileBar({
  current = 'home'
}) {
  const tabs = [{
    key: 'home',
    label: 'Home',
    icon: 'home',
    href: 'index.html'
  }, {
    key: 'fulltime',
    label: 'Full-time',
    icon: 'sparkles',
    href: 'service-fulltime.html'
  }, {
    key: 'parttime',
    label: 'Part-time',
    icon: 'clock',
    href: 'service-parttime.html'
  }, {
    key: 'visa',
    label: 'Visa',
    icon: 'badge-check',
    href: 'service-visa.html'
  }, {
    key: 'overseas',
    label: 'Abroad',
    icon: 'plane-landing',
    href: 'service-overseas.html'
  }];
  return /*#__PURE__*/React.createElement("nav", {
    className: "sticky-nav",
    "aria-label": "Services"
  }, tabs.map(t => /*#__PURE__*/React.createElement("a", {
    key: t.key,
    href: t.href,
    className: 'sn-tab' + (current === t.key ? ' active' : ''),
    "aria-current": current === t.key ? 'page' : undefined
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": t.icon
  }), /*#__PURE__*/React.createElement("span", null, t.label))));
}
Object.assign(window, {
  Nav,
  Hero,
  ProductPicker,
  About,
  MaidGallery,
  MaidCard,
  Picture,
  PressStrip,
  TrustStrip,
  ServiceSection,
  HowItWorks,
  Pricing,
  Comparison,
  Reviews,
  Reassure,
  Faq,
  CtaBand,
  Footer,
  WhatsappFab,
  StickyMobileBar,
  Dh,
  WaIcon,
  SERVICES,
  SERVICE_KEYS,
  MAIDS_GALLERY,
  wa
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/pages.jsx
try { (() => {
/* ============================================================================
   PAGES.JSX — section components for the secondary pages
   (about.html, faq.html, hire.html). Reuses the shared
   primitives in components.jsx (Nav, Footer, Picture, Dh, WaIcon, wa…).
   ============================================================================ */

/* ----------------------------------------------------------------------------
   PAGE HEADER — slim editorial header used at the top of secondary pages.
   ---------------------------------------------------------------------------- */
function PageHeader({
  overline,
  title,
  sub,
  accent
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, overline && /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, overline), /*#__PURE__*/React.createElement("h1", null, title, " ", accent && /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, accent)), sub && /*#__PURE__*/React.createElement("p", null, sub)));
}

/* ----------------------------------------------------------------------------
   AI & TECH DIVISION — maids.cc runs a software-driven pipeline. Honest
   framing, no invented metrics.
   ---------------------------------------------------------------------------- */
function AiTechSection() {
  const caps = [{
    ic: 'cpu',
    t: 'In-house product team',
    d: 'We build the booking, payroll, and matching software ourselves — not off-the-shelf agency tooling.'
  }, {
    ic: 'route',
    t: 'Same-day logistics',
    d: 'Routing and dispatch software is how we Uber a maid to your door the same day you sign.'
  }, {
    ic: 'whatsapp',
    t: 'AI-assisted support',
    d: '24/7 chat triage routes you to a real person fast, in four languages.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "tech-section",
    id: "tech"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner tech-inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tech-kicker"
  }, "A maids.cc division"), /*#__PURE__*/React.createElement("img", {
    className: "tech-logo",
    src: "../../assets/logos/maids-aitech-white.png",
    alt: "maids.cc \u2014 AI & Tech Division"
  }), /*#__PURE__*/React.createElement("h2", null, "A care company that ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, "runs on software.")), /*#__PURE__*/React.createElement("p", null, "The reason we can sign, pay, and deliver in a single day is that the whole pipeline \u2014 profiles, contracts, payments, payroll, replacements \u2014 is one system we built and keep improving."), /*#__PURE__*/React.createElement("ul", {
    className: "tech-caps"
  }, caps.map(c => /*#__PURE__*/React.createElement("li", {
    key: c.t
  }, /*#__PURE__*/React.createElement("span", {
    className: "tech-cap-ic"
  }, c.ic === 'whatsapp' ? /*#__PURE__*/React.createElement(WaIcon, null) : /*#__PURE__*/React.createElement("i", {
    "data-lucide": c.ic
  })), /*#__PURE__*/React.createElement("b", null, c.t), /*#__PURE__*/React.createElement("span", {
    className: "tech-cap-d"
  }, c.d))))));
}

/* ----------------------------------------------------------------------------
   CAREERS — short recruiting band. Routes to WhatsApp (no ATS in this kit).
   ---------------------------------------------------------------------------- */
function CareersBand() {
  return /*#__PURE__*/React.createElement("section", {
    className: "careers-band",
    id: "careers"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner careers-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "careers-copy"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Careers"), /*#__PURE__*/React.createElement("h2", null, "Help us look after 30,000 homes."), /*#__PURE__*/React.createElement("p", null, "We hire across care, operations, customer support, and engineering \u2014 in Dubai and remote. If you want to build the company that fixed domestic hiring in the UAE, talk to us.")), /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc — I am interested in a career with you. Here is a bit about me:'),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-accent btn-lg"
  }, /*#__PURE__*/React.createElement(WaIcon, null), "Message recruiting")));
}

/* ----------------------------------------------------------------------------
   POLICIES — replacement policy (#replacement) + plain-language terms (#terms).
   ---------------------------------------------------------------------------- */
function PoliciesSection() {
  const replacement = ['If the maid isn’t the right fit, tell us on WhatsApp — we send a replacement at no cost.', 'Replacements are unlimited for the life of your contract. There is no per-swap fee.', 'The first 7 days are fully money-back if none of the replacements work for you.', 'While we arrange the next match, support stays on the line — you’re never left without a plan.'];
  const terms = [{
    t: 'Monthly, cancel anytime',
    d: 'Full-time service runs month to month. Cancel with notice — no multi-year lock-in.'
  }, {
    t: 'All-in pricing',
    d: 'The advertised monthly figure includes salary, visa, Emirates ID, medicals, government fees, and WPS payroll. Anything not listed as included is quoted before you pay.'
  }, {
    t: 'Who employs the maid',
    d: 'Because we sponsor the visa, maids.cc carries the legal employer obligations — payroll, end-of-service, insurance, and repatriation.'
  }, {
    t: 'Refunds',
    d: '7-day money-back from the start of service. Visa government fees already paid to authorities are non-refundable once submitted.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "policies",
    id: "policies"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "policy-block",
    id: "replacement"
  }, /*#__PURE__*/React.createElement("div", {
    className: "policy-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "policy-ic"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "repeat"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Replacement policy"), /*#__PURE__*/React.createElement("h2", null, "If she doesn\u2019t fit, we fix it \u2014 free."))), /*#__PURE__*/React.createElement("ul", {
    className: "policy-list"
  }, replacement.map((r, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check-circle"
  }), /*#__PURE__*/React.createElement("span", null, r))))), /*#__PURE__*/React.createElement("div", {
    className: "policy-block",
    id: "terms"
  }, /*#__PURE__*/React.createElement("div", {
    className: "policy-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "policy-ic"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "file-text"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Terms \xB7 plain language"), /*#__PURE__*/React.createElement("h2", null, "The deal, without the fine print."))), /*#__PURE__*/React.createElement("div", {
    className: "terms-grid"
  }, terms.map((t, i) => /*#__PURE__*/React.createElement("div", {
    className: "terms-card",
    key: i
  }, /*#__PURE__*/React.createElement("h3", null, t.t), /*#__PURE__*/React.createElement("p", null, t.d)))), /*#__PURE__*/React.createElement("p", {
    className: "policy-foot"
  }, "This is a plain-language summary for the design kit, not a contract. The binding terms are the ones you sign at checkout."))));
}

/* ----------------------------------------------------------------------------
   HIRE PAGE — the "Sign & pay in 5 minutes" flow that every #hire / "Sign &
   pay" / maid-card CTA now points to. Three steps + a sticky order summary,
   ending in a confirmation state. Front-end demo only (no real payment).
   ---------------------------------------------------------------------------- */
const HIRE_SERVICES = [{
  key: 'fulltime',
  icon: 'sparkles',
  title: 'Full-time maid',
  price: 'From AED 2,980',
  unit: '/ month',
  note: 'Live-in or live-out · all-in monthly'
}, {
  key: 'parttime',
  icon: 'clock',
  title: 'Part-time maid or nanny',
  price: 'From AED 35',
  unit: '/ hour',
  note: 'Same maid every visit'
}, {
  key: 'visa',
  icon: 'badge-check',
  title: '2-year maid visa',
  price: 'AED 8,500',
  unit: '+ 160/mo',
  note: 'Issued in 7 days'
}, {
  key: 'overseas',
  icon: 'plane-landing',
  title: 'Bring a maid from abroad',
  price: 'Custom quote',
  unit: 'by country',
  note: 'Arrival guarantee'
}];
function HireStepDots({
  step
}) {
  const labels = ['Service', 'Your details', 'Sign & pay'];
  return /*#__PURE__*/React.createElement("ol", {
    className: "hire-steps"
  }, labels.map((l, i) => {
    const n = i + 1;
    const state = step > n ? 'done' : step === n ? 'current' : 'todo';
    return /*#__PURE__*/React.createElement("li", {
      key: l,
      className: 'hire-step ' + state
    }, /*#__PURE__*/React.createElement("span", {
      className: "hire-step-dot"
    }, state === 'done' ? /*#__PURE__*/React.createElement("i", {
      "data-lucide": "check"
    }) : n), /*#__PURE__*/React.createElement("span", {
      className: "hire-step-label"
    }, l));
  }));
}
function HirePage() {
  const [step, setStep] = React.useState(1);
  const [service, setService] = React.useState('fulltime');
  const [form, setForm] = React.useState({
    name: '',
    phone: '',
    area: '',
    home: 'Apartment'
  });
  const sel = HIRE_SERVICES.find(s => s.key === service);
  React.useEffect(() => {
    lucide.createIcons();
  });
  const set = k => e => setForm(f => ({
    ...f,
    [k]: e.target.value
  }));
  const go = n => () => {
    setStep(n);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Nav, null), /*#__PURE__*/React.createElement("main", {
    className: "hire"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner hire-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hire-main"
  }, /*#__PURE__*/React.createElement("a", {
    href: "index.html",
    className: "detail-back"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-left"
  }), "Back to home"), /*#__PURE__*/React.createElement("h1", {
    className: "hire-title"
  }, "Sign & pay in ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, "5 minutes.")), /*#__PURE__*/React.createElement("p", {
    className: "hire-sub"
  }, "Everything online \u2014 choose your service, share a couple of details, and we\u2019ll Uber her to you. Same day in most cases."), step !== 'done' && /*#__PURE__*/React.createElement(HireStepDots, {
    step: step
  }), step === 1 && /*#__PURE__*/React.createElement("section", {
    className: "hire-card"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "hire-card-h"
  }, "What do you need?"), /*#__PURE__*/React.createElement("div", {
    className: "hire-service-grid"
  }, HIRE_SERVICES.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.key,
    type: "button",
    className: 'hire-service' + (service === s.key ? ' selected' : ''),
    onClick: () => setService(s.key),
    "aria-pressed": service === s.key
  }, /*#__PURE__*/React.createElement("span", {
    className: "hire-service-ic"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": s.icon
  })), /*#__PURE__*/React.createElement("span", {
    className: "hire-service-body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hire-service-title"
  }, s.title), /*#__PURE__*/React.createElement("span", {
    className: "hire-service-note"
  }, s.note)), /*#__PURE__*/React.createElement("span", {
    className: "hire-service-price"
  }, s.price, /*#__PURE__*/React.createElement("small", null, s.unit)), /*#__PURE__*/React.createElement("span", {
    className: "hire-radio",
    "aria-hidden": "true"
  })))), /*#__PURE__*/React.createElement("div", {
    className: "hire-actions"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn btn-accent btn-lg",
    onClick: go(2)
  }, "Continue", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  })))), step === 2 && /*#__PURE__*/React.createElement("section", {
    className: "hire-card"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "hire-card-h"
  }, "Where should we send her?"), /*#__PURE__*/React.createElement("div", {
    className: "hire-fields"
  }, /*#__PURE__*/React.createElement("label", {
    className: "hire-field"
  }, /*#__PURE__*/React.createElement("span", null, "Full name"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: form.name,
    onChange: set('name'),
    placeholder: "e.g. Sara Al Maktoum"
  })), /*#__PURE__*/React.createElement("label", {
    className: "hire-field"
  }, /*#__PURE__*/React.createElement("span", null, "WhatsApp number"), /*#__PURE__*/React.createElement("input", {
    type: "tel",
    value: form.phone,
    onChange: set('phone'),
    placeholder: "+971 5x xxx xxxx"
  })), /*#__PURE__*/React.createElement("label", {
    className: "hire-field"
  }, /*#__PURE__*/React.createElement("span", null, "Area / community"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: form.area,
    onChange: set('area'),
    placeholder: "e.g. Dubai Marina"
  })), /*#__PURE__*/React.createElement("label", {
    className: "hire-field"
  }, /*#__PURE__*/React.createElement("span", null, "Home type"), /*#__PURE__*/React.createElement("select", {
    value: form.home,
    onChange: set('home')
  }, /*#__PURE__*/React.createElement("option", null, "Apartment"), /*#__PURE__*/React.createElement("option", null, "Villa"), /*#__PURE__*/React.createElement("option", null, "Townhouse"))), /*#__PURE__*/React.createElement("div", {
    className: "hire-field hire-field-wide hire-upload"
  }, /*#__PURE__*/React.createElement("span", null, "Emirates ID (optional now)"), /*#__PURE__*/React.createElement("div", {
    className: "hire-dropzone"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "upload"
  }), /*#__PURE__*/React.createElement("span", null, "Drag & drop or tap to upload \u2014 you can also send it on WhatsApp later.")))), /*#__PURE__*/React.createElement("div", {
    className: "hire-actions"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn btn-ghost btn-lg",
    onClick: go(1)
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-left"
  }), "Back"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn btn-accent btn-lg",
    onClick: go(3)
  }, "Continue", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right"
  })))), step === 3 && /*#__PURE__*/React.createElement("section", {
    className: "hire-card"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "hire-card-h"
  }, "Review & pay"), /*#__PURE__*/React.createElement("div", {
    className: "hire-review"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hire-review-row"
  }, /*#__PURE__*/React.createElement("span", null, "Service"), /*#__PURE__*/React.createElement("b", null, sel.title)), /*#__PURE__*/React.createElement("div", {
    className: "hire-review-row"
  }, /*#__PURE__*/React.createElement("span", null, "Name"), /*#__PURE__*/React.createElement("b", null, form.name || '—')), /*#__PURE__*/React.createElement("div", {
    className: "hire-review-row"
  }, /*#__PURE__*/React.createElement("span", null, "Deliver to"), /*#__PURE__*/React.createElement("b", null, form.area ? form.area + ' · ' + form.home : '—')), /*#__PURE__*/React.createElement("div", {
    className: "hire-review-row total"
  }, /*#__PURE__*/React.createElement("span", null, "Today\u2019s price"), /*#__PURE__*/React.createElement("b", null, sel.price, " ", /*#__PURE__*/React.createElement("small", null, sel.unit)))), /*#__PURE__*/React.createElement("div", {
    className: "hire-fields"
  }, /*#__PURE__*/React.createElement("label", {
    className: "hire-field hire-field-wide"
  }, /*#__PURE__*/React.createElement("span", null, "Name on card"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: "As printed on the card"
  })), /*#__PURE__*/React.createElement("label", {
    className: "hire-field hire-field-wide"
  }, /*#__PURE__*/React.createElement("span", null, "Card number"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    inputMode: "numeric",
    placeholder: "1234 5678 9012 3456"
  })), /*#__PURE__*/React.createElement("label", {
    className: "hire-field"
  }, /*#__PURE__*/React.createElement("span", null, "Expiry"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: "MM / YY"
  })), /*#__PURE__*/React.createElement("label", {
    className: "hire-field"
  }, /*#__PURE__*/React.createElement("span", null, "CVC"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    inputMode: "numeric",
    placeholder: "123"
  }))), /*#__PURE__*/React.createElement("label", {
    className: "hire-consent"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement("span", null, "I agree to the service contract and the ", /*#__PURE__*/React.createElement("a", {
    href: "faq.html#terms"
  }, "terms"), ", including the 7-day money-back and unlimited free replacements.")), /*#__PURE__*/React.createElement("div", {
    className: "hire-actions"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn btn-ghost btn-lg",
    onClick: go(2)
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-left"
  }), "Back"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn btn-accent btn-lg",
    onClick: go('done')
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "lock"
  }), "Sign & pay")), /*#__PURE__*/React.createElement("p", {
    className: "hire-secure"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shield-check"
  }), "Secured checkout \xB7 demo only \u2014 no card is charged.")), step === 'done' && /*#__PURE__*/React.createElement("section", {
    className: "hire-card hire-done"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hire-done-mark"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  })), /*#__PURE__*/React.createElement("h2", null, "You\u2019re all set", form.name ? ', ' + form.name.split(' ')[0] : '', "."), /*#__PURE__*/React.createElement("p", null, "Your ", sel.title.toLowerCase(), " is booked. We\u2019ll confirm on WhatsApp in minutes and arrange the Uber to ", form.area || 'your home', " \u2014 same day in most cases."), /*#__PURE__*/React.createElement("div", {
    className: "hire-next"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hire-next-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hire-next-n"
  }, "1"), "We match & confirm her profile on WhatsApp"), /*#__PURE__*/React.createElement("div", {
    className: "hire-next-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hire-next-n"
  }, "2"), "We handle visa, EID, medical & payroll"), /*#__PURE__*/React.createElement("div", {
    className: "hire-next-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hire-next-n"
  }, "3"), "She arrives \u2014 you don\u2019t lift a finger")), /*#__PURE__*/React.createElement("div", {
    className: "hire-actions"
  }, /*#__PURE__*/React.createElement("a", {
    href: wa('Hi maids.cc — I just signed up online. Looking forward to confirming my maid.'),
    target: "_blank",
    rel: "noopener",
    className: "btn btn-accent btn-lg"
  }, /*#__PURE__*/React.createElement(WaIcon, null), "Open WhatsApp"), /*#__PURE__*/React.createElement("a", {
    href: "index.html",
    className: "btn btn-ghost btn-lg"
  }, "Back to home")))), /*#__PURE__*/React.createElement("aside", {
    className: "hire-summary"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hire-summary-card"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Your order"), /*#__PURE__*/React.createElement("div", {
    className: "hire-summary-service"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hire-summary-ic"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": sel.icon
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", null, sel.title), /*#__PURE__*/React.createElement("span", null, sel.note))), /*#__PURE__*/React.createElement("div", {
    className: "hire-summary-price"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hsp-amount"
  }, sel.price), /*#__PURE__*/React.createElement("span", {
    className: "hsp-unit"
  }, sel.unit)), /*#__PURE__*/React.createElement("ul", {
    className: "hire-summary-incl"
  }, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  }), "Salary, visa, EID, medicals & WPS payroll"), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  }), "Unlimited free replacements"), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  }), "7-day money-back \xB7 cancel anytime")), /*#__PURE__*/React.createElement("div", {
    className: "hire-summary-trust"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shield-check"
  }), "Tadbeer-licensed \xB7 4.8 / 15K reviews"))))), /*#__PURE__*/React.createElement(Footer, null), /*#__PURE__*/React.createElement(WhatsappFab, null), /*#__PURE__*/React.createElement(StickyMobileBar, {
    current: "home"
  }));
}
Object.assign(window, {
  PageHeader,
  AiTechSection,
  CareersBand,
  PoliciesSection,
  HirePage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/pages.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/service-data.jsx
try { (() => {
/* ============================================================================
   SERVICE DATA — config for each service detail page.
   Keys map to filenames: fulltime → service-fulltime.html, etc.
   ============================================================================ */

const SERVICE_DETAILS = {
  /* ============================================================ FULL-TIME */
  fulltime: {
    key: 'fulltime',
    tone: 'blue',
    eyebrow: 'Full-time maid',
    icon: 'sparkles',
    headline: {
      pre: 'A full-time maid in your home',
      accent: 'today.',
      post: ''
    },
    sub: "Same maid every day — live-in or live-out. We handle her visa, medical, payroll, and the dozen government fees other agencies hide. You pay one monthly number. Cancel anytime.",
    reassure: ['Sign & pay online in 5 minutes — no office visits', 'Visa, medical, WPS payroll, Ubers all included', 'Free unlimited replacements until you find a fit', "Cancel anytime · no 2-year contracts"],
    primaryCta: {
      label: 'Hire a maid today',
      icon: 'zap'
    },
    waMsg: 'Hi maids.cc — I want to hire a full-time maid.',
    heroLabel: 'Photo · maid arriving at a UAE home',
    heroSrc: 'assets/fulltime-hero.png',
    heroPos: '52% center',
    priceFrom: '2,980',
    priceUnit: '/month all-in',
    priceFootnote: 'no hidden fees, ever',
    featureTable: {
      title: 'Everything other agencies hide — itemized.',
      sub: "Most agencies advertise the maid's salary and quietly invoice for the visa, medical, typist runs, Ubers, and \"government fees\" that aren't government fees. We bundle all of it. Here's what \"all-in\" actually means.",
      cols: [{
        key: 'a',
        label: 'Maids.cc',
        tag: 'All-in',
        good: true
      }, {
        key: 'b',
        label: 'Traditional agency',
        tag: 'Hidden',
        good: false
      }, {
        key: 'c',
        label: 'Hire direct',
        tag: 'You handle',
        good: false
      }],
      rows: [{
        row: 'Sign & pay online (5 minutes)',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Same maid every day, guaranteed',
        a: true,
        b: true,
        c: true
      }, {
        row: '2-year visa sponsorship',
        a: true,
        b: 'Extra fee',
        c: false
      }, {
        row: 'Emirates ID + medical handled',
        a: true,
        b: false,
        c: false
      }, {
        row: 'WPS payroll set up & run for you',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Free replacements (unlimited)',
        a: true,
        b: 'Once · fee',
        c: false
      }, {
        row: '24/7 real-person support',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Cancel anytime',
        a: true,
        b: false,
        c: false
      }, {
        row: 'PRO services (failed medical, ban-lifting)',
        a: true,
        b: 'Extra fee',
        c: false
      }, {
        row: 'Embassy paperwork for travel',
        a: true,
        b: false,
        c: false
      }]
    },
    pricingTable: {
      title: 'One number. Nothing else lands on your card.',
      sub: 'Other agencies break this into 6-8 line items. We bundle it. Here\'s what AED 2,980/month covers.',
      rows: [{
        item: 'Maid salary',
        icon: 'user',
        covers: 'Paid via WPS, on time, every month',
        cost: '1,500',
        unit: '/mo'
      }, {
        item: '2-year visa',
        icon: 'badge-check',
        covers: 'Sponsored by us — no AED 2,000 deposit, no AED 161 cancellation',
        free: true
      }, {
        item: 'Emirates ID + medical',
        icon: 'stethoscope',
        covers: 'We arrange and run her through every step',
        free: true
      }, {
        item: 'Medical insurance',
        icon: 'heart-pulse',
        covers: '80% medical visits, 70% pharmacy — UAE-wide network',
        free: true
      }, {
        item: 'WPS payroll setup',
        icon: 'banknote',
        covers: 'Account, monthly transfers, MOHRE compliance',
        free: true
      }, {
        item: 'Replacements',
        icon: 'repeat',
        covers: 'Swap her for another maid, unlimited times',
        free: true
      }, {
        item: 'Ubers & transport',
        icon: 'car',
        covers: 'Door-to-door delivery on day one; doctor visits ongoing',
        free: true
      }, {
        item: 'Government fees',
        icon: 'landmark',
        covers: 'MOHRE, GDRFA, typing, deposits — all of it',
        free: true
      }, {
        item: '24/7 support',
        icon: 'whatsapp',
        covers: 'Real person on WhatsApp, day or night',
        free: true
      }],
      total: {
        label: 'All-in monthly',
        covers: 'Everything above. No surprises, no add-ons, no "by the way" invoices.',
        cost: '2,980',
        unit: '/month'
      },
      footnote: 'Live-in or live-out. Monthly billing, cancel anytime. Refunds before visa issuance, minus government fees already paid.'
    },
    faq: [{
      q: 'How fast can I get a maid?',
      a: 'Same day in most cases. View profiles, pick one, sign and pay online in 5 minutes — we Uber her to your home. If she\'s coming from outside the UAE, count 7 days for the visa.'
    }, {
      q: 'What if she\'s not a fit?',
      a: 'Free replacements, unlimited. Tell us what didn\'t work and we swap her — no questions, no fee, no contract lock-in. Most clients try 1–2 maids before settling.'
    }, {
      q: 'Live-in vs. live-out?',
      a: 'Both at the same monthly all-in price. Live-in: she has a room in your home. Live-out: she commutes from our staff accommodation. Same maid in both cases.'
    }, {
      q: 'Are there any extra fees?',
      a: 'No. AED 2,980/month covers everything — salary, visa, medical, WPS, government fees, Ubers, replacements, support. The "all-in" promise is the whole product.'
    }, {
      q: 'Can I cancel?',
      a: 'Anytime, monthly. No 2-year contracts, no cancellation fee. We bill month-to-month via WPS.'
    }, {
      q: 'What documents do I need?',
      a: 'Your Emirates ID and a tenancy contract (Ejari) for your home. That\'s it. Salary certificate only required if we\'re sponsoring her visa.'
    }],
    ctaHeadline: {
      pre: 'Get her in your home',
      accent: 'today.'
    },
    ctaSub: '300+ profiles ready right now. Sign & pay online — she\'s at your door before dinner.'
  },
  /* ============================================================ PART-TIME */
  parttime: {
    key: 'parttime',
    tone: 'green',
    eyebrow: 'Part-time maid',
    icon: 'clock',
    headline: {
      pre: 'Same maid, by the hour.',
      accent: 'Not a stranger every visit.',
      post: ''
    },
    sub: 'Other apps send whoever\'s free. We assign one maid to your home and keep her there — week after week. From AED 35/hour. Book, reschedule, and pay in chat.',
    reassure: ['Same maid guaranteed — not a rotating crew', 'Money-back guarantee if she\'s not the right fit', 'Trained, insured, English-speaking', 'Book, reschedule, pay — all in WhatsApp'],
    primaryCta: {
      label: 'Book part-time',
      icon: 'calendar-plus'
    },
    waMsg: 'Hi maids.cc — I want to book a part-time maid.',
    heroLabel: 'Photo · part-time maid at work in a home',
    heroSrc: 'assets/parttime-hero.png?v=3',
    heroPos: 'center',
    priceFrom: '35',
    priceUnit: '/hour',
    priceFootnote: '2-hour minimum, cleaning supplies included',
    featureTable: {
      title: 'Why "same maid" matters.',
      sub: 'The cheap hourly apps optimize for filling slots, not building relationships. You get a different person every visit; she doesn\'t know your home, your routines, or where the spare key is. We do the opposite.',
      cols: [{
        key: 'a',
        label: 'Maids.cc',
        tag: 'Continuity',
        good: true
      }, {
        key: 'b',
        label: 'Hourly apps',
        tag: 'Rotating',
        good: false
      }, {
        key: 'c',
        label: 'Freelance maid',
        tag: 'Risky',
        good: false
      }],
      rows: [{
        row: 'Same maid every visit',
        a: true,
        b: 'Sometimes',
        c: true
      }, {
        row: 'Trained & vetted',
        a: true,
        b: 'Varies',
        c: false
      }, {
        row: 'Insured (work + liability)',
        a: true,
        b: 'Varies',
        c: false
      }, {
        row: 'Legal — working on a valid UAE visa',
        a: true,
        b: true,
        c: 'Often illegal'
      }, {
        row: 'Money-back if she\'s not a fit',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Book & reschedule in WhatsApp',
        a: true,
        b: 'App only',
        c: false
      }, {
        row: 'Cleaning supplies included',
        a: true,
        b: 'Extra',
        c: false
      }, {
        row: '24/7 support if anything goes wrong',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Pay after the visit',
        a: true,
        b: false,
        c: false
      }]
    },
    pricingTable: {
      title: 'Hourly rates that don\'t hide a subscription.',
      sub: 'No "membership" tacked on. No surge pricing. The rate you see is the rate you pay — supplies included.',
      rows: [{
        item: 'Single visit',
        icon: 'calendar',
        covers: 'One-off — try the maid, no commitment',
        cost: '45',
        unit: '/hr · 2hr min'
      }, {
        item: 'Weekly recurring',
        icon: 'repeat',
        covers: 'Same maid, same day every week (most popular)',
        cost: '35',
        unit: '/hr · 2hr min'
      }, {
        item: 'Bi-weekly recurring',
        icon: 'calendar-clock',
        covers: 'Every other week, same maid',
        cost: '40',
        unit: '/hr · 2hr min'
      }, {
        item: 'Monthly package',
        icon: 'package',
        covers: '4 visits × 2 hours, one bill',
        cost: '280',
        unit: '/month'
      }, {
        item: 'Cleaning supplies',
        icon: 'spray-can',
        covers: 'Eco-friendly products, she brings them',
        free: true
      }, {
        item: 'Reschedule fee',
        icon: 'rotate-cw',
        covers: '24h+ notice — no fee, no questions',
        free: true
      }, {
        item: 'Cancellation',
        icon: 'x-circle',
        covers: 'Cancel the recurring booking anytime',
        free: true
      }, {
        item: 'Add-on: ironing',
        icon: 'shirt',
        covers: 'Per-hour add-on, same maid',
        cost: '10',
        unit: '/hr extra'
      }],
      total: {
        label: 'Weekly · 2hrs',
        covers: 'Most-popular plan: same maid, same day, every week.',
        cost: '70',
        unit: '/visit'
      },
      footnote: 'VAT included. Pay after the visit via card or bank transfer — no upfront deposit.'
    },
    faq: [{
      q: 'How is "same maid" enforced?',
      a: 'We assign one named maid to your home when you book a recurring slot. If she\'s ever sick or on leave, we tell you 24h ahead and you choose: skip the visit, or accept a one-time substitute. Your default maid comes back the following week.'
    }, {
      q: 'What\'s the money-back guarantee?',
      a: 'If after the first visit she\'s not the right fit — for any reason — we refund the visit in full and assign a different maid. No questions.'
    }, {
      q: 'Do I need to be home during the visit?',
      a: 'No. Most clients aren\'t. She has a UAE work visa, is insured, and we run a background check. You can leave a key with the building or with us.'
    }, {
      q: 'What does she clean?',
      a: 'Standard: dusting, vacuuming, mopping, kitchen surfaces, bathrooms, bed linens, taking out trash. Add-ons by the hour: ironing, inside-fridge, inside-oven, balcony, windows.'
    }, {
      q: 'Can I increase the hours later?',
      a: 'Yes, anytime in WhatsApp. Going from 2hr/week to 4hr/week is a 60-second message. Pricing scales linearly — no tier upgrades.'
    }, {
      q: 'Why is the single-visit rate higher than recurring?',
      a: 'Recurring slots let us keep your maid on a stable schedule, which she prefers and we can plan for. One-off visits are AED 45 because they\'re harder for us to staff efficiently.'
    }],
    ctaHeadline: {
      pre: 'Book the first visit.',
      accent: 'Same maid from there.'
    },
    ctaSub: 'Tell us your address and a 2-hour window — she\'ll be there. AED 70 for a weekly 2-hour visit.'
  },
  /* ============================================================ VISA */
  visa: {
    key: 'visa',
    tone: 'orange',
    eyebrow: '2-year maid visa',
    icon: 'badge-check',
    headline: {
      pre: 'A 2-year maid visa,',
      accent: 'issued in 7 days.',
      post: ''
    },
    sub: 'Upload your maid\'s passport copy and photo — we handle Emirates ID, the medical, WPS payroll, MOHRE contract, and the embassy paperwork. From AED 8,500 for two years.',
    reassure: ['7 days end-to-end · 2-year residency', 'No deposit · refundable before visa issuance', 'PRO services included — failed medicals, ban-lifting, GCC', 'Embassy paperwork for Philippines, Ethiopia, Kenya, Sri Lanka, Uganda'],
    primaryCta: {
      label: 'Apply for a maid visa',
      icon: 'badge-check'
    },
    waMsg: 'Hi maids.cc — I want to apply for a 2-year maid visa.',
    heroLabel: 'Photo · maid holding her stamped Emirates ID',
    heroSrc: 'assets/visa-hero.png',
    heroPos: '50% 22%',
    priceFrom: '8,500',
    priceUnit: '/ 2 years',
    priceFootnote: 'or 10,960 upfront with no monthly add-on',
    featureTable: {
      title: 'Company sponsorship vs. private sponsorship.',
      sub: 'Sponsoring your maid privately means you\'re the legal employer, on the hook for fines, medical failures, runaways, and 6+ government counter visits. Company sponsorship moves all of that to us.',
      cols: [{
        key: 'a',
        label: 'Maids.cc (company)',
        tag: '2-year',
        good: true
      }, {
        key: 'b',
        label: 'Private sponsor',
        tag: '1-year',
        good: false
      }, {
        key: 'c',
        label: 'Other Tadbeers',
        tag: 'Patchy',
        good: false
      }],
      rows: [{
        row: 'Visa duration',
        a: '2 years',
        b: '1 year',
        c: '2 years'
      }, {
        row: 'Apply online (5 min, no office visit)',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Emirates ID + medical handled',
        a: true,
        b: false,
        c: 'Extra fee'
      }, {
        row: 'WPS payroll setup',
        a: true,
        b: false,
        c: 'Extra fee'
      }, {
        row: 'AED 2,000 government deposit handled',
        a: true,
        b: false,
        c: 'You pay'
      }, {
        row: 'Refundable before issuance',
        a: true,
        b: false,
        c: 'Varies'
      }, {
        row: 'PRO services (failed medical, ban-lift)',
        a: true,
        b: 'You handle',
        c: 'Extra fee'
      }, {
        row: 'Embassy paperwork (PH, ET, KE, LK, UG)',
        a: true,
        b: false,
        c: 'Some'
      }, {
        row: 'Schengen-ready travel docs',
        a: true,
        b: false,
        c: false
      }, {
        row: 'MOHRE-licensed Domestic Worker Service Centre',
        a: true,
        b: false,
        c: true
      }]
    },
    pricingTable: {
      title: 'Visa pricing — two ways to pay.',
      sub: 'Pick the structure that fits your cashflow. The all-in number is what your maid\'s 2-year residency actually costs — government fees, medical, insurance, EID, all of it.',
      rows: [{
        item: '2-year residency visa',
        icon: 'badge-check',
        covers: 'MOHRE contract, GDRFA stamp, full sponsorship',
        cost: '4,800',
        unit: '/ 2 yrs'
      }, {
        item: 'Emirates ID',
        icon: 'id-card',
        covers: 'Biometric, typing, ID card delivery',
        cost: '370',
        unit: '/ 2 yrs'
      }, {
        item: 'Medical fitness test',
        icon: 'stethoscope',
        covers: 'TB, HIV, biometrics — we take her there',
        cost: '320',
        unit: 'once'
      }, {
        item: 'Medical insurance (2 yrs)',
        icon: 'heart-pulse',
        covers: '80% visits / 70% pharmacy, UAE-wide network',
        cost: '1,400',
        unit: '/ 2 yrs'
      }, {
        item: 'PRO services',
        icon: 'shield-check',
        covers: 'Failed medical, ban lift, GCC, DMW',
        free: true
      }, {
        item: 'Embassy paperwork',
        icon: 'stamp',
        covers: 'PH, ET, KE, LK, UG — for travel & home leave',
        free: true
      }, {
        item: 'WPS payroll setup',
        icon: 'banknote',
        covers: 'Account, monthly transfers, MOHRE compliance',
        free: true
      }, {
        item: 'Door-to-door delivery',
        icon: 'car',
        covers: 'Documents collected & dropped — no counter visits',
        free: true
      }],
      total: {
        label: 'All-in upfront',
        covers: 'Two years of legal residency. One number, refundable before issuance.',
        cost: '8,500',
        unit: '+ 160/mo'
      },
      footnote: 'Alternative: AED 10,960 upfront with no monthly fee. Government deposit (AED 2,000) handled by us — refundable to you on cancellation via your IBAN.'
    },
    faq: [{
      q: 'Who is the legal employer?',
      a: 'Maids.cc — under our MOHRE Tadbeer license. That moves runaway risk, medical-failure risk, ban-lifting cost, and visa fines off you. You\'re the household, not the sponsor.'
    }, {
      q: 'How long does it actually take?',
      a: '7 days if she\'s already in the UAE on a tourist or cancelled visa. 2–4 weeks if she\'s coming from her home country (Philippines, Ethiopia, Kenya, Sri Lanka, Uganda) and needs an entry permit + embassy paperwork.'
    }, {
      q: 'What if she fails the medical?',
      a: 'We handle ban-lifting and a re-application at no additional cost — that\'s what "PRO services included" means. With private sponsorship, this is your problem.'
    }, {
      q: 'Can I cancel?',
      a: 'Yes. Refundable before visa issuance, minus government fees already paid. After issuance, AED 161 cancellation fee (inside UAE) or 261 (outside) — and a final medical/Emirates ID return.'
    }, {
      q: 'Will my maid be able to travel with me?',
      a: 'Yes. We prepare Schengen and tourist visa applications — 80% of our Italy/Germany/France submissions were approved in 2024. Documents come from your maids.cc app.'
    }, {
      q: 'Do I need to earn AED 25,000?',
      a: 'Not under company sponsorship — that salary requirement is for private sponsorship. With Maids.cc you only need a 2+ bedroom tenancy contract.'
    }],
    ctaHeadline: {
      pre: 'Get her residency stamped',
      accent: 'in 7 days.'
    },
    ctaSub: 'Upload her passport, sign and pay online — we run the rest. AED 8,500 + 160/mo or AED 10,960 upfront.'
  },
  /* ============================================================ OVERSEAS */
  overseas: {
    key: 'overseas',
    tone: 'orange',
    eyebrow: 'Recruitment from abroad',
    icon: 'plane-landing',
    headline: {
      pre: 'Bring your maid from',
      accent: 'anywhere in the world.',
      post: ''
    },
    sub: "We handle everything between her home country and your front door: visa, flights, taxis, paperwork. 100% arrival guarantee, or your money back. Pricing depends on the country.",
    reassure: ['100% arrival guarantee or your money back', 'Arrival in 10–50 days, depending on nationality', 'Fully online process — no office visits', 'Visas, flight tickets, taxis & paperwork — handled'],
    primaryCta: {
      label: 'Get instant quote',
      icon: 'whatsapp'
    },
    waMsg: "Hi maids.cc — I want to bring a maid from overseas. What's the price?",
    heroLabel: 'Photo · maid arriving at DXB with her documents',
    heroSrc: 'assets/overseas-hero.png',
    heroPos: '50% 28%',
    priceFrom: 'Quote',
    priceUnit: '· price depends on country',
    priceFootnote: 'WhatsApp us for an exact number in under 1 minute',
    featureTable: {
      title: 'Why "we handle it all" is more than a tagline.',
      sub: "Bringing a maid from overseas touches three governments, two airlines, an embassy, a medical centre, a typist, and a taxi. Other agencies hand you a checklist. We hand you a tracking link.",
      cols: [{
        key: 'a',
        label: 'Maids.cc',
        tag: 'Full chain',
        good: true
      }, {
        key: 'b',
        label: 'Recruitment agent',
        tag: 'Source only',
        good: false
      }, {
        key: 'c',
        label: 'DIY direct hire',
        tag: 'You do it',
        good: false
      }],
      rows: [{
        row: 'Source candidate (Philippines, Ethiopia, Kenya, etc.)',
        a: true,
        b: true,
        c: 'Word of mouth'
      }, {
        row: 'Embassy paperwork (POEA/PSA/DMW)',
        a: true,
        b: 'Extra fee',
        c: false
      }, {
        row: 'UAE entry permit (GDRFA)',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Flight booking (one-way, escorted if needed)',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Airport pickup & transport',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Medical fitness + Emirates ID',
        a: true,
        b: false,
        c: false
      }, {
        row: '2-year residency visa',
        a: true,
        b: 'Hand-off',
        c: false
      }, {
        row: 'WPS payroll setup',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Arrival guarantee (money back if she doesn\'t come)',
        a: true,
        b: false,
        c: false
      }, {
        row: 'Single point of contact, 24/7',
        a: true,
        b: false,
        c: false
      }]
    },
    pricingTable: {
      title: 'Price depends on her passport — here\'s why.',
      sub: 'Embassy fees, flight cost, attestation, and processing time vary by source country. We give an instant quote in WhatsApp; below is the shape of the bundle so you know what\'s in the number.',
      rows: [{
        item: 'Source & screen candidate',
        icon: 'user-search',
        covers: 'Video interviews, background, prior employer checks',
        cost: 'Varies'
      }, {
        item: 'Embassy paperwork',
        icon: 'stamp',
        covers: 'POEA, PSA, DMW, MoLSA, etc. — varies by country',
        cost: 'Varies'
      }, {
        item: 'Flight ticket (one-way)',
        icon: 'plane',
        covers: 'Direct to DXB / AUH — escorted if required by embassy',
        cost: 'Varies'
      }, {
        item: 'UAE entry permit',
        icon: 'badge-check',
        covers: 'GDRFA + MOHRE — we file before she boards',
        cost: '1,200'
      }, {
        item: 'Airport pickup',
        icon: 'car',
        covers: 'Greeter at gate, taxi to onboarding centre',
        free: true
      }, {
        item: 'Medical fitness + EID',
        icon: 'stethoscope',
        covers: 'Day-2 medical, biometrics, EID typing',
        cost: '690'
      }, {
        item: '2-year residency visa',
        icon: 'id-card',
        covers: 'Full MOHRE company sponsorship, refundable deposit handled',
        cost: '4,800',
        unit: '/ 2yrs'
      }, {
        item: 'WPS payroll + bank',
        icon: 'banknote',
        covers: 'Account opened, ATM card delivered, MOHRE-compliant',
        free: true
      }, {
        item: 'Arrival guarantee',
        icon: 'shield-check',
        covers: 'No-arrival = full refund. No exceptions.',
        free: true
      }],
      total: {
        label: 'Total range',
        covers: 'Country-dependent — Philippines tends to be the high end, Africa the low end. Ask for an exact number in chat.',
        cost: '12,000–22,000',
        unit: 'all-in'
      },
      footnote: 'Pricing finalized after passport upload. 50% deposit holds the slot; balance due on UAE arrival.'
    },
    faq: [{
      q: 'How long does it take?',
      a: '10 days for cancelled-visa candidates already in-country. 30–50 days for fresh overseas hires — embassy paperwork is the longest pole (POEA in Manila is 3–4 weeks, MoLSA in Addis is 2 weeks).'
    }, {
      q: 'What does the arrival guarantee actually cover?',
      a: 'If she doesn\'t board her flight, doesn\'t pass medical, or backs out — full refund of every dirham you\'ve paid us. The only thing not refundable is fees the embassy has already taken (typically AED 800–1,200, country-dependent).'
    }, {
      q: 'Which countries do you source from?',
      a: 'Philippines (most common), Ethiopia, Kenya, Sri Lanka, Uganda, India, Nepal, Bangladesh, Madagascar. Each has different embassy requirements and arrival timelines — we\'ll tell you in chat.'
    }, {
      q: 'Can I see her video and CV before paying?',
      a: 'Yes. We send 3–5 shortlisted profiles, each with a 90-second video, work history, and references. You pick. Deposit only after you\'ve selected.'
    }, {
      q: 'What if I don\'t like her when she arrives?',
      a: 'Free replacement under the same package — we Uber her back to onboarding and ship the next candidate. No re-application fee, no fresh visa cost. Same as our full-time maid replacement policy.'
    }, {
      q: 'Is this legal?',
      a: 'Yes. Maids.cc is a MOHRE Domestic Worker Service Centre (Tadbeer-licensed). All recruitment runs through official channels — POEA, MOHRE, GDRFA. No black-market sourcing, no "buddy" visas.'
    }],
    ctaHeadline: {
      pre: 'Send us her passport.',
      accent: 'See her face at DXB in weeks.'
    },
    ctaSub: 'WhatsApp us with the candidate\'s country, and we\'ll quote you in under a minute. 100% arrival guarantee or your money back.'
  }
};
Object.assign(window, {
  SERVICE_DETAILS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/service-data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/service-detail.jsx
try { (() => {
/* ============================================================================
   SERVICE DETAIL — components for the per-service pages reached from
   the picker "Learn more" link. Reusable layout primitives:
     <DetailHero>       — service name, lede, 2 CTAs, hero placeholder
     <FeatureCompare>   — "what's included" table (us vs them / hire direct)
     <PricingBreakdown> — itemized pricing rows, all-in total at the bottom
     <DetailFaq>        — service-specific FAQ accordion
     <DetailCtaBand>    — last-chance conversion band
   Each takes a config object from service-data.jsx.
   ============================================================================ */

function DetailHero({
  s
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: 'detail-hero tone-' + s.tone,
    id: "top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "detail-hero-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "detail-hero-copy"
  }, /*#__PURE__*/React.createElement("a", {
    href: "index.html",
    className: "detail-back"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-left"
  }), "Back to all services"), /*#__PURE__*/React.createElement("div", {
    className: "detail-eyebrow"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": s.icon
  }), /*#__PURE__*/React.createElement("span", null, s.eyebrow)), /*#__PURE__*/React.createElement("h1", null, s.headline.pre, " ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, s.headline.accent), s.headline.post ? ' ' + s.headline.post : ''), /*#__PURE__*/React.createElement("p", {
    className: "detail-lede"
  }, s.sub), /*#__PURE__*/React.createElement("ul", {
    className: "detail-reassure"
  }, s.reassure.map((r, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check-circle-2"
  }), /*#__PURE__*/React.createElement("span", null, r)))), /*#__PURE__*/React.createElement("div", {
    className: "detail-ctas"
  }, /*#__PURE__*/React.createElement("a", {
    href: wa(s.waMsg),
    target: "_blank",
    rel: "noopener",
    className: 'btn btn-tone-' + s.tone + ' btn-lg wa'
  }, /*#__PURE__*/React.createElement(WaIcon, null), s.primaryCta.label), /*#__PURE__*/React.createElement("a", {
    href: "#pricing",
    className: "detail-skim"
  }, "See pricing", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-down"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "detail-from"
  }, /*#__PURE__*/React.createElement("span", {
    className: "df-from"
  }, "From"), /*#__PURE__*/React.createElement("span", {
    className: "df-amount"
  }, /*#__PURE__*/React.createElement(Dh, {
    size: "0.78em"
  }), s.priceFrom), /*#__PURE__*/React.createElement("span", {
    className: "df-unit"
  }, s.priceUnit), s.priceFootnote && /*#__PURE__*/React.createElement("span", {
    className: "df-note"
  }, "\xB7 ", s.priceFootnote))), /*#__PURE__*/React.createElement("div", {
    className: "detail-hero-media"
  }, /*#__PURE__*/React.createElement(Picture, {
    label: s.heroLabel,
    src: s.heroSrc,
    pos: s.heroPos,
    eager: true,
    tone: s.tone === 'orange' ? 'orange' : 'blue',
    passive: s.heroSrc ? 'none' : 'center',
    rounded: "xl",
    ratio: "4/5"
  }), /*#__PURE__*/React.createElement("div", {
    className: "detail-hero-badge"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "play"
  }), /*#__PURE__*/React.createElement("span", null, "Video tour")))));
}
function FeatureCompare({
  s
}) {
  const {
    cols,
    rows,
    title,
    sub
  } = s.featureTable;
  return /*#__PURE__*/React.createElement("section", {
    className: "detail-section",
    id: "included"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-head left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "What's included"), /*#__PURE__*/React.createElement("h2", null, title), /*#__PURE__*/React.createElement("p", null, sub)), /*#__PURE__*/React.createElement("div", {
    className: "compare-table feature-table"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct-row-label"
  }, "\xA0"), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.key,
    className: 'ct-col-head' + (c.good ? ' good' : '')
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-col-tag"
  }, c.tag), /*#__PURE__*/React.createElement("span", {
    className: "ct-col-name"
  }, c.label)))), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "ct-row",
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct-row-label"
  }, r.row), cols.map(c => {
    const val = r[c.key];
    const isText = typeof val === 'string';
    const isGood = isText ? c.good : !!val;
    return /*#__PURE__*/React.createElement("div", {
      key: c.key,
      className: 'ct-cell' + (isGood ? ' good' : ''),
      "data-col": c.label
    }, isGood ? /*#__PURE__*/React.createElement("i", {
      "data-lucide": "check-circle",
      className: "ct-icon-good"
    }) : /*#__PURE__*/React.createElement("i", {
      "data-lucide": "x",
      className: "ct-icon-bad"
    }), isText && /*#__PURE__*/React.createElement("span", {
      className: "ct-cell-text"
    }, val));
  }))))));
}
function PricingBreakdown({
  s
}) {
  const {
    rows,
    title,
    sub,
    footnote,
    total
  } = s.pricingTable;
  return /*#__PURE__*/React.createElement("section", {
    className: "detail-section detail-section-alt",
    id: "pricing"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-head left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Pricing"), /*#__PURE__*/React.createElement("h2", null, title), /*#__PURE__*/React.createElement("p", null, sub)), /*#__PURE__*/React.createElement("div", {
    className: "pricing-breakdown"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pb-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pb-h-item"
  }, "Item"), /*#__PURE__*/React.createElement("div", {
    className: "pb-h-covers"
  }, "What it covers"), /*#__PURE__*/React.createElement("div", {
    className: "pb-h-cost"
  }, "Cost")), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: 'pb-row' + (r.highlight ? ' highlight' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "pb-item"
  }, r.icon && (r.icon === 'whatsapp' ? /*#__PURE__*/React.createElement(WaIcon, null) : /*#__PURE__*/React.createElement("i", {
    "data-lucide": r.icon
  })), /*#__PURE__*/React.createElement("span", null, r.item)), /*#__PURE__*/React.createElement("div", {
    className: "pb-covers"
  }, r.covers), /*#__PURE__*/React.createElement("div", {
    className: "pb-cost"
  }, r.free ? /*#__PURE__*/React.createElement("span", {
    className: "pb-free"
  }, "Included") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Dh, {
    size: "0.7em"
  }), r.cost, /*#__PURE__*/React.createElement("span", {
    className: "pb-unit"
  }, r.unit || ''))))), total && /*#__PURE__*/React.createElement("div", {
    className: "pb-row pb-total"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pb-item"
  }, /*#__PURE__*/React.createElement("span", null, total.label)), /*#__PURE__*/React.createElement("div", {
    className: "pb-covers"
  }, total.covers), /*#__PURE__*/React.createElement("div", {
    className: "pb-cost"
  }, /*#__PURE__*/React.createElement(Dh, {
    size: "0.7em"
  }), total.cost, /*#__PURE__*/React.createElement("span", {
    className: "pb-unit"
  }, total.unit)))), footnote && /*#__PURE__*/React.createElement("p", {
    className: "pb-footnote"
  }, footnote)));
}
function DetailFaq({
  s
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "faq faq-dark",
    id: "faq"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "faq-title"
  }, "About ", s.eyebrow.toLowerCase()), /*#__PURE__*/React.createElement("div", {
    className: "faq-list"
  }, s.faq.map((f, i) => /*#__PURE__*/React.createElement("details", {
    key: i,
    className: "faq-item"
  }, /*#__PURE__*/React.createElement("summary", null, /*#__PURE__*/React.createElement("span", null, f.q), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-down",
    className: "faq-chev"
  })), /*#__PURE__*/React.createElement("p", null, f.a))))));
}
function DetailCtaBand({
  s
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "recap",
    id: "hire"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "recap-card"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Ready when you are"), /*#__PURE__*/React.createElement("h2", null, s.ctaHeadline.pre, " ", /*#__PURE__*/React.createElement("span", {
    className: "accent"
  }, s.ctaHeadline.accent)), /*#__PURE__*/React.createElement("p", null, s.ctaSub), /*#__PURE__*/React.createElement("div", {
    className: "recap-cta"
  }, /*#__PURE__*/React.createElement("a", {
    href: wa(s.waMsg),
    target: "_blank",
    rel: "noopener",
    className: 'btn btn-tone-' + s.tone + ' btn-xl wa'
  }, /*#__PURE__*/React.createElement(WaIcon, null), s.primaryCta.label)), /*#__PURE__*/React.createElement("div", {
    className: "recap-trust"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shield-check"
  }), /*#__PURE__*/React.createElement("span", null, "Tadbeer-licensed \xB7 24/7 real-person support \xB7 Cancel anytime")))));
}

/* ============================================================================
   OTHER SERVICES — bottom "Explore the rest" cards. Shows the 3 other
   services as compact cards linking to their detail page.
   ============================================================================ */
const OTHER_SERVICES_META = {
  fulltime: {
    tone: 'blue',
    icon: 'sparkles',
    title: 'Full-time maid',
    sub: 'Live-in or live-out · from AED 2,980/mo'
  },
  parttime: {
    tone: 'green',
    icon: 'clock',
    title: 'Part-time maid or nanny',
    sub: 'Same maid · from AED 35/hour'
  },
  visa: {
    tone: 'orange',
    icon: 'badge-check',
    title: '2-year maid visa',
    sub: 'Ready in 7 days · from AED 8,500'
  },
  overseas: {
    tone: 'orange',
    icon: 'plane-landing',
    title: 'Bring a maid from abroad',
    sub: 'Visas, flights, paperwork · arrival guarantee'
  }
};
function OtherServices({
  currentKey
}) {
  const keys = Object.keys(OTHER_SERVICES_META).filter(k => k !== currentKey);
  return /*#__PURE__*/React.createElement("section", {
    className: "other-services"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-head left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "overline"
  }, "Looking for something else?"), /*#__PURE__*/React.createElement("h2", null, "Explore the rest.")), /*#__PURE__*/React.createElement("div", {
    className: "os-grid"
  }, keys.map(k => {
    const m = OTHER_SERVICES_META[k];
    return /*#__PURE__*/React.createElement("a", {
      key: k,
      href: 'service-' + k + '.html',
      className: 'os-card tone-' + m.tone
    }, /*#__PURE__*/React.createElement("div", {
      className: "os-icon"
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": m.icon
    })), /*#__PURE__*/React.createElement("div", {
      className: "os-body"
    }, /*#__PURE__*/React.createElement("h3", null, m.title), /*#__PURE__*/React.createElement("p", null, m.sub)), /*#__PURE__*/React.createElement("i", {
      "data-lucide": "arrow-right",
      className: "os-arrow"
    }));
  }))));
}
function ServiceDetailPage({
  s
}) {
  React.useEffect(() => {
    lucide.createIcons();
    // Entrance fade-up — one-shot staggered reveal on load. (Reliable across
    // environments; doesn't depend on IntersectionObserver firing for
    // already-visible content, which left the page blank in some contexts.)
    const targets = document.querySelectorAll('.detail-hero-copy > *, .detail-hero-media, .ct-row, .pb-row, .pb-total, .faq-item, .os-card, .recap-card');
    targets.forEach((el, i) => {
      el.classList.add('fade-up');
      el.style.setProperty('--i', i % 8);
    });
    // Let the hidden initial state paint, then transition everything in.
    const raf = requestAnimationFrame(() => requestAnimationFrame(() => {
      targets.forEach(el => el.classList.add('in-view'));
    }));
    // Safety net: setTimeout fires even when frames don't (hidden tab / capture
    // / export), so content is never stuck at opacity:0.
    const revealFallback = setTimeout(() => targets.forEach(el => el.classList.add('in-view')), 1600);
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(revealFallback);
    };
  }, []);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Nav, null), /*#__PURE__*/React.createElement(DetailHero, {
    s: s
  }), /*#__PURE__*/React.createElement(FeatureCompare, {
    s: s
  }), /*#__PURE__*/React.createElement(PricingBreakdown, {
    s: s
  }), /*#__PURE__*/React.createElement(DetailFaq, {
    s: s
  }), /*#__PURE__*/React.createElement(OtherServices, {
    currentKey: s.key
  }), /*#__PURE__*/React.createElement(DetailCtaBand, {
    s: s
  }), /*#__PURE__*/React.createElement(Footer, null), /*#__PURE__*/React.createElement(WhatsappFab, null), /*#__PURE__*/React.createElement(StickyMobileBar, {
    current: s.key
  }));
}
Object.assign(window, {
  DetailHero,
  FeatureCompare,
  PricingBreakdown,
  DetailFaq,
  DetailCtaBand,
  OtherServices,
  ServiceDetailPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/service-detail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/social/components.jsx
try { (() => {
/* global React, useTweaks */
const {
  useState,
  useMemo
} = React;

/* ================================================================
   SOCIAL-ONLY TYPE SCALE
   Sourced directly from `uploads/Social media size.pdf` — the
   brand-supplied layout PDF whose three pages spec the exact
   font sizes for each format on a 1080-wide canvas.
   ================================================================ */
const TYPE = {
  // Headline sizes per format (from PDF)
  headlineSquare: 64,
  headlinePortrait: 68,
  headlineStory: 88,
  headlineLandscape: 56,
  // extrapolated (no PDF page for 16:9)
  // Subhead sizes per format
  subheadSquare: 34,
  subheadPortrait: 36,
  subheadStory: 40,
  subheadLandscape: 30,
  // Badge / tag text — PDF uses 30 px in all three formats
  badge: 30,
  // Body for bullets / attribution (slightly under subhead)
  bodyMD: 28,
  bodySM: 24,
  // KPI / mega price
  kpi: 200,
  kpiSM: 140
};
const HEADLINE_FOR = {
  portrait: TYPE.headlinePortrait,
  square: TYPE.headlineSquare,
  story: TYPE.headlineStory,
  landscape: TYPE.headlineLandscape
};
const SUBHEAD_FOR = {
  portrait: TYPE.subheadPortrait,
  square: TYPE.subheadSquare,
  story: TYPE.subheadStory,
  landscape: TYPE.subheadLandscape
};

/* ================================================================
   SPACING SCALE — canvas-space px on a 4-px grid.
   Per-format overrides give Story more vertical air and Landscape
   tighter packing. Everything in the templates that used a magic
   number now reads from SP or GAP.
   ================================================================ */
const SP = {
  xs: 12,
  sm: 24,
  md: 40,
  lg: 64,
  xl: 96,
  xxl: 128
};

/** Gap between major content blocks (headline→subhead, subhead→image, etc).
  * Scales by format: Story is roomy, Landscape is tight. */
const GAP = {
  portrait: {
    headlineToSub: 24,
    subToBody: 48,
    blockToCta: 64,
    ctaToLogo: 32
  },
  square: {
    headlineToSub: 20,
    subToBody: 40,
    blockToCta: 56,
    ctaToLogo: 28
  },
  story: {
    headlineToSub: 32,
    subToBody: 64,
    blockToCta: 96,
    ctaToLogo: 40
  },
  landscape: {
    headlineToSub: 16,
    subToBody: 24,
    blockToCta: 32,
    ctaToLogo: 20
  }
};

/** Vertical height the bottom logo occupies, with breathing room. */
function logoH(format) {
  return LOGO_W[format] / LOGO_RATIO;
}

/** Line-height multiplier for headlines. */
const HEADLINE_LH = 1.05;

/* Logo width in canvas-px. Measured 279–281 px across all four 1080-native
   reference posts (arrivals, thumbnails footer, chores top, indian bottom). */
const LOGO_W = {
  portrait: 280,
  square: 280,
  story: 280,
  landscape: 200
};

/* ================================================================
   SAFE ZONES (canvas-space px). Bumped insets so important content
   doesn't crowd the canvas edge. Story reserves IG's profile header
   + CTA/reply bar exactly per spec.
   ================================================================ */
const SAFE = {
  portrait: {
    top: 96,
    right: 96,
    bottom: 96,
    left: 96,
    feedCrop: {
      top: 135,
      bottom: 135
    }
  },
  square: {
    top: 80,
    right: 80,
    bottom: 80,
    left: 80
  },
  story: {
    top: 280,
    right: 96,
    bottom: 420,
    left: 96
  },
  landscape: {
    top: 56,
    right: 56,
    bottom: 56,
    left: 56
  }
};
const CANVAS = {
  portrait: {
    w: 1080,
    h: 1350
  },
  square: {
    w: 1080,
    h: 1080
  },
  story: {
    w: 1080,
    h: 1920
  },
  landscape: {
    w: 1200,
    h: 675
  }
};
const FORMATS = [{
  key: 'portrait',
  label: '4:5 · 1080×1350',
  name: 'Instagram feed'
}, {
  key: 'square',
  label: '1:1 · 1080×1080',
  name: 'Square feed'
}, {
  key: 'story',
  label: '9:16 · 1080×1920',
  name: 'Story / Reel'
}, {
  key: 'landscape',
  label: '16:9 · 1200×675',
  name: 'X / LinkedIn'
}];
const TEMPLATES = [{
  key: 'profile',
  name: 'Maid profile',
  desc: 'Photo card with "Hire Now" pill.'
}, {
  key: 'promise',
  name: 'Promise poster',
  desc: 'Quadrangle headline + parallelogram footer.'
}, {
  key: 'price',
  name: 'Service price',
  desc: 'All-in monthly with benefit bullets.'
}, {
  key: 'quote',
  name: 'Testimonial',
  desc: 'Five-star review pull-quote.'
}, {
  key: 'available',
  name: 'Availability',
  desc: '"Arriving today" hourly hook.'
}, {
  key: 'tip',
  name: 'Education tip',
  desc: 'Conversational tip with brand stamp.'
}];
const SERVICES = {
  livein: {
    label: 'Live-in maid',
    pill: 'Hire now',
    token: 'var(--maids-blue)'
  },
  hourly: {
    label: 'Hourly help',
    pill: 'Arriving today',
    token: 'var(--maids-green)'
  },
  visa: {
    label: 'Visa services',
    pill: '7-day visa',
    token: 'var(--maids-orange)'
  }
};
const DEFAULTS = /*EDITMODE-BEGIN*/{
  "format": "portrait",
  "template": "profile",
  "service": "livein",
  "headline": "Your full-time maid. In your home today.",
  "subhead": "All-in AED 2,980/month. WhatsApp us · in 5 min.",
  "badge": "Hire now",
  "price": "2,980",
  "priceUnit": "AED / month · all-in",
  "ctaPhone": "+971 800 624 377",
  "chatCta": "Chat on WhatsApp · 5 min",
  "trustStamp": "7-day money\nback guarantee",
  "quote": "Booked her on WhatsApp Tuesday — she was in our home Friday.",
  "quoteWho": "Reem · Dubai · 2 yrs with maids.cc",
  "tip": "Some chores are too scary to face alone.",
  "tipBody": "Get a full-time maid today. From AED 2,980/month · 7-day money back.",
  "showSafeZones": false
} /*EDITMODE-END*/;

/* ================================================================
   BRAND BUILDING BLOCKS
   ================================================================ */

const LOGO_BLUE = '../../assets/logos/maids-logo-blue.png';
const LOGO_WHITE = '../../assets/logos/maids-logo-white.png';
const LOGO_RATIO = 1835 / 519; // ≈ 3.535

/** Lockup using the real PNG wordmarks. */
function BrandLogo({
  tone = 'blue',
  width = 280,
  style
}) {
  const src = tone === 'white' ? LOGO_WHITE : LOGO_BLUE;
  return /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "maids.cc + nannies + visa services",
    style: {
      width,
      height: width / LOGO_RATIO,
      display: 'block',
      ...style
    }
  });
}

// Floating-quadrangle radius — anything that does NOT touch the frame edge
// uses this exact value. Edge-bleeding shapes (parallelogram footer) skip it.
const Q_RADIUS = 23;

/**
 * Quadrangle frame — pure rounded rectangle. The brand language is clean
 * geometry; no clip-path slants, no tails. Use for service tags, badges,
 * inline callouts that aren't edge-bleeding.
 */
function QuadFrame({
  bg = 'var(--maids-blue)',
  color = '#fff',
  radius = Q_RADIUS,
  pad = '20px 32px',
  style,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      color,
      borderRadius: radius,
      padding: pad,
      fontWeight: 700,
      lineHeight: 1.15,
      letterSpacing: '-0.005em',
      textWrap: 'balance',
      boxSizing: 'border-box',
      ...style
    }
  }, children);
}

/**
 * TrustStamp — small bottom-right orange guarantee stamp. The PDF spec
 * uses this at exactly 30 px text on all three formats ("7-day money /
 * back guarantee"). Two-line, balanced, sits in the corner.
 */
function TrustStamp({
  children,
  format,
  style
}) {
  const s = SAFE[format];
  return /*#__PURE__*/React.createElement(QuadFrame, {
    bg: "var(--maids-orange)",
    color: "#fff",
    pad: "20px 28px",
    style: {
      position: 'absolute',
      right: s.right,
      bottom: s.bottom,
      fontSize: TYPE.badge,
      lineHeight: 1.2,
      maxWidth: 320,
      textAlign: 'left',
      fontWeight: 700,
      ...style
    }
  }, children);
}

/**
 * Image placeholder — solid blue color block with diagonal stripes and a
 * monospace label. Never gradients between brand colors (brand rule).
 */
function ImageSlot({
  label = 'image',
  tone = 'blue',
  style
}) {
  const bg = tone === 'blue' ? 'repeating-linear-gradient(45deg, #1F3A78 0 22px, #25499B 22px 44px)' : tone === 'orange' ? 'repeating-linear-gradient(45deg, #D44E14 0 22px, #EE6124 22px 44px)' : 'repeating-linear-gradient(45deg, #E5E7EB 0 22px, #F2F5FB 22px 44px)';
  const labelColor = tone === 'light' ? 'rgba(37,73,155,0.55)' : 'rgba(255,255,255,0.55)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      borderRadius: Q_RADIUS,
      overflow: 'hidden',
      background: bg,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: labelColor,
      fontFamily: 'var(--font-mono, ui-monospace)',
      fontSize: 22,
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      fontWeight: 600
    }
  }, label));
}

/**
 * FramePhoto — full-bleed photo placeholder. The brand shoots photos
 * with intentional passive space for text + branding, so the photo IS
 * the frame. Pass `passive` to mark where the safe text zone sits
 * ("top" | "bottom" | "left" | "right" | "center" | "none"); a soft
 * brand-blue gradient is added to that zone for legibility.
 */
function FramePhoto({
  label = 'photo · brand',
  passive = 'none',
  tint = 'blue'
}) {
  const bg = tint === 'blue' ? 'repeating-linear-gradient(45deg, #1F3A78 0 28px, #25499B 28px 56px)' : 'repeating-linear-gradient(45deg, #E5E7EB 0 28px, #F2F5FB 28px 56px)';
  const labelColor = tint === 'light' ? 'rgba(37,73,155,0.55)' : 'rgba(255,255,255,0.55)';
  // Passive-zone overlay: deep-blue gradient where text will sit.
  const overlays = {
    top: 'linear-gradient(to bottom, rgba(22,48,104,0.55) 0%, rgba(22,48,104,0.25) 35%, rgba(22,48,104,0) 60%)',
    bottom: 'linear-gradient(to top,    rgba(22,48,104,0.55) 0%, rgba(22,48,104,0.25) 35%, rgba(22,48,104,0) 60%)',
    left: 'linear-gradient(to right,  rgba(22,48,104,0.65) 0%, rgba(22,48,104,0.25) 35%, rgba(22,48,104,0) 55%)',
    right: 'linear-gradient(to left,   rgba(22,48,104,0.55) 0%, rgba(22,48,104,0.25) 35%, rgba(22,48,104,0) 55%)',
    center: 'radial-gradient(ellipse at center, rgba(22,48,104,0.55) 0%, rgba(22,48,104,0) 60%)',
    none: null
  }[passive];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: bg
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: labelColor,
      fontFamily: 'var(--font-mono, ui-monospace)',
      fontSize: 24,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      fontWeight: 600
    }
  }, label)), overlays && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: overlays
    }
  }));
}

/**
 * Parallelogram footer — bottom-anchored blue plank with the real PNG wordmark
 * inside, and an orange tag sitting on the slanted edge. Used by the carousel/
 * profile template (matches social-thumbnails.png).
 */
function ParallelogramFooter({
  width = '72%',
  height = 240,
  cta,
  format,
  logoTone = 'white'
}) {
  // SVG plank: 4 corners. Visible corners (the slanted top-right edge
  // and the bottom-right corner) get the brand 23 px radius. The two
  // left corners bleed off-canvas — 0 radius is fine there.
  const R = Q_RADIUS;
  const SLANT = 64;
  // Path coords use a viewBox; we render at 1000 wide and let it stretch.
  // Points (clockwise): TL(0,0) → TR(1000-SLANT, 0) → BR(1000, H) → BL(0, H)
  // The visible inner corners are TR and BR. We round those to R.
  const H = 100; // viewBox height; preserveAspectRatio='none' to stretch.
  // Build a rounded path: go to top-left, line to (top-right minus R along the slanted edge),
  // arc to a point R below on the slanted edge, line to bottom-right minus R, arc to bottom-right - R,
  // then back. To keep math simple, we approximate by rounding only the two visible corners with
  // short arcs along the actual edge directions.
  const r = R * (H / height); // scale radius into viewBox H units
  // Compute the slant direction unit vector (from TR going to BR).
  const slantDX = SLANT,
    slantDY = H;
  const slantLen = Math.hypot(slantDX, slantDY);
  const ux = slantDX / slantLen,
    uy = slantDY / slantLen;
  // Top-right corner: incoming dir = +x, outgoing dir = (ux, uy). Round between them.
  const trX = 1000 - SLANT,
    trY = 0;
  // pull back along incoming (x-axis), and forward along slant
  const trIn = {
    x: trX - r,
    y: trY
  };
  const trOut = {
    x: trX + ux * r,
    y: trY + uy * r
  };
  // Bottom-right corner: incoming dir = (ux, uy), outgoing dir = -x. Round.
  const brX = 1000,
    brY = H;
  const brIn = {
    x: brX - ux * r,
    y: brY - uy * r
  };
  const brOut = {
    x: brX - r,
    y: brY
  };
  const d = [`M 0 0`, `L ${trIn.x} ${trIn.y}`, `Q ${trX} ${trY} ${trOut.x} ${trOut.y}`, `L ${brIn.x} ${brIn.y}`, `Q ${brX} ${brY} ${brOut.x} ${brOut.y}`, `L 0 ${H}`, `Z`].join(' ');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      height,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 1000 ${H}`,
    preserveAspectRatio: "none",
    style: {
      position: 'absolute',
      left: 0,
      bottom: 0,
      width,
      height: '100%',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: d,
    fill: "var(--maids-blue)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      bottom: 0,
      width,
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      paddingLeft: 80
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    tone: logoTone,
    width: LOGO_W[format]
  })), cta && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 80,
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }, /*#__PURE__*/React.createElement(ChatBadge, {
    size: "md"
  }, cta)));
}

/** Five-star row in brand orange. */
function StarsRow({
  size = 56
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: size,
      color: 'var(--maids-orange)',
      fontWeight: 700,
      letterSpacing: '0.18em',
      lineHeight: 1
    }
  }, "\u2605\u2605\u2605\u2605\u2605");
}

/**
 * ChatBadge — the conversion lever. Green WhatsApp pill with a small
 * speech-bubble glyph + the chat-channel copy. Every paid post should
 * carry one of these. Big enough to read on a 4" thumbnail, small enough
 * not to fight the headline.
 */
function ChatBadge({
  children = 'Chat on WhatsApp · 5 min',
  size = 'md',
  style
}) {
  const dims = size === 'lg' ? {
    fs: 36,
    pad: '20px 32px 20px 28px',
    icon: 32
  } : size === 'sm' ? {
    fs: 26,
    pad: '14px 24px 14px 22px',
    icon: 22
  } : {
    fs: 30,
    pad: '18px 28px 18px 26px',
    icon: 26
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 14,
      background: 'var(--maids-green)',
      color: '#fff',
      fontWeight: 700,
      fontSize: dims.fs,
      lineHeight: 1.1,
      padding: dims.pad,
      borderRadius: 999,
      boxShadow: '0 8px 20px rgba(21, 184, 134, 0.32)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 32 32",
    width: dims.icon,
    height: dims.icon,
    fill: "#fff",
    "aria-hidden": "true",
    focusable: "false",
    style: {
      flexShrink: 0,
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M16.004 0h-.008C7.174 0 0 7.176 0 16c0 3.5 1.128 6.744 3.046 9.378L1.05 31.31l6.137-1.961C9.717 31.018 12.74 32 16.004 32 24.826 32 32 24.822 32 16S24.826 0 16.004 0zm9.31 22.594c-.386 1.09-1.918 1.994-3.14 2.258-.836.178-1.928.32-5.604-1.204-4.7-1.948-7.726-6.724-7.962-7.034-.226-.31-1.9-2.53-1.9-4.826 0-2.296 1.166-3.424 1.636-3.904.386-.394.844-.574 1.298-.574.146 0 .278.008.398.014.47.02.706.048 1.016.79.386.93 1.326 3.226 1.438 3.462.114.236.228.554.07.864-.148.32-.278.46-.514.736-.236.276-.46.488-.696.784-.216.258-.46.534-.188.998.272.454 1.21 1.994 2.6 3.23 1.794 1.594 3.274 2.088 3.786 2.302.382.158.836.12 1.116-.186.354-.394.79-1.046 1.234-1.688.314-.46.71-.518 1.126-.362.424.148 2.71 1.276 3.18 1.51.47.236.78.35.894.546.112.196.112 1.13-.274 2.22z"
  })), /*#__PURE__*/React.createElement("span", null, children));
}

/**
 * PricePill — small price anchor ("from AED 2,980 / mo"). Use in posts
 * that aren't price-led but still need the value-prop visible at a glance.
 */
function PricePill({
  amount,
  unit,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: 8,
      background: '#fff',
      color: 'var(--maids-blue)',
      fontWeight: 700,
      fontSize: TYPE.badge,
      lineHeight: 1.1,
      padding: '14px 22px',
      borderRadius: Q_RADIUS,
      letterSpacing: '-0.005em',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.7,
      fontWeight: 600
    }
  }, "from"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: TYPE.badge + 6
    }
  }, "AED ", amount), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.7,
      fontWeight: 600
    }
  }, unit));
}

/** Safe-zone overlay — translucent red over the reserved areas. */
function SafeZoneOverlay({
  format
}) {
  const s = SAFE[format];
  const label = {
    position: 'absolute',
    fontFamily: 'var(--font-mono, ui-monospace)',
    fontSize: 18,
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    color: '#fff',
    background: 'rgba(220, 38, 38, 0.92)',
    padding: '6px 10px',
    borderRadius: 4
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none',
      zIndex: 1000
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: s.top,
      background: 'rgba(220,38,38,0.18)',
      borderBottom: '2px dashed rgba(220,38,38,0.8)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      height: s.bottom,
      background: 'rgba(220,38,38,0.18)',
      borderTop: '2px dashed rgba(220,38,38,0.8)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: s.top,
      bottom: s.bottom,
      left: 0,
      width: s.left,
      background: 'rgba(220,38,38,0.12)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: s.top,
      bottom: s.bottom,
      right: 0,
      width: s.right,
      background: 'rgba(220,38,38,0.12)'
    }
  }), format === 'portrait' && s.feedCrop && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: s.feedCrop.top,
      left: 0,
      right: 0,
      borderTop: '2px dashed rgba(20, 184, 166, 0.9)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: s.feedCrop.bottom,
      left: 0,
      right: 0,
      borderBottom: '2px dashed rgba(20, 184, 166, 0.9)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...label,
      top: s.feedCrop.top + 8,
      right: 12,
      background: 'rgba(13,148,136,0.92)'
    }
  }, "1:1 feed crop")), format === 'story' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      ...label,
      top: 12,
      left: 12
    }
  }, "Profile reserved"), /*#__PURE__*/React.createElement("div", {
    style: {
      ...label,
      bottom: 12,
      left: 12
    }
  }, "CTA / reply reserved")));
}

/* ================================================================
   TEMPLATES — two recurring layouts from the brand's existing posts:

   A · PDF BASE (page 1 / page 3 of the brand layout PDF)
        ┌────────────────────────────────────┐
        │ HEADLINE  (top-left, blue or white)│
        │ subhead   (below)                  │
        │                                    │
        │      [   image area   ]            │
        │                          [stamp]   │
        │ [maids.cc logo]                    │
        └────────────────────────────────────┘

   B · FOOTER PLANK (social-thumbnails.png)
        ┌────────────────────────────────────┐
        │ HEADLINE  (centered or top)        │
        │ [ photo carousel / hero ]          │
        │ ╲                                  │
        │  ╲ blue parallelogram plank ─ tag  │
        │   ╲ logo                           │
        └────────────────────────────────────┘
   ================================================================ */

/** Profile / carousel — Layout B, footer plank. */
function ProfileTemplate({
  t,
  format,
  svc
}) {
  const s = SAFE[format];
  const c = CANVAS[format];
  const isLand = format === 'landscape';
  const footerH = isLand ? 160 : format === 'story' ? 280 : 240;

  // Headline area takes the top band on portrait/square/story
  const headlineTop = s.top;
  const headlineH = isLand ? 0 : HEADLINE_FOR[format] * HEADLINE_LH * 2;
  const cardTop = headlineTop + headlineH + GAP[format].subToBody;
  const cardBottom = footerH + GAP[format].blockToCta - SP.sm;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: '#F2F5FB'
    }
  }), !isLand && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: s.right,
      top: headlineTop,
      color: 'var(--maids-blue)',
      fontWeight: 700,
      fontSize: HEADLINE_FOR[format],
      lineHeight: HEADLINE_LH,
      letterSpacing: '-0.02em',
      textWrap: 'balance'
    }
  }, "Hire from ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--maids-orange)'
    }
  }, "200+"), " maids and nannies"), /*#__PURE__*/React.createElement(ImageSlot, {
    label: "maid \xB7 video",
    tone: "blue",
    style: {
      top: isLand ? s.top : cardTop,
      bottom: cardBottom,
      left: isLand ? c.w * 0.42 : s.left + SP.lg,
      right: isLand ? s.right : s.right + SP.lg
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: (isLand ? c.w * 0.42 : s.left + SP.lg) + SP.sm,
      top: (isLand ? s.top : cardTop) + SP.sm,
      background: 'var(--maids-green)',
      color: '#fff',
      fontWeight: 700,
      fontSize: TYPE.badge,
      lineHeight: 1,
      padding: '14px 28px',
      borderRadius: 999
    }
  }, t.badge || svc.pill), /*#__PURE__*/React.createElement(ParallelogramFooter, {
    format: format,
    height: footerH,
    width: isLand ? '46%' : '72%',
    cta: isLand ? null : t.chatCta
  }));
}

/** Promise — Layout A, PDF base. Full-bleed photo with passive zones for text. */
function PromiseTemplate({
  t,
  format,
  svc
}) {
  const s = SAFE[format];
  const c = CANVAS[format];
  const isLand = format === 'landscape';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(FramePhoto, {
    label: "photo \xB7 maid in the home",
    tint: "blue",
    passive: isLand ? 'left' : 'bottom'
  }), !isLand && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to bottom, rgba(22,48,104,0.55) 0%, rgba(22,48,104,0.25) 30%, rgba(22,48,104,0) 55%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: s.right,
      top: s.top,
      color: '#fff',
      fontWeight: 700,
      fontSize: HEADLINE_FOR[format],
      lineHeight: HEADLINE_LH,
      letterSpacing: '-0.02em',
      textWrap: 'balance',
      textShadow: '0 2px 12px rgba(0,0,0,0.25)'
    }
  }, t.headline), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: s.right,
      top: s.top + HEADLINE_FOR[format] * HEADLINE_LH * 2 + GAP[format].headlineToSub,
      color: 'rgba(255,255,255,0.95)',
      fontWeight: 500,
      fontSize: SUBHEAD_FOR[format],
      lineHeight: 1.35,
      maxWidth: c.w * 0.7,
      textShadow: '0 2px 8px rgba(0,0,0,0.25)'
    }
  }, t.subhead), /*#__PURE__*/React.createElement(TrustStamp, {
    format: format
  }, t.trustStamp.split('\n').map((ln, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), ln))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom + logoH(format) + GAP[format].ctaToLogo
    }
  }, /*#__PURE__*/React.createElement(ChatBadge, null, t.chatCta)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    tone: "white",
    width: LOGO_W[format]
  })));
}

/** Price — service tag, mega price, bullets, stamp, logo. */
function PriceTemplate({
  t,
  format,
  svc
}) {
  const s = SAFE[format];
  const isLand = format === 'landscape';
  const bullets = ['All-in monthly · no hidden fees', 'Visa, medical, Emirates ID — handled', 'Free replacements · unlimited', '7-day money-back guarantee'];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: '#fff'
    }
  }), /*#__PURE__*/React.createElement(QuadFrame, {
    bg: svc.token,
    color: "#fff",
    pad: "14px 24px",
    style: {
      position: 'absolute',
      left: s.left,
      top: s.top,
      fontSize: TYPE.badge,
      display: 'inline-block'
    }
  }, svc.label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      top: s.top + TYPE.badge + SP.md + SP.sm
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: isLand ? TYPE.kpiSM : TYPE.kpi,
      lineHeight: 0.85,
      letterSpacing: '-0.04em',
      color: 'var(--maids-blue)'
    }
  }, "AED\xA0", /*#__PURE__*/React.createElement("span", {
    style: {
      color: svc.token
    }
  }, t.price)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: SP.sm - 6,
      fontSize: SUBHEAD_FOR[format],
      fontWeight: 600,
      color: 'var(--maids-blue)'
    }
  }, t.priceUnit)), /*#__PURE__*/React.createElement("ul", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom + logoH(format) + GAP[format].ctaToLogo + SP.lg + SP.md + 60,
      listStyle: 'none',
      padding: 0,
      margin: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: SP.xs + 2,
      color: 'var(--maids-blue)',
      fontSize: TYPE.bodyMD,
      fontWeight: 600,
      maxWidth: 760
    }
  }, bullets.map((b, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: 999,
      border: '2.5px solid currentColor',
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 4,
      borderRadius: 999,
      background: 'currentColor'
    }
  })), b))), /*#__PURE__*/React.createElement(TrustStamp, {
    format: format
  }, t.trustStamp.split('\n').map((ln, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), ln))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom + logoH(format) + GAP[format].ctaToLogo
    }
  }, /*#__PURE__*/React.createElement(ChatBadge, null, t.chatCta)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    tone: "blue",
    width: LOGO_W[format]
  })));
}

/** Quote — full-frame customer photo + testimonial overlay. */
function QuoteTemplate({
  t,
  format,
  svc
}) {
  const s = SAFE[format];
  const isLand = format === 'landscape';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(FramePhoto, {
    label: "photo \xB7 happy customer",
    tint: "blue",
    passive: isLand ? 'right' : 'top'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to top, rgba(22,48,104,0.65) 0%, rgba(22,48,104,0.25) 30%, rgba(22,48,104,0) 55%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      top: s.top
    }
  }, /*#__PURE__*/React.createElement(StarsRow, {
    size: isLand ? 40 : 52
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: s.right,
      top: s.top + (isLand ? 60 : 88),
      color: '#fff',
      fontWeight: 700,
      fontSize: HEADLINE_FOR[format],
      lineHeight: 1.1,
      letterSpacing: '-0.02em',
      textWrap: 'balance',
      textShadow: '0 2px 12px rgba(0,0,0,0.35)'
    }
  }, "\u201C", t.quote, "\u201D"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: s.right,
      bottom: s.bottom + logoH(format) + GAP[format].ctaToLogo,
      fontSize: SUBHEAD_FOR[format],
      fontWeight: 600,
      color: 'rgba(255,255,255,0.92)',
      textShadow: '0 2px 8px rgba(0,0,0,0.25)'
    }
  }, "\u2014 ", t.quoteWho), !isLand && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: s.right,
      bottom: s.bottom
    }
  }, /*#__PURE__*/React.createElement(ChatBadge, {
    size: "sm"
  }, t.chatCta)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    tone: "white",
    width: LOGO_W[format]
  })));
}

/** Available — full-frame photo with left blue overlay column (social-arrivals). */
function AvailableTemplate({
  t,
  format,
  svc
}) {
  const s = SAFE[format];
  const c = CANVAS[format];
  const isLand = format === 'landscape';
  const splitX = isLand ? c.w * 0.5 : c.w * 0.46;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(FramePhoto, {
    label: "photo \xB7 maid arriving",
    tint: "blue",
    passive: "none"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: splitX,
      background: 'var(--maids-blue)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      top: s.top,
      background: 'var(--maids-green)',
      color: '#fff',
      fontWeight: 700,
      fontSize: TYPE.badge,
      lineHeight: 1,
      padding: '14px 28px',
      borderRadius: 999
    }
  }, t.badge || svc.pill), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: c.w - splitX + SP.sm,
      top: s.top + TYPE.badge + SP.md,
      color: '#fff',
      fontWeight: 700,
      fontSize: HEADLINE_FOR[format],
      lineHeight: HEADLINE_LH,
      letterSpacing: '-0.02em',
      textWrap: 'balance'
    }
  }, t.headline), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: c.w - splitX + SP.sm,
      top: s.top + TYPE.badge + SP.md + HEADLINE_FOR[format] * HEADLINE_LH * 2 + GAP[format].headlineToSub,
      color: 'rgba(255,255,255,0.92)',
      fontWeight: 500,
      fontSize: SUBHEAD_FOR[format],
      lineHeight: 1.35
    }
  }, t.subhead), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom + logoH(format) + GAP[format].ctaToLogo + 72 + SP.sm
    }
  }, /*#__PURE__*/React.createElement(QuadFrame, {
    bg: "var(--maids-orange)",
    color: "#fff",
    pad: "20px 28px",
    style: {
      fontSize: TYPE.badge,
      lineHeight: 1.2,
      maxWidth: 280,
      fontWeight: 700
    }
  }, t.trustStamp.split('\n').map((ln, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), ln)))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom + logoH(format) + GAP[format].ctaToLogo
    }
  }, /*#__PURE__*/React.createElement(ChatBadge, {
    size: "sm"
  }, t.chatCta)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      bottom: s.bottom
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    tone: "white",
    width: LOGO_W[format]
  })));
}

/** Tip — full-frame photo with brand-blue passive zones top + bottom. */
function TipTemplate({
  t,
  format,
  svc
}) {
  const s = SAFE[format];
  const isLand = format === 'landscape';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(FramePhoto, {
    label: "photo \xB7 relatable object",
    tint: "blue",
    passive: "center"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to bottom, rgba(22,48,104,0.85) 0%, rgba(22,48,104,0.55) 22%, rgba(22,48,104,0.05) 45%, rgba(22,48,104,0.05) 55%, rgba(22,48,104,0.55) 78%, rgba(22,48,104,0.85) 100%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: s.top,
      left: 0,
      right: 0,
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    tone: "white",
    width: LOGO_W[format]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left,
      right: s.right,
      top: s.top + logoH(format) + GAP[format].subToBody,
      color: '#fff',
      fontWeight: 700,
      fontSize: HEADLINE_FOR[format],
      lineHeight: HEADLINE_LH,
      letterSpacing: '-0.02em',
      textWrap: 'balance',
      textAlign: 'center',
      textShadow: '0 2px 12px rgba(0,0,0,0.35)'
    }
  }, t.tip), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: s.left + SP.md,
      right: s.right + SP.md,
      top: s.top + logoH(format) + GAP[format].subToBody + HEADLINE_FOR[format] * HEADLINE_LH * 2 + GAP[format].headlineToSub,
      color: 'rgba(255,255,255,0.92)',
      fontWeight: 500,
      fontSize: SUBHEAD_FOR[format],
      lineHeight: 1.4,
      textAlign: 'center',
      textWrap: 'pretty',
      textShadow: '0 2px 8px rgba(0,0,0,0.25)'
    }
  }, t.tipBody), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: s.bottom,
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(ChatBadge, {
    size: isLand ? 'md' : 'lg'
  }, t.chatCta)), !isLand && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: s.right,
      top: s.top
    }
  }, /*#__PURE__*/React.createElement(QuadFrame, {
    bg: "var(--maids-orange)",
    color: "#fff",
    pad: "16px 24px",
    style: {
      fontSize: TYPE.badge,
      lineHeight: 1.2,
      maxWidth: 260,
      fontWeight: 700
    }
  }, t.trustStamp.split('\n').map((ln, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), ln)))));
}
const TEMPLATE_FNS = {
  profile: ProfileTemplate,
  promise: PromiseTemplate,
  price: PriceTemplate,
  quote: QuoteTemplate,
  available: AvailableTemplate,
  tip: TipTemplate
};

/* ================================================================
   POST FRAME — fits to container, scales the 1080-wide canvas
   ================================================================ */
function PostFrame({
  format,
  children,
  maxWidth,
  showSafeZones
}) {
  const ref = React.useRef(null);
  const [scale, setScale] = useState(0.4);
  React.useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => {
      const w = el.clientWidth;
      const native = CANVAS[format].w;
      setScale(w / native);
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [format]);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    className: 'post fmt-' + format,
    style: {
      maxWidth
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "post-canvas",
    style: {
      transform: `scale(${scale})`
    }
  }, children, showSafeZones && /*#__PURE__*/React.createElement(SafeZoneOverlay, {
    format: format
  })));
}

/* ================================================================
   APP
   ================================================================ */
function App() {
  const [tweaks, setTweak] = useTweaks(DEFAULTS);
  window.__t = tweaks;
  window.__setT = setTweak;
  const svc = SERVICES[tweaks.service];
  const Tmpl = TEMPLATE_FNS[tweaks.template];
  const tmplMeta = TEMPLATES.find(x => x.key === tweaks.template);
  return /*#__PURE__*/React.createElement("div", {
    className: "app"
  }, /*#__PURE__*/React.createElement("header", {
    className: "app-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    className: "app-title"
  }, "Social media templates"), /*#__PURE__*/React.createElement("p", {
    className: "app-sub"
  }, "Six brand-true templates \xD7 four formats. Real PNG wordmarks, quadrangle frames, parallelogram footer + orange stamp tag. Toggle safe-zone overlays in Tweaks.")), /*#__PURE__*/React.createElement("div", {
    className: "app-meta"
  }, "SOCIAL \xB7 UI KIT \xB7 v2")), /*#__PURE__*/React.createElement("div", {
    className: "toolbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "toolbar-group"
  }, /*#__PURE__*/React.createElement("span", {
    className: "toolbar-label"
  }, "Template"), /*#__PURE__*/React.createElement("div", {
    className: "seg"
  }, TEMPLATES.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.key,
    className: t.key === tweaks.template ? 'is-active' : '',
    onClick: () => setTweak('template', t.key)
  }, t.name)))), /*#__PURE__*/React.createElement("div", {
    className: "toolbar-group"
  }, /*#__PURE__*/React.createElement("span", {
    className: "toolbar-label"
  }, "Service"), /*#__PURE__*/React.createElement("div", {
    className: "seg"
  }, Object.entries(SERVICES).map(([k, s]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    className: k === tweaks.service ? 'is-active' : '',
    onClick: () => setTweak('service', k),
    style: {
      background: k === tweaks.service ? s.token : undefined
    }
  }, s.label)))), /*#__PURE__*/React.createElement("div", {
    className: "toolbar-group"
  }, /*#__PURE__*/React.createElement("span", {
    className: "toolbar-label"
  }, "Safe zones"), /*#__PURE__*/React.createElement("div", {
    className: "seg"
  }, /*#__PURE__*/React.createElement("button", {
    className: tweaks.showSafeZones ? 'is-active' : '',
    onClick: () => setTweak('showSafeZones', !tweaks.showSafeZones)
  }, tweaks.showSafeZones ? 'On' : 'Off')))), /*#__PURE__*/React.createElement("section", {
    className: "template-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "template-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "template-name"
  }, /*#__PURE__*/React.createElement("span", {
    className: "template-num"
  }, "All four formats"), /*#__PURE__*/React.createElement("h2", null, tmplMeta.name)), /*#__PURE__*/React.createElement("span", {
    className: "template-desc"
  }, tmplMeta.desc)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, minmax(280px, 1fr))',
      gap: 40
    }
  }, FORMATS.map(f => /*#__PURE__*/React.createElement("div", {
    className: "example-card",
    key: f.key
  }, /*#__PURE__*/React.createElement("div", {
    className: "example-meta"
  }, /*#__PURE__*/React.createElement("span", null, f.name), /*#__PURE__*/React.createElement("span", {
    className: "dim"
  }, f.label)), /*#__PURE__*/React.createElement(PostFrame, {
    format: f.key,
    showSafeZones: tweaks.showSafeZones
  }, /*#__PURE__*/React.createElement(Tmpl, {
    t: tweaks,
    format: f.key,
    svc: svc
  })))))));
}
Object.assign(window, {
  App
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/social/components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/social/tweaks-panel.jsx
try { (() => {
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  noDeckControls = false,
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  // Auto-inject a rail toggle when a <deck-stage> is on the page. The
  // toggle drives the deck's per-viewer _railVisible via window message;
  // state is mirrored from the same localStorage key the deck reads so
  // the control reflects reality across reloads. The mechanism is the
  // message — authors who want custom placement can post it directly
  // and pass noDeckControls to suppress this one.
  const hasDeckStage = React.useMemo(() => typeof document !== 'undefined' && !!document.querySelector('deck-stage'), []);
  // deck-stage enables its rail in connectedCallback, but this panel can
  // mount before that element has upgraded. The initial read catches the
  // common case; the listener covers mounting first. (Older deck-stage.js
  // copies still wait for the host's __omelette_rail_enabled postMessage —
  // same listener handles those.)
  const [railEnabled, setRailEnabled] = React.useState(() => hasDeckStage && !!document.querySelector('deck-stage')?._railEnabled);
  React.useEffect(() => {
    if (!hasDeckStage || railEnabled) return undefined;
    const onMsg = e => {
      if (e.data && e.data.type === '__omelette_rail_enabled') setRailEnabled(true);
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, [hasDeckStage, railEnabled]);
  const [railVisible, setRailVisible] = React.useState(() => {
    try {
      return localStorage.getItem('deck-stage.railVisible') !== '0';
    } catch (e) {
      return true;
    }
  });
  const toggleRail = on => {
    setRailVisible(on);
    window.postMessage({
      type: '__deck_rail_visible',
      on
    }, '*');
  };
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-noncommentable": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children, hasDeckStage && railEnabled && !noDeckControls && /*#__PURE__*/React.createElement(TweakSection, {
    label: "Deck"
  }, /*#__PURE__*/React.createElement(TweakToggle, {
    label: "Thumbnail rail",
    value: railVisible,
    onChange: toggleRail
  })))));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/social/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

})();
