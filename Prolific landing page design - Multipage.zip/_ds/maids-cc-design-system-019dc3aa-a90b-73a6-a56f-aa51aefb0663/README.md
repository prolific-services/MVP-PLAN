# Maids.cc Design System

A working design system for the Maids.cc brand — colors, type, components, logos, and UI kit pieces ready to drop into mocks, prototypes, decks, or production work.

---

## About Maids.cc

**Maids.cc** is a UAE household services company **trusted by 83K+ UAE families** (15K+ reviews). The entire booking experience runs on **WhatsApp** — every product below is initiated and managed through chat, in minutes.

The wordmark itself spells out the product line:

> **maids.cc + nannies + visa services**

There is also an **AI & Tech Division** sub-brand, which uses a tightened version of the same wordmark with "AI & Tech Division" in the orange accent slot. Use the exact same visual system for any AI & Tech materials.

### The three actual products

The brand sells trust, transparency, and speed across **three distinct services** — every piece of marketing or product copy should make it clear which one is being offered.

| # | Product | Headline price | Promise |
| - | ------- | -------------- | ------- |
| 1 | **Hourly help** | **From AED 35/hour** · cleaner or nanny | Full refund if unsatisfied · 100+ cleaners · same-maid guarantee · free add-ons (ironing, fridge, balcony, windows) · upgrades for cooking / infant / elderly / pet / special-needs / overnight nanny |
| 2 | **Full-time maid / nanny** | **From AED 2,980/month** · live-in or live-out | Ethiopian, African, or Filipina maids · in your home **today** · 7-day money-back · unlimited free replacements · all-in price (salary + visa + Ubers + medicals + gov costs) |
| 3 | **Maid visa (2-year)** | **AED 8,500 + 160/mo** *or* **AED 10,960 + 0/mo** | Visa issued in **7 days** · Emirates ID & medical · WPS payroll · PRO services (failed medicals, ban/runaway lifting, DMW, GCC) · embassy paperwork · 24/7 customer care |

**Always include with every product:** *"All on WhatsApp · in minutes."* Chat is the booking channel — never bury it.

### Products represented in this system

| Product surface | Description |
| --------------- | ----------- |
| **Marketing site** | maids.cc — homepage, packages, booking flow. Public, conversion-focused. |
| **Ops dashboard** | Internal duty-manager console — live WhatsApp inbox, roster, replacements, SLA, visa pipeline. Built in `ui_kits/dashboard/`. |
| **Social media** | Paid-post templates (feed / story / portrait) carrying the WhatsApp CTA badge. Built in `ui_kits/social/`. |
| **AI & Tech Division** | Internal/engineering-facing surface — recruiting, blog, product pages. |

### Source materials provided

The system is built from these inputs:

- `uploads/Maids Logo Blue RGB.png` — primary 2-color wordmark
- `uploads/Maids Logo White RGB.png` — reverse / dark-background wordmark
- `uploads/AI&Tech Colored@4x.png` — AI & Tech division wordmark
- `uploads/AI&Tech White@4x.png` — AI & Tech reverse wordmark

> **Source materials.** The brand board PDF **is** present in `uploads/` (`Maids Brand Board - low.pdf`), alongside the print brochures (`Brochure house - Ready for print-compressed.pdf`, `Brochure house V4 - Low.pdf`) and the social sizing guide (`Social media size.pdf`). Color, type, and logo foundations below are sampled from the official wordmarks and reconciled against that brand board. If you have the editable Figma/AI source, attach it so we can lock the remaining open items (custom icon set, approved photography) to spec.

---

## Index — what's in this folder

| Path | What's there |
| ---- | ------------ |
| `README.md` | This file. Foundations + content/visual rules. |
| `SKILL.md` | Agent-Skill front-matter so the system can be loaded as a skill in Claude Code. |
| `colors_and_type.css` | Foundation **aggregator** — `@import`s the token + base partials below. Link this (or `styles.css`) to get the whole foundation. Filename kept stable so existing links don't break. |
| `tokens/` | Design tokens split by category — `fonts`, `colors`, `typography`, `spacing`, `radii`, `shadows`, `motion`. Edit the partial you care about. |
| `base/` | Bare-element styles + helpers — `elements.css`, `dirham.css`, `image-mock.css`. |
| `assets/logos/` | Master logos — blue, white, AI&Tech colored, AI&Tech white — plus the **app icon & avatar** (the wordmark "m"). |
| `preview/` | Design-system preview cards, organized into category subfolders — `colors/`, `type/`, `spacing/`, `components/`, `brand/`. Rendered in the project's Design System tab. |
| `ui_kits/marketing/` | Marketing site UI kit — homepage, service detail pages, components, booking module. |
| `ui_kits/dashboard/` | Internal ops dashboard UI kit — duty-manager shell: live WhatsApp inbox, roster, SLA, visa pipeline. |
| `ui_kits/social/` | Social media UI kit — paid-post templates (feed, story, portrait) with the WhatsApp CTA badge. |

---

## Brand Identity at a Glance

- **Logo**: Lowercase rounded geometric sans wordmark "maids.cc". Blue main word + orange product-line tagline ("+ nannies + visa services" or "AI & Tech Division").
- **Primary color**: `#25499B` Maids Blue — sampled directly from the master wordmark.
- **Accent color**: `#EE6124` Maids Orange — sampled directly from the master wordmark.
- **Font**: **IBM Plex Sans Arabic** — the brand's licensed face, with full Latin + Arabic coverage. Loaded locally from `fonts/`. Weights 100–700 (Thin→Bold).

> 📝 **Weight cap:** IBM Plex Sans Arabic ships **Thin (100) through Bold (700)** — no ExtraBold/Black. The token system aliases `--fw-extrabold` and `--fw-black` to `700` so existing styles still work, but display headlines won't be as chunky as the wordmark itself (which is a separate hand-drawn cut). When you need extra emphasis, lean on size and color, not weight.

---

## CONTENT FUNDAMENTALS

### Voice — what Maids.cc sounds like

Maids.cc copy is **plain, direct, and reassuring**. The product is a high-trust household decision (a stranger living in your home, a visa worth thousands of dirhams) so the writing earns trust by being concrete, not aspirational.

| Trait | What we do | What we avoid |
| ----- | ---------- | ------------- |
| **Direct** | "Get a full-time maid today." | "Discover the future of home harmony." |
| **Concrete** | "Unlimited free replacements. 7-day money-back." | "We'll always be there for you." |
| **Transparent** | Show the price, the package, the contract length up front. | Hidden fees, "starting from", "contact us for pricing". |
| **Calm & confident** | Short declarative sentences. No exclamation marks except in CTAs. | Hype, urgency, fake countdowns. |
| **Service-warm** | Use **"you"** for the customer, **"we"** / **"our team"** for the brand. | Royal "we" without context, third-person "the client". |

### Casing & punctuation rules

- **Sentence case for everything** — buttons, headings, nav. Title Case looks corporate and we are not corporate. Exception: the wordmark itself is always lowercase.
- **Never ALL-CAPS / uppercase text.** No `text-transform: uppercase` anywhere — not on headings, buttons, eyebrows, labels, or nav. All-caps reads as shouting and corporate. For small label emphasis use the mono font + color + letter-spacing, never uppercasing. (The wordmark stays lowercase; never force it up.)
- **Numerals** as digits (`24/7`, `7 days`, `AED 2,980`) — never spelled out. Currency is always **AED**, placed **before** the number with a space: `AED 2,980` (UAE convention, matching every kit). In big price displays the official **dirham symbol** (`<Dh/>` / `svg.dh`, `aria-label="AED"`) replaces the letters but keeps the same before-the-number position: `⟨dh⟩ 2,980`. Never write `2,980 AED`.
- **No emoji** in product UI or marketing copy. The brand is friendly through warmth and color, not through 😊.
- **No exclamation marks** except in CTA microcopy ("Book today!" max one per screen).
- **Oxford comma**: yes.
- **Em-dash with spaces** — like this — for asides.

### Microcopy patterns

| Where | Pattern | Example |
| ----- | ------- | ------- |
| Primary CTA | Verb + outcome, ≤ 4 words | `Book a maid` · `Get my visa` · `Start now` |
| Secondary CTA | "Learn …" / "See …" / question form | `See packages` · `How does it work?` |
| Reassurance line under CTA | One sentence, fact-based | `Unlimited free replacements. Cancel anytime.` |
| Section header | Customer benefit, sentence case | `One maid. One price. No surprises.` |
| Empty state | Neutral, action-oriented, no apology | `No bookings yet. Pick a package to start.` |
| Error | What happened + what to do, no blame | `That card was declined. Try another card.` |
| Success toast | Past tense, complete sentence, no exclamation | `Your maid was scheduled for May 3.` |

### Vibe in one paragraph

> *Maids.cc reads like the calm, organised friend who already figured out the household-help thing. They tell you what it costs, when it shows up, and what happens if it doesn't work out. They book it for you on WhatsApp in the time it takes to make tea. They don't oversell. They don't apologise for being efficient. The orange is the only thing in the brand that ever raises its voice.*

---

## VISUAL FOUNDATIONS

### Color

- **Three-primary brand** — Blue, Orange, and Green sit at roughly 120° apart on the wheel (a near-triadic set). Each has a clear job; they never compete.
- **Maids Blue (`#25499B`) carries the brand** — large surfaces, navigation, headlines, illustrations, the corporate voice.
- **Maids Orange (`#EE6124`) is the spotlight** — primary CTAs, accents on hover, key data points, the "+" connector. Use sparingly — if everything is orange, nothing is.
- **Maids Green (`#15B886`) is the "yes"** — confirmation, status (active / available / booked), success toasts, the "Hire Now" pill that already lives in the brand's social. Triadic with blue and orange.
- **Pairing rule**: never put orange text on green or vice versa (they sit too close in lightness — 2.1 : 1). Always separate them with white or ink.
- **Service tones are named by their colour, never by a tint nickname.** Each of the three services rides a brand colour: full-time = **blue**, hourly / part-time = **green**, visa / overseas = **orange**. In code the tone keys and classes are literally `blue` / `green` / `orange` (e.g. `tone: 'green'`, `.btn-tone-orange`, `.media-frame-blue`). Do **not** reintroduce `lavender` or `cream` — those were legacy misnomers that rendered green/orange and contradicted the no-cream rule. When you remove a cream/beige surface, replace it with **white or a brand colour** (a `*-50` tint), never another warm off-white.
- **White & cool neutrals** dominate the canvas. Never warm beige/cream — keep neutrals true grey or with a faint blue undertone.
- **Dark mode** is not part of the brand today. If we need a dark surface, use `--maids-blue-700` (`#163068`), not pure black.

### Typography

- **One family does it all**: **IBM Plex Sans Arabic** — the brand's licensed face, with full Latin + Arabic coverage. 600–700 for headlines, 500–600 for UI, 400–500 for body.
- **Weight cap**: Plex Sans Arabic ships Thin (100) → Bold (700) only. No ExtraBold/Black — when you need extra emphasis, lean on **size and color**, not weight.
- **Generous line-height** (1.5–1.6 for body). Maids.cc copy is often read by non-native English speakers and bilingual UAE residents — readability beats density.
- **Never orphans, never widows** — `text-wrap: balance` is applied globally to all headings (h1–h4, display) so the last line never dangles a single word; `text-wrap: pretty` is applied globally to all body copy (`p`, `li`, `blockquote`) so paragraphs don't end with a short stub line. Both rules live in `base/elements.css` (pulled in via `colors_and_type.css`) — you don't need to add them per-component.
- **No italics** as a stylistic choice. Use weight + size for emphasis.

### Spacing & layout

- **4-px base grid** scaled in even steps (4, 8, 12, 16, 24, 32, 48, 64, 96).
- **Default content width**: `1200px` for marketing, `1280px` for app surfaces, with `24px` gutter.
- **Generous breathing room** — sections separated by 64–96 px on desktop. This is not a dense product; whitespace signals confidence.
- **Card padding** is `24px` default, `32px` for feature cards.
- **Sticky top nav** on marketing; sticky left rail on dashboard. Both shrink/elevate on scroll with a subtle shadow, not a color change.

### Backgrounds

- **Default**: white or `--bg-subtle` (`#FAFAFB`).
- **Hero / feature blocks**: solid `--maids-blue` or `--maids-blue-50` tint. Hard edges.
- **No gradients — anywhere.** Flat color fills only. No brand-color gradients, no orange→blue blends, no sky washes, no mesh, no subtle tint-to-white fades. If a surface needs depth, use a tint step (`*-50` / `*-100`) or a neutral shadow, never a gradient. **One functional exception:** a single-hue photo-legibility scrim under text on photography (see Imagery) — that is a readability tool, never decoration.
- **Photography**: warm, candid, household-real. Daylight, soft natural light, no studio gloss. People (maids and families) shown working/living, not posing. Maids wear the navy maids.cc uniform.
- **No hand-drawn illustrations.** No textured papers, no patterns, no grain. The brand is clean and product-led.

### Animation & motion

- **Standard easing**: `cubic-bezier(0.2, 0, 0, 1)` ("--ease-standard"). Snappy in, soft out.
- **Default duration**: `200ms`. Long enough to register, short enough to feel responsive.
- **Bounce** is allowed only on success states (e.g., a confirmation checkmark) — `cubic-bezier(0.34, 1.56, 0.64, 1)`. Never on hover or scroll.
- **Fades** for content swaps; **slide-up 8 px + fade** for modals and toasts.
- **No parallax**, no scroll-jacking, no auto-rotating hero carousels.

### Hover & press

- **Hover (interactive)**: shift to `*-600` token (e.g. blue → `#1E3D85`, orange → `#D44E14`) AND raise shadow one step. **No opacity hovers** — they look unfinished.
- **Hover (link)**: color shift from blue to orange. No underline appearing.
- **Press**: shift to `*-700` AND scale `0.98` for 80 ms. Feels physical without being cute.
- **Focus ring**: 2 px solid `--maids-orange` offset by 2 px. Always visible — orange is the focus color whether the element is blue, white, or orange.
- **Disabled**: 40 % opacity OR muted token (`--fg-disabled`); cursor `not-allowed`.

### Borders, shadows, elevation

- **Border default**: `1px solid var(--border-subtle)` = `#E5E7EB`. Never thicker than 1 px outside form controls.
- **Form-control border**: `1.5px` for affordance.
- **Shadow philosophy**: soft, double-layered, slightly cool-tinted (we use `rgba(17,24,39, …)` — the deep neutral — not pure black).
  - `shadow-xs` for micro-elevation (chips, raised inputs)
  - `shadow-sm` default cards
  - `shadow-md` cards on hover, popovers
  - `shadow-lg` modals, hero CTAs
- **No glow — ever.** Shadows are always **neutral cool-grey** (`rgba(17,24,39,…)`), never a brand-colored bloom. There are no orange or blue glows on CTAs, badges, or play buttons. (`--shadow-brand` / `--shadow-accent` still exist as token names for back-compat but now resolve to the same neutral shadow — don't author new colored shadows.)
- **No inner shadows.** No "neumorphic" inset effects.

### Cards

- **Surface**: white.
- **Radius**: `12px` default, `16px` for feature cards, `24px` for hero modules.
- **Border**: 1 px subtle border **OR** soft shadow — pick one, never both. Default to shadow on white pages, border on tinted (`--maids-blue-50`) pages.
- **Padding**: `24px`; `32px` if it has a header strip.
- **Header strip pattern**: when a card has a colored header strip, the strip is `--maids-blue` and contains white display-weight text + an optional orange `+` accent.

### Corners & shape language

- **Radii speak warmth.** All buttons are full pill (`--radius-pill`) — matches the rounded wordmark. Cards get `12–16px`. Inputs are `8px`. **Never sharp 90° corners** on interactive surfaces.
- **Avatars / image masks**: full circle for people, `12px` for property/location imagery.

### Transparency, blur, glass

- **Almost never.** The brand is high-contrast and decisive. The only allowed glass surface is the **scroll-shrunken top nav**, which uses `rgba(255,255,255,0.85) + backdrop-filter: blur(12px)`.
- **Image overlays — the one allowed scrim.** To keep white text legible over photography, use a **single-hue** deep-blue scrim that fades from `rgba(22,48,104,~0.6)` to transparent, confined to the text zone, paired with a subtle text-shadow. This is the *only* gradient permitted in the system, and only for legibility — never two hues, never decorative, never over a surface without text. No black overlays.

### Layout rules — fixed elements

- **Top nav**: sticky, 72 px tall, full bleed, white. Shrinks to 56 px and gains `shadow-sm` after `64 px` of scroll.
- **Floating CTA**: bottom-right on marketing pages — pill-shaped, orange, neutral `shadow-lg` (no colored glow). Hidden until the hero scrolls out of view.
- **Dashboard sidebar**: fixed left, 240 px wide, `--maids-blue-700` background.

### Imagery treatment

- Color-grade photography toward **warm-but-natural daylight**. Skin tones true; whites slightly warm. Never push toward teal-and-orange cinematic grading — keep it editorial-real.
- **No B&W photography.** No film-grain treatments. No oversaturated stock.
- **Cropping rule — keep face and action visible.** Whenever a photo is cropped or framed, preserve **both** the maid's face (if present) **and** the action she's performing. Never crop down to a torso, a single arm, or the tool alone.
- **Home service cards are a consistent mid close-up.** Each card in the homepage product picker frames a **mid close-up** of the maid — face (if available) plus the action — at a **4:3** ratio. Because source photos vary (some are wide environmental shots where the subject reads small), bake a dedicated `*-card.png` crop per service rather than relying on `object-fit: cover` alone, which can't zoom a wide frame. Detail-page heroes keep the **full, uncropped** photo at 4:5.
- For decorative/abstract spots: **flat geometric shapes in brand colors** (a blue square, an orange `+` symbol enlarged) — never gradient meshes or generic 3D blobs.

---

## ICONOGRAPHY

We did not receive a custom icon set with the brand assets. The system uses **Lucide** (formerly Feather), via CDN, as the standard icon font. Lucide's stroke style — `1.5 px`, rounded line caps, geometric — matches the rounded wordmark nicely without competing.

- **Stroke weight**: `1.75 px` for icons sized 16–20 px, `2 px` at 24 px+. Lucide's default `2 px` is fine; bump to `2.25 px` only on white-on-color backgrounds.
- **Size grid**: `16 / 20 / 24 / 32 / 48`. Default UI icon is `20 px`.
- **Color**: inherits text color (`--fg-2` for nav, `--fg-1` for emphasis). Orange for **action** affordance, blue for **brand** affordance.
- **No filled icons** mixed with outline. Pick one per surface; default is outline.
- **No emoji** anywhere in product UI.
- **No unicode glyphs as icons** (no `→`, `✓`, etc. in copy — use Lucide `arrow-right`, `check`).

> **WhatsApp is a first-class brand mark — not a generic chat icon.** Maids.cc is proud that the entire B2C journey happens on WhatsApp, so **every action that opens or represents WhatsApp** — chat CTAs, "message us", 24/7 support, "get a quote", a WhatsApp inbox or activity row — **must carry the official WhatsApp glyph**, never a generic Lucide `message-circle` / `message-square` / `headphones` / `help-circle`, and never a hand-drawn speech bubble. The mark signals the destination; the channel is the product. Each UI kit ships a shared **`WaIcon`** component (inline SVG, inherits `currentColor`, so it works white-on-green or in-button). Reserve Lucide message/chat icons strictly for **non-WhatsApp** messaging (internal notes, email). When a feature card or table row is about WhatsApp support, use `ic: 'whatsapp'` and let the kit render `WaIcon`.

> **Icon CDN flagged.** Lucide is a substitution — Maids.cc may have a custom set in production. If you have it, drop SVGs into `assets/icons/` and we'll switch the kits to use them.

CDN reference (already wired into the UI kits):

```html
<script src="https://unpkg.com/lucide@latest"></script>
<script>lucide.createIcons();</script>
```

The **`+` symbol** that appears in the wordmark is itself a brand mark — when an interface needs a "plus" icon as decoration (not as a UI control), use the chunky rounded plus from the wordmark, not Lucide's plus. Render it as `<span class="brand-plus">+</span>` styled with `font-family: var(--font-display); font-weight: 800; color: var(--maids-orange);`.

---

## How to use this system

```html
<link rel="stylesheet" href="colors_and_type.css">
<!-- Now any heading / paragraph / token-using element is on-brand -->

<h1>One maid. One price. No surprises.</h1>
<p>Unlimited free replacements. Cancel anytime.</p>
<button class="btn btn-primary">Book a maid</button>
```

Components live in `ui_kits/<product>/` as standalone JSX files you can import, or copy into a new design.

---

## Open questions / needs from you

1. **AI & Tech Division** — we have its wordmarks but no further sub-brand guidelines. If there's a separate tone/visual extension for AI&Tech, share it.
2. **Photography library** — the brand calls for real, honest, soft-light photography. **Full-time** and **part-time** now have real candid photos wired into both their service pages (4:5 hero) and homepage cards (4:3 mid close-up crop); **visa** and **overseas** still use placeholders. If you can share approved, production-licensed photos — especially for visa and overseas — we'll wire them in with the same face-and-action framing.
3. **Custom icon set** — confirm whether the production app uses a custom set or Lucide/Feather/Phosphor.
4. **Dashboard scope** — the built dashboard kit is an **internal ops** console (duty-manager view). If you also need a **customer-facing** logged-in dashboard, share screenshots or a Figma and we'll build it as a separate surface.
